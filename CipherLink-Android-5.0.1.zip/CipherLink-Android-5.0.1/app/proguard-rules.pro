# CipherLink uses standard JCA/JCE APIs; no special reflection rules are required.
