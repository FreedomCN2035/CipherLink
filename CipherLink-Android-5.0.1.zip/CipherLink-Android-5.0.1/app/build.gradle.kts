plugins {
    id("com.android.application")
}

android {
    namespace = "com.cipherlink.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.cipherlink.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 31
        versionName = "5.0.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("com.google.zxing:core:3.5.4")
}
