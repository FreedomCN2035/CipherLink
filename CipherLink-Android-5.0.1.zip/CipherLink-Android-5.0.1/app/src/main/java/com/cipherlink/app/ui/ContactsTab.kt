package com.cipherlink.app.ui

import android.graphics.Bitmap
import android.view.View
import android.widget.ImageView
import android.widget.ScrollView
import com.cipherlink.app.MainActivity
import com.cipherlink.app.R
import com.cipherlink.app.core.Fmt
import com.cipherlink.app.qr.QrCodec
import com.cipherlink.app.storage.AppStore

/** "联系人" tab: my public key (text + QR) and the saved public keys of the people I talk to. */
class ContactsTab(private val host: MainActivity) {
    private val ui: Ui get() = host.ui
    private val store: AppStore get() = host.store

    fun build(): View {
        val scroll = ScrollView(host).apply { isFillViewport = true }
        val box = ui.vbox().apply { setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(24)) }

        box.addView(ui.sectionTitle("我的公钥", "发给对方；对方保存后才能给你发密文。公钥可以公开。"))
        box.addView(myKeyCard())

        box.addView(ui.sectionTitle("联系人", "保存对方的公钥，加密时选择他们作为收件人"))
        val addCard = ui.card()
        addCard.addView(ui.button("＋ 添加联系人", Ui.BTN_PRIMARY) { host.showAddContactDialog() }, ui.lp(h = ui.dp(46)))
        val row = ui.hbox()
        row.addView(ui.button("从剪贴板添加") { host.addContactFromClipboard() }, ui.lp(w = 0, weight = 1f, t = 8, r = 5))
        row.addView(ui.button("扫描公钥截图") { host.addContactFromScreenshot() }, ui.lp(w = 0, weight = 1f, t = 8, l = 5))
        addCard.addView(row)
        box.addView(addCard)

        val contacts = store.listContacts()
        if (contacts.isEmpty()) {
            val empty = ui.card()
            empty.addView(Dialogs.centered(ui, "还没有联系人\n把对方发来的 CL2P. 公钥卡粘贴进来即可"))
            box.addView(empty)
        } else {
            val activeId = store.activeContactId()
            contacts.forEach { contact -> box.addView(contactCard(contact, contact.id == activeId)) }
        }

        val note = ui.card()
        note.background = ui.rounded(ui.color(R.color.cl_primary_soft), 20)
        note.addView(ui.text("防冒充小提示", 14f, R.color.cl_primary, true))
        note.addView(
            ui.text(
                "第一次交换公钥时，请通过电话或当面核对双方的“指纹”是否一致。保存为联系人后，CipherLink 会自动校验之后每条消息的发送方身份。",
                12f, R.color.cl_text
            ).apply { setLineSpacing(0f, 1.15f) },
            ui.lp(t = 4)
        )
        box.addView(note)

        scroll.addView(box)
        return scroll
    }

    private fun myKeyCard(): View {
        val card = ui.card()
        val cardText = store.publicKeyCard()
        val fingerprint = store.myFingerprint()
        if (cardText == null || fingerprint == null) {
            card.addView(Dialogs.centered(ui, "还没有密钥\n到“消息”页点“创建密钥”"))
            return card
        }
        card.addView(ui.labelValue("我的指纹", Fmt.fingerprint(fingerprint), true))

        var qr: Bitmap? = null
        try {
            qr = QrCodec.encode(cardText, 560)
        } catch (t: Throwable) {
            qr = null
        }
        val image = qr
        if (image != null) {
            val view = ImageView(host).apply {
                setImageBitmap(image)
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(0xFFFFFFFF.toInt())
                setPadding(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8))
            }
            card.addView(view, ui.lp(w = ui.dp(210), h = ui.dp(210), t = 12))
        }

        val row = ui.hbox()
        row.addView(ui.button("分享公钥", Ui.BTN_PRIMARY) { host.shareMyPublicKey() }, ui.lp(w = 0, weight = 1f, t = 12, r = 5))
        row.addView(ui.button("复制") {
            host.copyText(cardText)
            host.toast("公钥已复制，发给对方即可")
        }, ui.lp(w = 0, weight = 1f, t = 12, l = 5))
        card.addView(row)
        if (image != null) {
            card.addView(ui.button("保存二维码到相册") { host.saveImageToGallery(image) }, ui.lp(t = 8))
        }
        return card
    }

    private fun contactCard(contact: AppStore.Contact, active: Boolean): View {
        val card = ui.card()
        val head = ui.hbox()
        head.addView(ui.text(contact.name, 17f, R.color.cl_text, true), ui.lp(w = 0, weight = 1f, r = 8))
        if (active) head.addView(ui.chip("当前收件人", R.color.cl_green, R.color.cl_green_soft))
        card.addView(head)
        card.addView(ui.mono(Fmt.fingerprint(contact.id), 11f).apply {
            setTextColor(ui.color(R.color.cl_muted))
        }, ui.lp(t = 4))

        val row = ui.hbox()
        row.addView(
            ui.button(if (active) "取消当前" else "设为收件人", if (active) Ui.BTN_SECONDARY else Ui.BTN_PRIMARY) {
                store.setActiveContact(if (active) null else contact.id)
                host.renderTab()
            },
            ui.lp(w = 0, weight = 1.4f, t = 10, r = 5)
        )
        row.addView(ui.button("重命名") { host.renameContact(contact) }, ui.lp(w = 0, weight = 1f, t = 10, l = 5, r = 5))
        row.addView(ui.button("删除", Ui.BTN_DANGER) { host.deleteContact(contact) }, ui.lp(w = 0, weight = 1f, t = 10, l = 5))
        card.addView(row)
        return card
    }
}
