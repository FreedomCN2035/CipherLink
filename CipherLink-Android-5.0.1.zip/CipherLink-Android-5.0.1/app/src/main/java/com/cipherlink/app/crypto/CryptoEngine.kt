package com.cipherlink.app.crypto

import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PublicKey
import java.security.SecureRandom
import java.security.Signature
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.MGF1ParameterSpec
import java.security.spec.RSAPublicKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import javax.crypto.spec.SecretKeySpec

/**
 * CipherLink crypto protocol (CL2).
 *
 * Hybrid encryption:
 *   RSA-3072-OAEP(SHA-256, MGF1-SHA1) wraps a random AES-256 key.
 *   AES-256-GCM encrypts the payload (UTF-8 text, or an attachment envelope).
 *   SHA256withRSA signs all header fields, the ciphertext and the sender modulus.
 *
 * Wire compatibility: the text format (CL2M.) produced by version 4.x is unchanged. The
 * formerly reserved header byte now carries the content type (0 = text, 1 = attachment);
 * it is part of the signed data, so it cannot be altered in transit.
 */
object CryptoEngine {
    const val PUBLIC_PREFIX = "CL2P."
    const val MESSAGE_PREFIX = "CL2M."

    const val CONTENT_TEXT = 0
    const val CONTENT_ATTACHMENT = 1

    /** Hard limit for one attachment. The encrypted file is about the same size. */
    const val MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024

    private const val RSA_BITS = 3072
    private const val RSA_MODULUS_BYTES = RSA_BITS / 8
    private const val RSA_PUBLIC_EXPONENT = 65537L
    private const val AES_BYTES = 32
    private const val GCM_IV_BYTES = 12
    private const val GCM_TAG_BITS = 128
    private const val FINGERPRINT_BYTES = 12
    private const val MAX_TEXT_BYTES = 1024 * 1024
    private const val ENVELOPE_OVERHEAD = 64 * 1024
    private const val MAX_PLAINTEXT_BYTES = MAX_ATTACHMENT_BYTES + ENVELOPE_OVERHEAD
    private const val MAX_CIPHERTEXT_BYTES = MAX_PLAINTEXT_BYTES + 16
    private const val MAX_MESSAGE_TEXT_CHARS = 1_500_000

    private const val PROTOCOL_VERSION = 2
    private const val SUITE_ID = 1 // RSA3072-OAEP-SHA256/MGF1-SHA1 + AES256-GCM + SHA256withRSA
    private const val FLAGS_EMBED_SENDER_MODULUS = 0x01

    private const val ENVELOPE_MAGIC = 0x434C4131 // "CLA1"
    private val FILE_MAGIC = byteArrayOf('C'.code.toByte(), 'L'.code.toByte(), '2'.code.toByte(), 'F'.code.toByte())

    private val encoder = Base64.getUrlEncoder().withoutPadding()
    private val decoder = Base64.getUrlDecoder()

    data class ParsedPublicKey(val key: PublicKey, val id: String)

    class Attachment(val name: String, val mime: String, val data: ByteArray)

    class DecryptResult(
        val kind: Int,
        /** Text message body, or the optional caption of an attachment. */
        val plaintext: String,
        val attachment: Attachment?,
        val senderFingerprint: String,
        val senderName: String?,
        val trustedIdentity: Boolean,
        /** CL2P card rebuilt from the verified embedded sender key, so it can be saved as a contact. */
        val senderCard: String
    )

    data class TrustedContact(val name: String, val publicKey: PublicKey)

    // ------------------------------------------------------------------ keys

    fun generateIdentity(extraEntropy: ByteArray = ByteArray(0)): KeyPair {
        val random = SecureRandom()
        if (extraEntropy.isNotEmpty()) {
            // setSeed supplements the OS-provided CSPRNG; it never replaces it.
            random.setSeed(extraEntropy)
        }
        val generator = KeyPairGenerator.getInstance("RSA")
        generator.initialize(RSA_BITS, random)
        return generator.generateKeyPair()
    }

    fun isMatchingKeyPair(keyPair: KeyPair): Boolean {
        val pub = keyPair.public as? RSAPublicKey ?: return false
        val priv = keyPair.private as? RSAPrivateKey ?: return false
        return pub.modulus == priv.modulus && priv.modulus.bitLength() >= 3000
    }

    /**
     * Two independent round-trip checks before a generated key is accepted:
     * raw RSA-OAEP public->private, and the complete CL2M envelope encrypt->decrypt.
     */
    fun selfTest(keyPair: KeyPair): Boolean {
        if (!isMatchingKeyPair(keyPair)) return false
        return runCatching {
            val probe = "你好".toByteArray(StandardCharsets.UTF_8)
            val rawEncrypted = oaepCipher(Cipher.ENCRYPT_MODE, keyPair.public).doFinal(probe)
            val rawDecrypted = oaepCipher(Cipher.DECRYPT_MODE, keyPair.private).doFinal(rawEncrypted)
            require(rawDecrypted.contentEquals(probe))

            val full = encrypt("CipherLink 自测：你好", keyPair.public, keyPair)
            val result = decrypt(full, keyPair, emptyMap())
            require(result.plaintext == "CipherLink 自测：你好")
            true
        }.getOrDefault(false)
    }

    fun fingerprint(publicKey: PublicKey): String {
        validateRsaPublicKey(publicKey)
        return MessageDigest.getInstance("SHA-256")
            .digest(publicKey.encoded)
            .copyOf(FINGERPRINT_BYTES)
            .joinToString("") { "%02X".format(it.toInt() and 0xFF) }
    }

    /** Compact public-key card: about 540 ASCII chars. */
    fun buildPublicKeyCard(publicKey: PublicKey): String {
        validateRsaPublicKey(publicKey)
        val rsa = publicKey as RSAPublicKey
        val modulus = toFixedUnsigned(rsa.modulus, RSA_MODULUS_BYTES)
        val fp = MessageDigest.getInstance("SHA-256").digest(publicKey.encoded).copyOf(FINGERPRINT_BYTES)

        val buf = ByteBuffer.allocate(1 + 1 + 4 + RSA_MODULUS_BYTES + FINGERPRINT_BYTES)
        buf.put(PROTOCOL_VERSION.toByte())
        buf.put(SUITE_ID.toByte())
        buf.putInt(RSA_PUBLIC_EXPONENT.toInt())
        buf.put(modulus)
        buf.put(fp)
        return PUBLIC_PREFIX + encode(buf.array())
    }

    fun parsePublicKeyCard(value: String): ParsedPublicKey {
        val clean = value.trim()
        if (clean.startsWith(PUBLIC_PREFIX)) {
            val raw = decode(clean.removePrefix(PUBLIC_PREFIX))
            require(raw.size == 1 + 1 + 4 + RSA_MODULUS_BYTES + FINGERPRINT_BYTES) {
                "CL2P 公钥卡长度错误"
            }
            var p = 0
            val version = raw[p++].toInt() and 0xFF
            val suite = raw[p++].toInt() and 0xFF
            require(version == PROTOCOL_VERSION && suite == SUITE_ID) { "不支持的公钥卡版本" }
            val exponent = readInt(raw, p).toLong() and 0xFFFFFFFFL
            p += 4
            require(exponent == RSA_PUBLIC_EXPONENT) { "不支持的 RSA 公钥指数" }
            val modulus = raw.copyOfRange(p, p + RSA_MODULUS_BYTES)
            p += RSA_MODULUS_BYTES
            val expectedFp = raw.copyOfRange(p, p + FINGERPRINT_BYTES)
            val key = publicKeyFromModulus(modulus)
            val actualFp = MessageDigest.getInstance("SHA-256").digest(key.encoded).copyOf(FINGERPRINT_BYTES)
            require(MessageDigest.isEqual(expectedFp, actualFp)) { "公钥卡指纹校验失败" }
            return ParsedPublicKey(key, fingerprint(key))
        }

        // Also accept standard PEM public keys for easy manual import.
        val pem = clean
            .removePrefix("-----BEGIN PUBLIC KEY-----")
            .removeSuffix("-----END PUBLIC KEY-----")
            .replace("\\s".toRegex(), "")
        val der = try {
            Base64.getDecoder().decode(pem)
        } catch (_: Throwable) {
            decode(pem)
        }
        val key = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(der))
        validateRsaPublicKey(key)
        return ParsedPublicKey(key, fingerprint(key))
    }

    // ------------------------------------------------------------ encryption

    /** Encrypt text. Returns the CL2M. text form. */
    fun encrypt(plaintext: String, recipient: PublicKey, sender: KeyPair): String {
        val plain = plaintext.toByteArray(StandardCharsets.UTF_8)
        require(plain.isNotEmpty()) { "消息不能为空" }
        require(plain.size <= MAX_TEXT_BYTES) { "消息过长：单条文本最多 1 MB" }
        return packetToText(encryptPacket(plain, CONTENT_TEXT, recipient, sender))
    }

    /**
     * Encrypt a file. Returns the raw packet; use [packetToFile] to write it to disk
     * or [packetToText] when it is small enough to be sent as text / QR codes.
     */
    fun encryptAttachment(
        name: String,
        mime: String,
        data: ByteArray,
        caption: String,
        recipient: PublicKey,
        sender: KeyPair
    ): ByteArray {
        require(data.isNotEmpty()) { "附件是空文件" }
        require(data.size <= MAX_ATTACHMENT_BYTES) {
            "附件过大：最大 ${MAX_ATTACHMENT_BYTES / (1024 * 1024)} MB"
        }
        val envelope = buildEnvelope(cleanFileName(name), mime.take(120), caption.take(2000), data)
        return encryptPacket(envelope, CONTENT_ATTACHMENT, recipient, sender)
    }

    private fun encryptPacket(plain: ByteArray, contentType: Int, recipient: PublicKey, sender: KeyPair): ByteArray {
        require(plain.size <= MAX_PLAINTEXT_BYTES) { "内容过大" }
        validateRsaPublicKey(recipient)
        require(isMatchingKeyPair(sender)) { "发送方公私钥不是同一套密钥" }

        val random = SecureRandom()
        val aesBytes = ByteArray(AES_BYTES).also(random::nextBytes)
        val iv = ByteArray(GCM_IV_BYTES).also(random::nextBytes)

        val aes = Cipher.getInstance("AES/GCM/NoPadding")
        aes.init(Cipher.ENCRYPT_MODE, SecretKeySpec(aesBytes, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
        val cipherText = aes.doFinal(plain)
        require(cipherText.size <= MAX_CIPHERTEXT_BYTES) { "密文长度异常" }

        // The actual public->private asymmetric step.
        val wrappedKey = oaepCipher(Cipher.ENCRYPT_MODE, recipient).doFinal(aesBytes)
        require(wrappedKey.size == RSA_MODULUS_BYTES) { "RSA 密钥封装长度异常" }

        val recipientFp = hexToBytes(fingerprint(recipient))
        val senderFp = hexToBytes(fingerprint(sender.public))
        val senderRsa = sender.public as RSAPublicKey
        val senderModulus = toFixedUnsigned(senderRsa.modulus, RSA_MODULUS_BYTES)

        val headerLen = 4 + FINGERPRINT_BYTES + FINGERPRINT_BYTES + RSA_MODULUS_BYTES +
            GCM_IV_BYTES + 4 + cipherText.size
        val packet = ByteBuffer.allocate(headerLen + RSA_MODULUS_BYTES + RSA_MODULUS_BYTES)
        packet.put(PROTOCOL_VERSION.toByte())
        packet.put(SUITE_ID.toByte())
        packet.put(FLAGS_EMBED_SENDER_MODULUS.toByte())
        packet.put(contentType.toByte())
        packet.put(recipientFp)
        packet.put(senderFp)
        packet.put(wrappedKey)
        packet.put(iv)
        packet.putInt(cipherText.size)
        packet.put(cipherText)
        check(packet.position() == headerLen)

        val raw = packet.array()
        val signature = Signature.getInstance("SHA256withRSA")
        signature.initSign(sender.private)
        signature.update(raw, 0, headerLen)
        signature.update(senderModulus)
        val signed = signature.sign()
        require(signed.size == RSA_MODULUS_BYTES) { "RSA 签名长度异常" }

        packet.put(signed)
        packet.put(senderModulus)
        return raw
    }

    // ------------------------------------------------------------ decryption

    fun decrypt(
        payloadText: String,
        recipient: KeyPair,
        trustedContacts: Map<String, TrustedContact> = emptyMap()
    ): DecryptResult {
        val clean = payloadText.trim()
        require(clean.length <= MAX_MESSAGE_TEXT_CHARS) { "加密消息过大或数据异常" }
        require(clean.startsWith(MESSAGE_PREFIX)) { "不是 CipherLink CL2 加密消息（应以 CL2M. 开头）" }
        return decryptPacket(decode(clean.removePrefix(MESSAGE_PREFIX)), recipient, trustedContacts)
    }

    fun decryptPacket(
        raw: ByteArray,
        recipient: KeyPair,
        trustedContacts: Map<String, TrustedContact> = emptyMap()
    ): DecryptResult {
        require(isMatchingKeyPair(recipient)) { "本机公钥与私钥不是同一套密钥，请检查本机密钥。" }
        require(raw.size >= minimumPacketSize()) { "加密消息长度错误或已损坏" }
        var p = 0
        fun take(n: Int): ByteArray {
            require(n >= 0 && p + n <= raw.size) { "加密消息被截断" }
            return raw.copyOfRange(p, p + n).also { p += n }
        }
        fun byte(): Int = take(1)[0].toInt() and 0xFF

        val version = byte()
        val suite = byte()
        val flags = byte()
        val contentType = byte()
        require(version == PROTOCOL_VERSION && suite == SUITE_ID) { "不支持的加密消息版本" }
        require(flags and FLAGS_EMBED_SENDER_MODULUS != 0) { "消息未携带发送方公钥" }
        require(contentType == CONTENT_TEXT || contentType == CONTENT_ATTACHMENT) { "不支持的内容类型" }

        val recipientFp = bytesToHex(take(FINGERPRINT_BYTES))
        val senderFp = bytesToHex(take(FINGERPRINT_BYTES))
        require(recipientFp == fingerprint(recipient.public)) { "这条消息不是发给当前设备的公钥" }

        val wrappedKey = take(RSA_MODULUS_BYTES)
        val iv = take(GCM_IV_BYTES)
        val ctLen = readInt(raw, p)
        p += 4
        require(ctLen in 17..MAX_CIPHERTEXT_BYTES) { "密文长度异常" }
        val cipherText = take(ctLen)
        val headerLen = p
        val signature = take(RSA_MODULUS_BYTES)
        val senderModulus = take(RSA_MODULUS_BYTES)
        require(p == raw.size) { "加密消息存在未知尾部数据" }

        val embeddedSender = publicKeyFromModulus(senderModulus)
        require(fingerprint(embeddedSender) == senderFp) { "发送方公钥与消息指纹不匹配" }

        val trusted = trustedContacts[senderFp]
        if (trusted != null) {
            require(fingerprint(trusted.publicKey) == senderFp) { "本地联系人公钥指纹不一致" }
        }
        val verifyKey = trusted?.publicKey ?: embeddedSender
        val verified = runCatching {
            val sig = Signature.getInstance("SHA256withRSA")
            sig.initVerify(verifyKey)
            sig.update(raw, 0, headerLen)
            sig.update(senderModulus)
            sig.verify(signature)
        }.getOrDefault(false)
        require(verified) { "签名验证失败：消息可能被篡改，或发送方公钥不匹配" }

        val aesBytes = runCatching {
            oaepCipher(Cipher.DECRYPT_MODE, recipient.private).doFinal(wrappedKey)
        }.getOrElse {
            throw IllegalArgumentException("RSA 会话密钥解包失败：请确认对方使用的是你的公钥，并且消息没有被修改。", it)
        }
        require(aesBytes.size == AES_BYTES) { "AES 会话密钥长度错误" }

        val plainBytes = runCatching {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(aesBytes, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
            cipher.doFinal(cipherText)
        }.getOrElse {
            throw IllegalArgumentException("AES-GCM 解密失败：密文损坏或被修改。", it)
        }

        val card = buildPublicKeyCard(embeddedSender)
        return if (contentType == CONTENT_ATTACHMENT) {
            val parsed = parseEnvelope(plainBytes)
            DecryptResult(CONTENT_ATTACHMENT, parsed.first, parsed.second, senderFp, trusted?.name, trusted != null, card)
        } else {
            DecryptResult(
                CONTENT_TEXT, String(plainBytes, StandardCharsets.UTF_8), null,
                senderFp, trusted?.name, trusted != null, card
            )
        }
    }

    // --------------------------------------------------------------- file form

    fun packetToText(packet: ByteArray): String = MESSAGE_PREFIX + encode(packet)

    /** Encrypted file on disk = 4-byte magic "CL2F" + raw packet. */
    fun packetToFile(packet: ByteArray): ByteArray {
        val out = ByteArray(FILE_MAGIC.size + packet.size)
        System.arraycopy(FILE_MAGIC, 0, out, 0, FILE_MAGIC.size)
        System.arraycopy(packet, 0, out, FILE_MAGIC.size, packet.size)
        return out
    }

    /** True if these first bytes start an encrypted CipherLink file (cheap pre-check). */
    fun hasFileMagic(head: ByteArray): Boolean {
        if (head.size < FILE_MAGIC.size) return false
        for (i in FILE_MAGIC.indices) if (head[i] != FILE_MAGIC[i]) return false
        return true
    }

    fun isEncryptedFile(bytes: ByteArray): Boolean {
        if (bytes.size < FILE_MAGIC.size + minimumPacketSize()) return false
        for (i in FILE_MAGIC.indices) if (bytes[i] != FILE_MAGIC[i]) return false
        return true
    }

    fun fileToPacket(bytes: ByteArray): ByteArray {
        require(isEncryptedFile(bytes)) { "不是 CipherLink 加密文件" }
        return bytes.copyOfRange(FILE_MAGIC.size, bytes.size)
    }

    /** Largest encrypted-file size the app will try to open (attachment + protocol overhead). */
    const val MAX_FILE_BYTES = MAX_ATTACHMENT_BYTES + ENVELOPE_OVERHEAD + 4096

    // ---------------------------------------------------------------- envelope

    private fun buildEnvelope(name: String, mime: String, caption: String, data: ByteArray): ByteArray {
        val nameB = name.toByteArray(StandardCharsets.UTF_8)
        val mimeB = mime.toByteArray(StandardCharsets.UTF_8)
        val capB = caption.toByteArray(StandardCharsets.UTF_8)
        val buf = ByteBuffer.allocate(4 + 2 + nameB.size + 2 + mimeB.size + 4 + capB.size + 4 + data.size)
        buf.putInt(ENVELOPE_MAGIC)
        buf.putShort(nameB.size.toShort())
        buf.put(nameB)
        buf.putShort(mimeB.size.toShort())
        buf.put(mimeB)
        buf.putInt(capB.size)
        buf.put(capB)
        buf.putInt(data.size)
        buf.put(data)
        return buf.array()
    }

    private fun parseEnvelope(bytes: ByteArray): Pair<String, Attachment> {
        val buf = ByteBuffer.wrap(bytes)
        require(buf.remaining() >= 16 && buf.int == ENVELOPE_MAGIC) { "附件数据格式错误" }
        val nameLen = buf.short.toInt() and 0xFFFF
        require(nameLen <= 1024 && buf.remaining() >= nameLen) { "附件文件名异常" }
        val nameB = ByteArray(nameLen).also { buf.get(it) }
        require(buf.remaining() >= 2) { "附件数据被截断" }
        val mimeLen = buf.short.toInt() and 0xFFFF
        require(mimeLen <= 256 && buf.remaining() >= mimeLen) { "附件类型异常" }
        val mimeB = ByteArray(mimeLen).also { buf.get(it) }
        require(buf.remaining() >= 4) { "附件数据被截断" }
        val capLen = buf.int
        require(capLen in 0..(16 * 1024) && buf.remaining() >= capLen) { "附件说明异常" }
        val capB = ByteArray(capLen).also { buf.get(it) }
        require(buf.remaining() >= 4) { "附件数据被截断" }
        val dataLen = buf.int
        require(dataLen in 1..MAX_ATTACHMENT_BYTES && buf.remaining() == dataLen) { "附件长度异常" }
        val data = ByteArray(dataLen).also { buf.get(it) }
        val name = cleanFileName(String(nameB, StandardCharsets.UTF_8))
        val mime = String(mimeB, StandardCharsets.UTF_8).ifBlank { "application/octet-stream" }
        return Pair(String(capB, StandardCharsets.UTF_8), Attachment(name, mime, data))
    }

    /** The file name comes from the other party: never trust path separators or control characters. */
    fun cleanFileName(raw: String): String {
        val base = raw.substringAfterLast('/').substringAfterLast('\\')
        val cleaned = base
            .map { c -> if (c.isISOControl() || c in "<>:\"|?*") '_' else c }
            .joinToString("")
            .trim()
            .trimStart('.')
            .take(120)
        return cleaned.ifBlank { "attachment.bin" }
    }

    // ----------------------------------------------------------------- helpers

    private fun minimumPacketSize(): Int = 4 + FINGERPRINT_BYTES + FINGERPRINT_BYTES +
        RSA_MODULUS_BYTES + GCM_IV_BYTES + 4 + 17 + RSA_MODULUS_BYTES + RSA_MODULUS_BYTES

    private fun oaepCipher(mode: Int, key: java.security.Key): Cipher {
        val cipher = Cipher.getInstance("RSA/ECB/OAEPPadding")
        val spec = OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA1, PSource.PSpecified.DEFAULT)
        cipher.init(mode, key, spec)
        return cipher
    }

    private fun validateRsaPublicKey(key: PublicKey) {
        val rsa = key as? RSAPublicKey ?: throw IllegalArgumentException("不是 RSA 公钥")
        require(rsa.modulus.bitLength() >= 3000) { "RSA 公钥强度不足：必须至少 RSA-3072" }
        require(rsa.publicExponent == BigInteger.valueOf(RSA_PUBLIC_EXPONENT)) { "RSA 公钥指数必须为 65537" }
    }

    private fun publicKeyFromModulus(modulusBytes: ByteArray): PublicKey {
        require(modulusBytes.size == RSA_MODULUS_BYTES) { "RSA modulus 长度错误" }
        val modulus = BigInteger(1, modulusBytes)
        require(modulus.bitLength() >= 3000) { "RSA modulus 强度不足" }
        val spec = RSAPublicKeySpec(modulus, BigInteger.valueOf(RSA_PUBLIC_EXPONENT))
        return KeyFactory.getInstance("RSA").generatePublic(spec)
    }

    private fun toFixedUnsigned(value: BigInteger, size: Int): ByteArray {
        val raw = value.toByteArray()
        val unsigned = if (raw.size == size + 1 && raw[0].toInt() == 0) raw.copyOfRange(1, raw.size) else raw
        require(unsigned.size == size) { "RSA 数值长度异常：${unsigned.size} != $size" }
        return unsigned
    }

    private fun readInt(bytes: ByteArray, offset: Int): Int {
        require(offset >= 0 && offset + 4 <= bytes.size) { "数据长度不足" }
        return ByteBuffer.wrap(bytes, offset, 4).int
    }

    private fun hexToBytes(hex: String): ByteArray {
        require(hex.length == FINGERPRINT_BYTES * 2)
        return ByteArray(FINGERPRINT_BYTES) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    private fun bytesToHex(bytes: ByteArray): String = bytes.joinToString("") { "%02X".format(it.toInt() and 0xFF) }

    fun encode(bytes: ByteArray): String = encoder.encodeToString(bytes)

    fun decode(value: String): ByteArray = runCatching { decoder.decode(value) }
        .getOrElse { throw IllegalArgumentException("Base64 数据损坏", it) }

    private fun isB64Char(c: Char): Boolean =
        (c in 'A'..'Z') || (c in 'a'..'z') || (c in '0'..'9') || c == '-' || c == '_'

    /**
     * Normalizes user-pasted CipherLink text. Chat apps add line wrapping, invisible
     * zero-width characters or surrounding labels. Everything after the recognized prefix
     * that is not part of the URL-safe Base64 alphabet is treated as surrounding text.
     */
    fun normalizeIncoming(value: String): String {
        val stripped = value
            .replace("\u200B", "")
            .replace("\u200C", "")
            .replace("\u200D", "")
            .replace("\uFEFF", "")
            .trim()

        val candidates = listOf(MESSAGE_PREFIX, "CL2Q.", PUBLIC_PREFIX)
            .mapNotNull { prefix ->
                val i = stripped.indexOf(prefix)
                if (i >= 0) i to prefix else null
            }
            .sortedBy { it.first }
        val (_, prefix) = candidates.firstOrNull() ?: throw IllegalArgumentException(
            "不是可识别的 CipherLink 数据：应以 CL2M.、CL2Q. 或 CL2P. 开头。"
        )
        val tail = stripped.substring(stripped.indexOf(prefix) + prefix.length)

        return when (prefix) {
            "CL2Q." -> {
                // CL2Q has dots as structural separators; the payload is URL-safe Base64.
                val compact = tail.filterNot(Char::isWhitespace)
                prefix + compact.takeWhile { isB64Char(it) || it == '.' }
            }
            else -> {
                val encoded = tail.asSequence()
                    .filterNot(Char::isWhitespace)
                    .takeWhile { isB64Char(it) }
                    .joinToString("")
                require(encoded.isNotEmpty()) { "$prefix 内容为空" }
                prefix + encoded
            }
        }
    }
}
