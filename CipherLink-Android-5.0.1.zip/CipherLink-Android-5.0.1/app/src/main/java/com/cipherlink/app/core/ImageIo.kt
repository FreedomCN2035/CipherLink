package com.cipherlink.app.core

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.cipherlink.app.qr.QrCodec
import kotlin.math.roundToInt

/** Image decoding and MediaStore queries shared by the app, the services and the quick-decrypt screen. */
object ImageIo {
    private const val MAX_DIM = 3600

    class MediaRow(val id: Long, val dateAdded: Long, val name: String, val path: String, val uri: Uri) {
        val isScreenshot: Boolean
            get() {
                val n = (name + " " + path).lowercase()
                return listOf("screenshot", "screen_shot", "screenshots", "截屏", "截图", "屏幕截图").any { n.contains(it) }
            }
    }

    /** Newest images first. Pass [sinceSeconds] > 0 to restrict to recently added images. */
    fun queryRecentImages(context: Context, limit: Int, sinceSeconds: Long = 0L): List<MediaRow> {
        val out = ArrayList<MediaRow>()
        val hasPath = Build.VERSION.SDK_INT >= 29
        val projection = if (hasPath) {
            arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.RELATIVE_PATH
            )
        } else {
            arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.DISPLAY_NAME
            )
        }
        val selection = if (sinceSeconds > 0L) "${MediaStore.Images.Media.DATE_ADDED} >= ?" else null
        val args = if (sinceSeconds > 0L) arrayOf(sinceSeconds.toString()) else null
        runCatching {
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                args,
                "${MediaStore.Images.Media.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val pathCol = if (hasPath) cursor.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH) else -1
                while (cursor.moveToNext() && out.size < limit) {
                    val id = cursor.getLong(idCol)
                    out.add(
                        MediaRow(
                            id,
                            cursor.getLong(dateCol),
                            cursor.getString(nameCol) ?: "",
                            if (pathCol >= 0) cursor.getString(pathCol) ?: "" else "",
                            Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                        )
                    )
                }
            }
        }
        return out
    }

    fun decodeScaled(resolver: ContentResolver, uri: Uri): Bitmap {
        // ImageDecoder handles modern providers (cloud photos, HEIF) best.
        if (Build.VERSION.SDK_INT >= 28) {
            val modern = runCatching {
                val source = ImageDecoder.createSource(resolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val w = info.size.width
                    val h = info.size.height
                    val largest = maxOf(w, h).coerceAtLeast(1)
                    if (largest > MAX_DIM) {
                        val scale = MAX_DIM.toDouble() / largest.toDouble()
                        decoder.setTargetSize(
                            (w * scale).roundToInt().coerceAtLeast(1),
                            (h * scale).roundToInt().coerceAtLeast(1)
                        )
                    }
                }
            }.getOrNull()
            if (modern != null) return modern
        }

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        runCatching {
            resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                BitmapFactory.decodeFileDescriptor(pfd.fileDescriptor, null, bounds)
            }
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            runCatching {
                resolver.openInputStream(uri)?.use { input -> BitmapFactory.decodeStream(input, null, bounds) }
            }
        }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "无法打开图片" }

        var sample = 1
        while (maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > MAX_DIM ||
            (bounds.outWidth / sample).toLong() * (bounds.outHeight / sample).toLong() > 16_000_000L
        ) {
            sample *= 2
        }
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bitmap = runCatching {
            resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                BitmapFactory.decodeFileDescriptor(pfd.fileDescriptor, null, options)
            }
        }.getOrNull() ?: runCatching {
            resolver.openInputStream(uri)?.use { input -> BitmapFactory.decodeStream(input, null, options) }
        }.getOrNull()
        return bitmap ?: error("无法解码图片")
    }

    /** Decodes every QR code found in the image. */
    fun decodeQrTexts(resolver: ContentResolver, uri: Uri, deep: Boolean): List<String> {
        val bitmap = decodeScaled(resolver, uri)
        return try {
            QrCodec.decodeAll(bitmap, deep)
        } finally {
            bitmap.recycle()
        }
    }

    /**
     * Looks at the newest images (screenshots first) and returns the QR texts of the first one
     * that contains CipherLink data. Used by the "latest screenshot" button.
     */
    fun scanLatestForCipherLink(context: Context, maxImages: Int = 6): List<String> {
        val recent = queryRecentImages(context, 12)
        val ordered = recent.filter { it.isScreenshot } + recent.filter { !it.isScreenshot }
        for (row in ordered.take(maxImages)) {
            val texts = runCatching { decodeQrTexts(context.contentResolver, row.uri, deep = true) }
                .getOrDefault(emptyList())
            if (texts.any { it.startsWith("CL2") }) return texts
        }
        return emptyList()
    }

    /** Reads only the first bytes of a document (used to recognize .clink files without loading them). */
    fun peekHead(resolver: ContentResolver, uri: Uri, count: Int = 4): ByteArray {
        return runCatching {
            resolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(count)
                var read = 0
                while (read < count) {
                    val n = input.read(buffer, read, count - read)
                    if (n < 0) break
                    read += n
                }
                buffer.copyOf(read)
            }
        }.getOrNull() ?: ByteArray(0)
    }

    /** Reads at most [limit] bytes; throws if the source is larger. */
    fun readBytesLimited(resolver: ContentResolver, uri: Uri, limit: Int): ByteArray {
        resolver.openInputStream(uri)?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(64 * 1024)
            var total = 0
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                total += n
                require(total <= limit) { "文件过大（超过 ${Fmt.size(limit.toLong())}）" }
                out.write(buffer, 0, n)
            }
            return out.toByteArray()
        }
        throw java.io.FileNotFoundException("无法打开所选文件")
    }
}
