package com.cipherlink.app.ui

import android.view.View
import android.widget.ScrollView
import com.cipherlink.app.MainActivity
import com.cipherlink.app.R
import com.cipherlink.app.core.Fmt
import com.cipherlink.app.service.OverlayService
import com.cipherlink.app.storage.AppStore

/** "设置" tab. */
class SettingsTab(private val host: MainActivity) {
    private val ui: Ui get() = host.ui
    private val store: AppStore get() = host.store

    fun build(): View {
        val scroll = ScrollView(host).apply { isFillViewport = true }
        val box = ui.vbox().apply { setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(24)) }

        // ----------------------------------------------------------- security
        box.addView(ui.sectionTitle("安全", "保护你打开 CipherLink 的入口"))
        val security = ui.card()
        val passwordOn = store.isAppPasswordEnabled()
        security.addView(ui.labelValue("启动密码", if (passwordOn) "已开启" else "未开启"))
        val pwRow = ui.hbox()
        pwRow.addView(
            ui.button(if (passwordOn) "修改密码" else "设置启动密码", Ui.BTN_PRIMARY) { host.showSetPasswordDialog() },
            ui.lp(w = 0, weight = 1f, t = 10, r = 5)
        )
        if (passwordOn) {
            pwRow.addView(ui.button("关闭密码") { host.showDisablePasswordDialog() }, ui.lp(w = 0, weight = 1f, t = 10, l = 5))
        }
        security.addView(pwRow)
        if (passwordOn) {
            security.addView(ui.divider())
            security.addView(ui.labelValue("离开后自动锁定", host.autoLockLabel()))
            security.addView(ui.button("更改自动锁定时间") { host.chooseAutoLock() }, ui.lp(t = 8))
        }
        security.addView(ui.divider())
        security.addView(
            ui.switchRow("隐私屏保护", "禁止截屏和录屏，并在最近任务里隐藏预览", store.secureWindow()) { enabled ->
                host.setSecureWindow(enabled)
            }
        )
        security.addView(
            ui.switchRow("通知里显示消息内容", "关闭后通知只提示“收到一条加密消息”（锁屏时始终隐藏）", store.notifyShowContent()) { enabled ->
                store.setNotifyShowContent(enabled)
            }
        )
        box.addView(security)

        // -------------------------------------------------------- quick access
        box.addView(ui.sectionTitle("快捷入口", "不用打开 App，也能加密发送、接收解密"))
        val quick = ui.card()
        quick.addView(
            ui.switchRow("通知栏快捷输入", "下拉通知栏即可输入明文加密，或粘贴密文解密", store.isQuickNotificationEnabled()) { enabled ->
                host.setQuickNotification(enabled)
            }
        )
        quick.addView(
            ui.switchRow("悬浮窗", "可拖动的悬浮球，点开就是发送/解密面板", OverlayService.running) { enabled ->
                host.setOverlay(enabled)
            }
        )
        quick.addView(ui.divider())
        quick.addView(
            ui.muted(
                "CipherLink 只使用一条通知：里面有加密发送框、解密框，以及最新收到的解密结果；自动解密和悬浮窗也共用这一条，不会另外弹通知。\n\n" +
                    "小技巧：在聊天软件里长按选中密文，菜单里的“CipherLink 解密”可一键解密；把二维码图片或 .clink 文件“分享”给 CipherLink 也行。",
                12f
            ).apply { setLineSpacing(0f, 1.15f) }
        )
        box.addView(quick)

        // ------------------------------------------------------- auto decrypt
        box.addView(ui.sectionTitle("自动解密", "只有发给你的有效密文才会提示，其他内容一律忽略，同一条消息只提示一次"))
        val monitor = ui.card()
        monitor.addView(
            ui.switchRow("监听剪贴板", "复制密文后自动解密并弹出结果", store.monitorClipboardEnabled()) { enabled ->
                host.setClipboardMonitor(enabled)
            }
        )
        monitor.addView(
            ui.switchRow("监听新保存的二维码图片", "截图或保存二维码后自动识别并解密", store.monitorQrEnabled()) { enabled ->
                host.setQrMonitor(enabled)
            }
        )
        monitor.addView(ui.divider())
        monitor.addView(
            ui.muted(
                "Android 10 以后系统不允许 App 在后台读取剪贴板内容，所以后台监听剪贴板可能不生效——这是系统限制，不是故障。" +
                    "不受限制的做法：打开 CipherLink 时会自动检查；或点通知栏/悬浮窗里的“解密剪贴板”，一步完成。",
                12f
            ).apply { setLineSpacing(0f, 1.15f) }
        )
        monitor.addView(ui.button("后台保活设置（防止被系统杀掉）") { host.openBatterySettings() }, ui.lp(t = 10))
        box.addView(monitor)

        // ---------------------------------------------------------------- key
        box.addView(ui.sectionTitle("我的密钥", "私钥由 Android 安全存储保护，不会导出"))
        val key = ui.card()
        val fp = store.myFingerprint()
        key.addView(
            ui.labelValue(
                "状态",
                when (store.identityState()) {
                    AppStore.IdentityState.READY -> "RSA-3072 · " + Fmt.fingerprint(fp.orEmpty())
                    AppStore.IdentityState.NONE -> "尚未创建"
                    AppStore.IdentityState.CORRUPT -> "密钥数据异常"
                },
                true
            )
        )
        key.addView(ui.button("重新生成密钥", Ui.BTN_DANGER) { host.confirmRegenerate() }, ui.lp(t = 10))
        box.addView(key)

        // --------------------------------------------------------------- data
        box.addView(ui.sectionTitle("数据"))
        val data = ui.card()
        data.addView(ui.labelValue("收件箱", "${store.historyList().size} 条（本机加密保存，最多 100 条）"))
        data.addView(ui.button("清空收件箱", Ui.BTN_DANGER) { host.clearInbox() }, ui.lp(t = 10))
        box.addView(data)

        // -------------------------------------------------------------- about
        box.addView(ui.sectionTitle("关于 CipherLink"))
        val about = ui.card()
        about.addView(
            ui.text(
                "版本 ${host.versionName()}\n\n" +
                    "• 没有网络权限，没有服务器；加解密全部在本机完成\n" +
                    "• 加密：RSA-3072-OAEP（SHA-256）封装随机 AES-256-GCM 密钥\n" +
                    "• 身份：每条消息带发送方公钥与 RSA 签名，防篡改、防冒充\n" +
                    "• 二维码：先加密签名，再分片；收齐并整包校验后才解密\n" +
                    "• 附件：同一套加密，最大 10 MB，保存时本机再加密一次\n" +
                    "• 首次建钥：用户触摸与时间戳作为额外熵，系统 SecureRandom 仍是主随机源\n" +
                    "• 聊天软件、剪贴板和截图属于系统外部环境，请注意周围人和其他 App",
                12f, R.color.cl_muted
            ).apply { setLineSpacing(0f, 1.2f) }
        )
        box.addView(about)

        scroll.addView(box)
        return scroll
    }
}
