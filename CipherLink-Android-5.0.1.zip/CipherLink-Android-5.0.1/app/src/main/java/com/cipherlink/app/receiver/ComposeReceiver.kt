package com.cipherlink.app.receiver

import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.cipherlink.app.core.Clip
import com.cipherlink.app.core.Fmt
import com.cipherlink.app.core.Inbox
import com.cipherlink.app.core.Notifier
import com.cipherlink.app.crypto.CryptoEngine
import com.cipherlink.app.storage.AppStore
import java.util.concurrent.Executors

/** Handles the two input boxes (send / decrypt) of the CipherLink notification. */
class ComposeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val key = when (action) {
            ACTION_SEND -> KEY_SEND
            ACTION_DECRYPT -> KEY_DECRYPT
            else -> return
        }
        val pending = goAsync()
        val input = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(key)?.toString()?.trim().orEmpty()
        EXECUTOR.execute {
            try {
                if (input.isEmpty()) {
                    // Always update the notification: otherwise Android keeps the "sending" spinner.
                    Notifier.updateQuick(context, "没有输入内容", "请先输入内容再点发送")
                } else if (action == ACTION_SEND) {
                    send(context, input)
                } else {
                    decrypt(context, input)
                }
            } catch (t: Throwable) {
                Notifier.updateQuick(context, "操作失败", Inbox.describe(t))
            } finally {
                pending.finish()
            }
        }
    }

    private fun send(context: Context, text: String) {
        val store = AppStore(context)
        val identity = store.loadIdentity() ?: throw IllegalStateException("本机密钥不可用，请打开 CipherLink 检查")
        val contact = store.activeContact() ?: throw IllegalStateException("请先在 CipherLink 选择收件人")
        val recipient = CryptoEngine.parsePublicKeyCard(contact.publicKeyCard).key
        val encrypted = CryptoEngine.encrypt(text, recipient, identity)
        Clip.copyText(context, encrypted, "CipherLink encrypted message")
        Notifier.updateQuick(
            context,
            "✓ 已加密并复制",
            "收件人：${contact.name}\n密文（${encrypted.length} 字符）已在剪贴板，去聊天软件长按粘贴发送即可。"
        )
    }

    private fun decrypt(context: Context, input: String) {
        when (val outcome = Inbox.processText(context, input, "通知栏", Inbox.Mode.MANUAL)) {
            is Inbox.Outcome.Decrypted -> {
                val item = outcome.item
                val from = Fmt.senderLabel(item.senderName, item.senderFp)
                if (item.isFile) {
                    Notifier.updateQuick(
                        context, "✓ 收到加密文件 · $from",
                        "${item.fileName}（${Fmt.size(item.fileSize)}）\n打开 CipherLink 保存或查看"
                    )
                } else {
                    val text = item.text.orEmpty()
                    val shown = if (!AppStore(context).notifyShowContent()) {
                        "已解密，点按打开 CipherLink 查看"
                    } else if (text.length > 3500) {
                        text.take(3500) + "\n…（已截断）"
                    } else {
                        text
                    }
                    Notifier.updateQuick(context, "✓ 已解密 · $from", shown)
                }
            }
            is Inbox.Outcome.PublicKeyCard ->
                Notifier.updateQuick(context, "这是公钥，不是密文", "请打开 CipherLink → 联系人 → 添加联系人")
            is Inbox.Outcome.Progress ->
                Notifier.updateQuick(
                    context, "二维码分片未收齐",
                    "已收到 ${outcome.received}/${outcome.total} 张，缺少第 ${outcome.missing.joinToString("、")} 张"
                )
            is Inbox.Outcome.Failed ->
                Notifier.updateQuick(context, "解密失败", Inbox.describe(outcome.error))
            Inbox.Outcome.Ignored ->
                Notifier.updateQuick(context, "无法识别", "请粘贴以 CL2M. 开头的密文")
        }
    }

    companion object {
        const val ACTION_SEND = "com.cipherlink.app.action.NOTIFY_SEND"
        const val ACTION_DECRYPT = "com.cipherlink.app.action.NOTIFY_DECRYPT"
        const val KEY_SEND = "cipherlink_notify_send"
        const val KEY_DECRYPT = "cipherlink_notify_decrypt"
        private val EXECUTOR = Executors.newSingleThreadExecutor()
    }
}
