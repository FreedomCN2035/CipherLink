package com.cipherlink.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.cipherlink.app.core.Monitor
import com.cipherlink.app.core.Notifier
import com.cipherlink.app.storage.AppStore

/** Restores the quick notification and the background monitor after a reboot or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val store = AppStore(context)
        if (store.identityState() != AppStore.IdentityState.READY) return
        if (store.isQuickNotificationEnabled()) {
            runCatching { Notifier.postQuick(context) }
        }
        runCatching { Monitor.sync(context) }
    }
}
