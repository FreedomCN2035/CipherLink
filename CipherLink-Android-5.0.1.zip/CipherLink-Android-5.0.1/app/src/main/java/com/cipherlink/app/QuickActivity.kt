package com.cipherlink.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.cipherlink.app.core.Clip
import com.cipherlink.app.core.ImageIo
import com.cipherlink.app.core.Inbox
import com.cipherlink.app.core.Uris
import com.cipherlink.app.crypto.CryptoEngine
import com.cipherlink.app.storage.AppStore
import com.cipherlink.app.ui.Dialogs
import java.util.concurrent.Executors

/**
 * Transparent one-tap decrypt screen. It appears over whatever app is in front, shows the
 * result in a small dialog, and disappears. Entry points:
 *  - "解密剪贴板" button in the notification / floating window (ACTION_CLIPBOARD);
 *  - selected text -> "CipherLink 解密" in the text-selection menu (PROCESS_TEXT);
 *  - sharing text, a QR image or a .clink file to "CipherLink 解密" (SEND / VIEW).
 * Being a focused activity is also what allows reading the clipboard on Android 10+.
 */
class QuickActivity : Activity() {
    private lateinit var store: AppStore
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var handled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = AppStore(this)
        // Fallback in case the window never reports focus (some launchers / split-screen states).
        mainHandler.postDelayed({ runOnce() }, 700L)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) runOnce()
    }

    private fun runOnce() {
        if (handled || isFinishing) return
        handled = true
        handle(intent)
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun close() {
        if (!isFinishing) finish()
    }

    private fun handle(incoming: Intent?) {
        if (incoming == null) {
            close()
            return
        }
        if (store.identityState() != AppStore.IdentityState.READY) {
            Dialogs.message(this, "还没有密钥", "请先打开 CipherLink 创建你的密钥。") { close() }
            return
        }
        when (incoming.action) {
            ACTION_CLIPBOARD -> {
                val text = Clip.readText(this)
                if (text == null) {
                    toast("剪贴板是空的，或系统未允许读取")
                    close()
                } else {
                    processTexts(listOf(text), "剪贴板")
                }
            }
            Intent.ACTION_PROCESS_TEXT -> {
                val text = incoming.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
                if (text.isNullOrBlank()) close() else processTexts(listOf(text), "选中的文字")
            }
            Intent.ACTION_SEND -> {
                val stream = Uris.stream(incoming)
                if (stream != null) {
                    processUri(stream, "分享的内容")
                } else {
                    val text = incoming.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                    if (text.isNullOrBlank()) close() else processTexts(listOf(text), "分享的文字")
                }
            }
            Intent.ACTION_VIEW -> {
                val uri = incoming.data
                if (uri == null) close() else processUri(uri, "打开的文件")
            }
            else -> close()
        }
    }

    private fun processTexts(texts: List<String>, source: String) {
        executor.execute {
            val outcome = try {
                Inbox.processTexts(this, texts, source, Inbox.Mode.MANUAL)
            } catch (t: Throwable) {
                Inbox.Outcome.Failed(t)
            }
            mainHandler.post { present(outcome) }
        }
    }

    private fun processUri(uri: Uri, source: String) {
        toast("正在识别…")
        executor.execute {
            val outcome = try {
                val head = ImageIo.peekHead(contentResolver, uri, 4)
                if (CryptoEngine.hasFileMagic(head)) {
                    val bytes = ImageIo.readBytesLimited(contentResolver, uri, CryptoEngine.MAX_FILE_BYTES)
                    Inbox.processFileBytes(this, bytes, source, Inbox.Mode.MANUAL)
                } else {
                    val texts = ImageIo.decodeQrTexts(contentResolver, uri, true)
                    if (texts.isEmpty()) {
                        Inbox.Outcome.Failed(IllegalStateException("没有在这张图片里识别到二维码"))
                    } else {
                        Inbox.processTexts(this, texts, source, Inbox.Mode.MANUAL)
                    }
                }
            } catch (t: Throwable) {
                Inbox.Outcome.Failed(t)
            }
            mainHandler.post { present(outcome) }
        }
    }

    private fun openApp() {
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(MainActivity.EXTRA_OPEN_INBOX, true)
        startActivity(open)
    }

    private fun present(outcome: Inbox.Outcome) {
        if (!Dialogs.isAlive(this)) return
        when (outcome) {
            is Inbox.Outcome.Decrypted -> {
                val item = outcome.item
                val builder = AlertDialog.Builder(this)
                    .setTitle(if (item.isFile) "收到加密文件" else "收到加密消息")
                    .setView(Dialogs.decryptedContent(this, store, item))
                    .setNegativeButton("关闭", null)
                if (item.isFile) {
                    builder.setPositiveButton("在 CipherLink 中保存/打开") { _, _ -> openApp() }
                } else {
                    builder.setPositiveButton("复制") { _, _ ->
                        Clip.copyText(this, item.text.orEmpty())
                        toast("已复制")
                    }
                    builder.setNeutralButton("打开 CipherLink") { _, _ -> openApp() }
                }
                builder.setOnDismissListener { close() }
                builder.show()
            }
            is Inbox.Outcome.PublicKeyCard ->
                Dialogs.importPublicKey(this, store, outcome.card, "", { close() }) {}
            is Inbox.Outcome.Progress -> {
                toast("二维码已收到 ${outcome.received}/${outcome.total} 张，缺少第 ${outcome.missing.joinToString("、")} 张")
                close()
            }
            is Inbox.Outcome.Failed ->
                Dialogs.error(this, "解密失败", outcome.error) { close() }
            Inbox.Outcome.Ignored -> {
                toast("没有发现可解密的 CipherLink 内容")
                close()
            }
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        executor.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_CLIPBOARD = "com.cipherlink.app.action.DECRYPT_CLIPBOARD"
    }
}
