package com.cipherlink.app.core

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Small formatting helpers shared by the UI and notifications. */
object Fmt {
    fun size(bytes: Long): String = when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
    }

    /** "今天 14:32", "昨天 09:10", "10-08 22:41". */
    fun time(ts: Long): String {
        if (ts <= 0L) return ""
        val now = Calendar.getInstance()
        val then = Calendar.getInstance().apply { timeInMillis = ts }
        val clock = SimpleDateFormat("HH:mm", Locale.US).format(Date(ts))
        val sameYear = now.get(Calendar.YEAR) == then.get(Calendar.YEAR)
        val dayDiff = now.get(Calendar.DAY_OF_YEAR) - then.get(Calendar.DAY_OF_YEAR)
        return when {
            sameYear && dayDiff == 0 -> "今天 $clock"
            sameYear && dayDiff == 1 -> "昨天 $clock"
            sameYear -> SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date(ts))
            else -> SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(ts))
        }
    }

    /** "A1B2 C3D4 E5F6 ..." - easier to compare out loud than one long hex string. */
    fun fingerprint(fp: String): String = fp.chunked(4).joinToString(" ")

    /** Short form for tight spaces: first 8 hex characters. */
    fun fingerprintShort(fp: String): String = fp.take(8)

    fun senderLabel(name: String?, fp: String): String =
        if (!name.isNullOrBlank()) name else "未知发送方 · ${fingerprintShort(fp)}"
}
