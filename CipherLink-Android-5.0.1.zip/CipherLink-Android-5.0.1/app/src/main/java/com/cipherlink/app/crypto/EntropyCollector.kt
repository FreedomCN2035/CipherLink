package com.cipherlink.app.crypto

import android.view.MotionEvent
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.nio.ByteBuffer
import java.security.MessageDigest

/**
 * Collects user interaction noise to supplement Android's OS CSPRNG.
 * The collected gestures are never used instead of SecureRandom.
 */
class EntropyCollector {
    private val lock = Any()
    private val bytes = ByteArrayOutputStream(16 * 1024)
    private var eventCount = 0
    private var startedAtNanos: Long? = null

    fun add(event: MotionEvent) {
        synchronized(lock) {
            if (bytes.size() > 24 * 1024) return
            if (startedAtNanos == null) startedAtNanos = System.nanoTime()
            val record = ByteArrayOutputStream(40)
            DataOutputStream(record).use { out ->
                out.writeInt(event.actionMasked)
                out.writeInt(event.pointerCount)
                out.writeFloat(event.rawX)
                out.writeFloat(event.rawY)
                out.writeLong(event.eventTime)
                out.writeLong(System.nanoTime())
                out.writeLong(System.currentTimeMillis())
            }
            bytes.write(record.toByteArray())
            eventCount++
        }
    }

    fun count(): Int = synchronized(lock) { eventCount }

    fun elapsedMs(): Long = synchronized(lock) {
        val start = startedAtNanos ?: return@synchronized 0L
        ((System.nanoTime() - start) / 1_000_000L).coerceAtLeast(0)
    }

    fun snapshotDigest(): ByteArray = synchronized(lock) {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(ByteBuffer.allocate(16)
            .putLong(System.currentTimeMillis())
            .putLong(System.nanoTime())
            .array())
        md.update(bytes.toByteArray())
        md.update(ByteBuffer.allocate(8).putLong(eventCount.toLong()).array())
        md.digest()
    }

    fun reset() = synchronized(lock) {
        bytes.reset()
        eventCount = 0
        startedAtNanos = null
    }
}
