package com.cipherlink.app.core

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.PersistableBundle

/** Clipboard helpers. Everything CipherLink puts on the clipboard is flagged as sensitive. */
object Clip {
    private const val EXTRA_IS_SENSITIVE = "android.content.extra.IS_SENSITIVE"

    private fun manager(context: Context): ClipboardManager =
        context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    fun copyText(context: Context, text: String, label: String = "CipherLink") {
        val clip = ClipData.newPlainText(label, text)
        clip.description.extras = PersistableBundle().apply { putBoolean(EXTRA_IS_SENSITIVE, true) }
        manager(context).setPrimaryClip(clip)
    }

    fun copyUri(context: Context, uri: Uri, label: String) {
        val clip = ClipData.newUri(context.contentResolver, label, uri)
        clip.description.extras = PersistableBundle().apply { putBoolean(EXTRA_IS_SENSITIVE, true) }
        manager(context).setPrimaryClip(clip)
    }

    /**
     * Reads the clipboard text. Android 10+ only returns data to the app that currently has
     * input focus (or the default keyboard), so call this from a focused window.
     */
    fun readText(context: Context): String? {
        val clip = runCatching { manager(context).primaryClip }.getOrNull() ?: return null
        if (clip.itemCount == 0) return null
        return runCatching { clip.getItemAt(0).coerceToText(context)?.toString() }
            .getOrNull()?.takeIf { it.isNotBlank() }
    }

    /**
     * When the current clip was copied (ms since epoch), or 0 if unknown. Reading only the
     * description never exposes clip data and is allowed in the background.
     */
    fun currentTimestamp(context: Context): Long {
        val description = runCatching { manager(context).primaryClipDescription }.getOrNull() ?: return 0L
        return runCatching { description.timestamp }.getOrDefault(0L)
    }

    fun currentIsText(context: Context): Boolean {
        val description = runCatching { manager(context).primaryClipDescription }.getOrNull() ?: return false
        return description.hasMimeType("text/*")
    }
}
