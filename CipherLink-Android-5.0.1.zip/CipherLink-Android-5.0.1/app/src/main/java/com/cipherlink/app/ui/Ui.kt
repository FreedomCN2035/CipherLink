package com.cipherlink.app.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.cipherlink.app.R

/**
 * Tiny view toolkit so every screen (activity, floating window, quick dialogs) looks the same.
 * Works with any Context; colors come from resources so dark mode works everywhere.
 */
class Ui(val ctx: Context) {
    private val density = ctx.resources.displayMetrics.density

    fun dp(v: Int): Int = (v * density + 0.5f).toInt()
    fun color(res: Int): Int = ctx.getColor(res)

    fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusDp * density
    }

    fun outlined(fill: Int, stroke: Int, radiusDp: Int): GradientDrawable = rounded(fill, radiusDp).apply {
        setStroke(dp(1), stroke)
    }

    fun ripple(content: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x22000000), content, null)

    /** Width/height are raw pixels or MATCH/WRAP; margins are in dp. */
    fun lp(
        w: Int = MATCH, h: Int = WRAP, weight: Float = 0f,
        l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0
    ): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    fun vbox(): LinearLayout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    fun hbox(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun text(
        value: CharSequence,
        sizeSp: Float = 14f,
        colorRes: Int = R.color.cl_text,
        bold: Boolean = false
    ): TextView = TextView(ctx).apply {
        text = value
        textSize = sizeSp
        setTextColor(color(colorRes))
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    fun muted(value: CharSequence, sizeSp: Float = 12f): TextView = text(value, sizeSp, R.color.cl_muted)

    fun mono(value: CharSequence, sizeSp: Float = 12f): TextView = text(value, sizeSp, R.color.cl_text).apply {
        typeface = Typeface.MONOSPACE
        setTextIsSelectable(true)
    }

    fun chip(value: String, fgRes: Int, bgRes: Int): TextView = TextView(ctx).apply {
        text = value
        textSize = 11f
        setTextColor(color(fgRes))
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(color(bgRes), 10)
        setPadding(dp(8), dp(3), dp(8), dp(3))
    }

    fun card(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(color(R.color.cl_surface), 20)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) }
    }

    fun sectionTitle(title: String, subtitle: String? = null): View {
        val box = vbox().apply { setPadding(dp(4), dp(10), dp(4), dp(8)) }
        box.addView(text(title, 18f, R.color.cl_text, true))
        if (!subtitle.isNullOrEmpty()) box.addView(muted(subtitle), lp(t = 2))
        return box
    }

    fun divider(): View = View(ctx).apply {
        setBackgroundColor(color(R.color.cl_divider))
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(12) }
    }

    fun button(label: String, kind: Int = BTN_SECONDARY, onClick: () -> Unit): Button = Button(ctx).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        minWidth = 0
        minimumWidth = 0
        minHeight = dp(44)
        minimumHeight = dp(44)
        gravity = Gravity.CENTER
        stateListAnimator = null
        val fill: Int
        val fg: Int
        when (kind) {
            BTN_PRIMARY -> { fill = color(R.color.cl_primary); fg = color(R.color.cl_on_primary) }
            BTN_DANGER -> { fill = color(R.color.cl_danger_soft); fg = color(R.color.cl_danger) }
            BTN_GHOST -> { fill = 0x00000000; fg = color(R.color.cl_primary) }
            else -> { fill = color(R.color.cl_btn); fg = color(R.color.cl_text) }
        }
        background = ripple(rounded(fill, 14))
        // Padding must be set after the background, otherwise the drawable can reset it to zero.
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setTextColor(fg)
        setOnClickListener { onClick() }
    }

    fun input(hint: String, minLines: Int = 1, maxLines: Int = 1, password: Boolean = false): EditText = EditText(ctx).apply {
        this.hint = hint
        setHintTextColor(color(R.color.cl_muted))
        setTextColor(color(R.color.cl_text))
        textSize = 15f
        background = rounded(color(R.color.cl_input), 14)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        if (password) {
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else if (maxLines <= 1) {
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
        } else {
            this.minLines = minLines
            this.maxLines = maxLines
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
    }

    fun switchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val row = hbox().apply { setPadding(0, dp(6), 0, dp(6)) }
        val texts = vbox()
        texts.addView(text(title, 15f, R.color.cl_text, true))
        if (!subtitle.isNullOrEmpty()) texts.addView(muted(subtitle), lp(t = 2))
        row.addView(texts, lp(w = 0, weight = 1f, r = 12))
        val toggle = Switch(ctx)
        toggle.isChecked = checked
        toggle.setOnCheckedChangeListener { _, value -> onChange(value) }
        row.addView(toggle, lp(w = WRAP))
        return row
    }

    fun labelValue(title: String, value: String, mono: Boolean = false): View {
        val box = vbox()
        box.addView(muted(title))
        val v = text(value, 14f, R.color.cl_text, true).apply {
            if (mono) typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        box.addView(v, lp(t = 3))
        return box
    }

    companion object {
        const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
        const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT
        const val BTN_PRIMARY = 0
        const val BTN_SECONDARY = 1
        const val BTN_DANGER = 2
        const val BTN_GHOST = 3
    }
}
