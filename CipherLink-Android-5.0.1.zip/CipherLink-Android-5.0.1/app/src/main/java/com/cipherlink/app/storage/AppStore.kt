package com.cipherlink.app.storage

import android.content.Context
import com.cipherlink.app.crypto.CryptoEngine
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyFactory
import java.security.KeyPair
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * All persistent state. Safe to instantiate anywhere (activity, service, receiver):
 * instances are cheap and share process-wide caches.
 */
class AppStore(context: Context) {
    private val appContext: Context = context.applicationContext ?: context
    private val prefs = appContext.getSharedPreferences("cipherlink_store_v3", Context.MODE_PRIVATE)
    private val vault = KeyStoreVault()

    enum class IdentityState { NONE, READY, CORRUPT }

    data class Contact(val id: String, val name: String, val publicKeyCard: String)

    data class HistoryItem(
        val id: String,
        val digest: String,
        val kind: Int,
        val time: Long,
        val senderFp: String,
        val senderName: String?,
        val senderCard: String?,
        val source: String,
        val text: String?,
        val fileName: String?,
        val fileMime: String?,
        val fileSize: Long,
        val fileStored: String?,
        val fileKey: String?
    ) {
        val isFile: Boolean get() = kind == KIND_FILE
    }

    data class StoredFile(val storedName: String, val wrappedKey: String)

    // ---------------------------------------------------------------- identity

    fun identityState(): IdentityState {
        if (cachedIdentity != null) return IdentityState.READY
        val public = prefs.getString(KEY_PUBLIC, null)
        val private = prefs.getString(KEY_PRIVATE, null)
        if (public == null && private == null) return IdentityState.NONE
        if (public == null || private == null) return IdentityState.CORRUPT
        return runCatching { loadIdentityStrict() }.fold(
            onSuccess = { IdentityState.READY },
            onFailure = { IdentityState.CORRUPT }
        )
    }

    fun hasIdentity(): Boolean = identityState() == IdentityState.READY

    fun loadIdentity(): KeyPair? = runCatching { loadIdentityStrict() }.getOrNull()

    fun loadIdentityStrict(): KeyPair {
        cachedIdentity?.let { return it }
        synchronized(IDENTITY_LOCK) {
            cachedIdentity?.let { return it }
            val pubText = prefs.getString(KEY_PUBLIC, null) ?: throw IllegalStateException("本机没有公钥")
            val encPrivateText = prefs.getString(KEY_PRIVATE, null) ?: throw IllegalStateException("本机没有私钥")
            val pub = decodePublicKey(pubText)
            val privateBytes = vault.decrypt(fromB64(encPrivateText))
            val privateKey = decodePrivateKey(privateBytes)
            val pair = KeyPair(pub, privateKey)
            require(CryptoEngine.isMatchingKeyPair(pair)) { "本机公钥与私钥不是同一套密钥；请在设置中重新生成" }
            cachedIdentity = pair
            return pair
        }
    }

    fun saveIdentity(keyPair: KeyPair) {
        require(CryptoEngine.isMatchingKeyPair(keyPair))
        val encryptedPrivate = vault.encrypt(keyPair.private.encoded)
        synchronized(IDENTITY_LOCK) {
            prefs.edit()
                .putString(KEY_PUBLIC, b64(keyPair.public.encoded))
                .putString(KEY_PRIVATE, b64(encryptedPrivate))
                .putString(KEY_PUBLIC_CARD, CryptoEngine.buildPublicKeyCard(keyPair.public))
                .putString(KEY_FINGERPRINT, CryptoEngine.fingerprint(keyPair.public))
                .commit()
            cachedIdentity = keyPair
        }
    }

    /** Explicit destructive reset. Never called automatically on load failure. */
    fun eraseIdentityPermanently() {
        synchronized(IDENTITY_LOCK) {
            prefs.edit().remove(KEY_PUBLIC).remove(KEY_PRIVATE).remove(KEY_PUBLIC_CARD).remove(KEY_FINGERPRINT).commit()
            cachedIdentity = null
            // The vault key is kept on purpose: it also protects the already-decrypted inbox.
        }
    }

    fun publicKeyCard(): String? {
        val card = prefs.getString(KEY_PUBLIC_CARD, null)
        if (!card.isNullOrBlank()) return card
        return loadIdentity()?.let { key ->
            CryptoEngine.buildPublicKeyCard(key.public).also { prefs.edit().putString(KEY_PUBLIC_CARD, it).apply() }
        }
    }

    fun myFingerprint(): String? {
        val fp = prefs.getString(KEY_FINGERPRINT, null)
        if (!fp.isNullOrBlank()) return fp
        return loadIdentity()?.let { key ->
            CryptoEngine.fingerprint(key.public).also { prefs.edit().putString(KEY_FINGERPRINT, it).apply() }
        }
    }

    // ---------------------------------------------------------------- contacts

    fun activeContactId(): String? = prefs.getString(KEY_ACTIVE, null)

    fun setActiveContact(id: String?) {
        prefs.edit().apply {
            if (id == null) remove(KEY_ACTIVE) else putString(KEY_ACTIVE, id)
        }.commit()
    }

    fun listContacts(): List<Contact> {
        val raw = prefs.getString(KEY_CONTACTS, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            val out = ArrayList<Contact>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Contact(o.getString("id"), o.optString("name", "未命名联系人"), o.getString("key")))
            }
            out.toList()
        }.getOrDefault(emptyList())
    }

    private fun writeContacts(contacts: List<Contact>) {
        val arr = JSONArray()
        contacts.forEach { c -> arr.put(JSONObject().put("id", c.id).put("name", c.name).put("key", c.publicKeyCard)) }
        prefs.edit().putString(KEY_CONTACTS, arr.toString()).commit()
    }

    fun upsertContact(contact: Contact) {
        val contacts = listContacts().filterNot { it.id == contact.id }.toMutableList()
        contacts.add(contact)
        writeContacts(contacts)
    }

    fun renameContact(id: String, name: String) {
        writeContacts(listContacts().map { if (it.id == id) it.copy(name = name) else it })
    }

    fun deleteContact(id: String) {
        val contacts = listContacts().filterNot { it.id == id }
        writeContacts(contacts)
        if (activeContactId() == id) setActiveContact(contacts.firstOrNull()?.id)
    }

    fun activeContact(): Contact? = activeContactId()?.let { id -> listContacts().firstOrNull { it.id == id } }

    fun findContact(id: String): Contact? = listContacts().firstOrNull { it.id == id }

    /** Contacts parsed into the form needed to pin sender identities while decrypting. */
    fun trustedContacts(): Map<String, CryptoEngine.TrustedContact> {
        val out = LinkedHashMap<String, CryptoEngine.TrustedContact>()
        listContacts().forEach { contact ->
            runCatching {
                val parsed = CryptoEngine.parsePublicKeyCard(contact.publicKeyCard)
                out[parsed.id] = CryptoEngine.TrustedContact(contact.name, parsed.key)
            }
        }
        return out
    }

    // ---------------------------------------------------------------- password

    fun isAppPasswordEnabled(): Boolean = prefs.getString(KEY_APP_PASSWORD_HASH, null).isNullOrBlank().not()

    fun setAppPassword(password: String) {
        require(password.length >= 6) { "启动密码至少 6 位" }
        val salt = ByteArray(PASSWORD_SALT_BYTES).also(SecureRandom()::nextBytes)
        val hash = derivePassword(password, salt, PASSWORD_ITERATIONS)
        prefs.edit()
            .putString(KEY_APP_PASSWORD_SALT, b64(salt))
            .putString(KEY_APP_PASSWORD_HASH, b64(hash))
            .putInt(KEY_APP_PASSWORD_ITERATIONS, PASSWORD_ITERATIONS)
            .remove(KEY_PW_FAILS)
            .remove(KEY_PW_LOCK_UNTIL)
            .commit()
    }

    fun verifyAppPassword(password: String): Boolean {
        val saltText = prefs.getString(KEY_APP_PASSWORD_SALT, null) ?: return false
        val hashText = prefs.getString(KEY_APP_PASSWORD_HASH, null) ?: return false
        val iterations = prefs.getInt(KEY_APP_PASSWORD_ITERATIONS, PASSWORD_ITERATIONS)
        return runCatching {
            val actual = derivePassword(password, fromB64(saltText), iterations)
            MessageDigest.isEqual(actual, fromB64(hashText))
        }.getOrDefault(false)
    }

    fun disableAppPassword() {
        prefs.edit()
            .remove(KEY_APP_PASSWORD_SALT)
            .remove(KEY_APP_PASSWORD_HASH)
            .remove(KEY_APP_PASSWORD_ITERATIONS)
            .remove(KEY_PW_FAILS)
            .remove(KEY_PW_LOCK_UNTIL)
            .commit()
    }

    /** Milliseconds the unlock screen must still wait after too many wrong attempts. */
    fun passwordLockRemainingMs(): Long =
        (prefs.getLong(KEY_PW_LOCK_UNTIL, 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    fun recordPasswordFailure() {
        val fails = prefs.getInt(KEY_PW_FAILS, 0) + 1
        val editor = prefs.edit().putInt(KEY_PW_FAILS, fails)
        if (fails >= 5) {
            // 30 s after the 5th failure, doubling each further failure, capped at 1 hour.
            val steps = (fails - 5).coerceAtMost(7)
            val waitMs = (30_000L shl steps).coerceAtMost(3_600_000L)
            editor.putLong(KEY_PW_LOCK_UNTIL, System.currentTimeMillis() + waitMs)
        }
        editor.commit()
    }

    fun clearPasswordFailures() {
        prefs.edit().remove(KEY_PW_FAILS).remove(KEY_PW_LOCK_UNTIL).commit()
    }

    // ------------------------------------------------- one-time processing log

    fun isProcessed(digest: String): Boolean = synchronized(PROCESSED_LOCK) { readProcessed().contains(digest) }

    /**
     * Atomically claims a payload digest. Returns true only for the first caller, so the
     * same ciphertext is never handled twice - across clipboard, QR, restarts and manual use.
     */
    fun claimProcessed(digest: String): Boolean {
        synchronized(PROCESSED_LOCK) {
            val digests = readProcessed()
            if (!digests.add(digest)) return false
            while (digests.size > MAX_PROCESSED_PAYLOADS) {
                digests.remove(digests.first())
            }
            val updated = JSONArray()
            digests.forEach(updated::put)
            prefs.edit().putString(KEY_PROCESSED_PAYLOADS, updated.toString()).commit()
            return true
        }
    }

    private fun readProcessed(): LinkedHashSet<String> {
        val raw = prefs.getString(KEY_PROCESSED_PAYLOADS, "[]") ?: "[]"
        val arr = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val digests = LinkedHashSet<String>()
        for (i in 0 until arr.length()) {
            arr.optString(i).takeIf { it.isNotBlank() }?.let { digests.add(it) }
        }
        return digests
    }

    // ----------------------------------------------------------------- history

    private fun historyFile(): File = File(appContext.filesDir, "history_v1.bin")
    private fun inboxDir(): File = File(appContext.filesDir, "inbox").also { it.mkdirs() }

    fun historyList(): List<HistoryItem> = synchronized(HISTORY_LOCK) { readHistory() }

    fun findHistory(digest: String): HistoryItem? = historyList().firstOrNull { it.digest == digest }

    fun findHistoryById(id: String): HistoryItem? = historyList().firstOrNull { it.id == id }

    fun addHistory(item: HistoryItem) {
        synchronized(HISTORY_LOCK) {
            val list = readHistory().toMutableList()
            list.add(0, item)
            while (list.size > MAX_HISTORY) {
                val removed = list.removeAt(list.size - 1)
                deleteStoredFile(removed)
            }
            writeHistory(list)
        }
    }

    fun deleteHistory(id: String) {
        synchronized(HISTORY_LOCK) {
            val list = readHistory()
            list.firstOrNull { it.id == id }?.let { deleteStoredFile(it) }
            writeHistory(list.filterNot { it.id == id })
        }
    }

    fun clearHistory() {
        synchronized(HISTORY_LOCK) {
            readHistory().forEach { deleteStoredFile(it) }
            writeHistory(emptyList())
        }
    }

    private fun deleteStoredFile(item: HistoryItem) {
        item.fileStored?.let { name -> runCatching { File(inboxDir(), File(name).name).delete() } }
    }

    private fun readHistory(): MutableList<HistoryItem> {
        val file = historyFile()
        if (!file.exists()) return ArrayList()
        return runCatching {
            val json = String(vault.decrypt(file.readBytes()), Charsets.UTF_8)
            val arr = JSONArray(json)
            val out = ArrayList<HistoryItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    HistoryItem(
                        id = o.getString("id"),
                        digest = o.getString("digest"),
                        kind = o.optInt("kind", KIND_TEXT),
                        time = o.optLong("time", 0L),
                        senderFp = o.optString("fp", ""),
                        senderName = o.optString("name", "").ifEmpty { null },
                        senderCard = o.optString("card", "").ifEmpty { null },
                        source = o.optString("source", ""),
                        text = if (o.has("text")) o.optString("text") else null,
                        fileName = o.optString("fname", "").ifEmpty { null },
                        fileMime = o.optString("mime", "").ifEmpty { null },
                        fileSize = o.optLong("size", 0L),
                        fileStored = o.optString("stored", "").ifEmpty { null },
                        fileKey = o.optString("fkey", "").ifEmpty { null }
                    )
                )
            }
            out
        }.getOrElse { ArrayList() }
    }

    private fun writeHistory(list: List<HistoryItem>) {
        val arr = JSONArray()
        list.forEach { h ->
            val o = JSONObject()
                .put("id", h.id)
                .put("digest", h.digest)
                .put("kind", h.kind)
                .put("time", h.time)
                .put("fp", h.senderFp)
                .put("source", h.source)
                .put("size", h.fileSize)
            h.senderName?.let { o.put("name", it) }
            h.senderCard?.let { o.put("card", it) }
            h.text?.let { o.put("text", it) }
            h.fileName?.let { o.put("fname", it) }
            h.fileMime?.let { o.put("mime", it) }
            h.fileStored?.let { o.put("stored", it) }
            h.fileKey?.let { o.put("fkey", it) }
            arr.put(o)
        }
        val encrypted = vault.encrypt(arr.toString().toByteArray(Charsets.UTF_8))
        val target = historyFile()
        val temp = File(target.parentFile, target.name + ".tmp")
        temp.writeBytes(encrypted)
        if (!temp.renameTo(target)) {
            target.delete()
            check(temp.renameTo(target)) { "无法写入收件箱" }
        }
    }

    /** Encrypts received attachment bytes at rest with a random AES key wrapped by the Keystore key. */
    fun saveAttachmentBytes(data: ByteArray): StoredFile {
        val random = SecureRandom()
        val key = ByteArray(32).also(random::nextBytes)
        val iv = ByteArray(12).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        val ct = cipher.doFinal(data)
        val name = UUID.randomUUID().toString() + ".bin"
        val out = ByteArray(iv.size + ct.size)
        System.arraycopy(iv, 0, out, 0, iv.size)
        System.arraycopy(ct, 0, out, iv.size, ct.size)
        File(inboxDir(), name).writeBytes(out)
        return StoredFile(name, b64(vault.encrypt(key)))
    }

    fun readAttachmentBytes(item: HistoryItem): ByteArray {
        val stored = item.fileStored ?: throw IllegalStateException("没有附件数据")
        val wrapped = item.fileKey ?: throw IllegalStateException("附件密钥丢失")
        val key = vault.decrypt(fromB64(wrapped))
        val blob = File(inboxDir(), File(stored).name).readBytes()
        require(blob.size > 12 + 16) { "附件文件损坏" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(key, "AES"),
            GCMParameterSpec(128, blob.copyOfRange(0, 12))
        )
        return cipher.doFinal(blob, 12, blob.size - 12)
    }

    // ---------------------------------------------------------------- settings

    fun isQuickNotificationEnabled(): Boolean = prefs.getBoolean(KEY_QUICK_NOTIFICATION, false)
    fun setQuickNotificationEnabled(enabled: Boolean) { prefs.edit().putBoolean(KEY_QUICK_NOTIFICATION, enabled).commit() }

    fun monitorClipboardEnabled(): Boolean = prefs.getBoolean(KEY_MONITOR_CLIPBOARD, false)
    fun setMonitorClipboardEnabled(enabled: Boolean) { prefs.edit().putBoolean(KEY_MONITOR_CLIPBOARD, enabled).commit() }

    fun monitorQrEnabled(): Boolean = prefs.getBoolean(KEY_MONITOR_QR, false)
    fun setMonitorQrEnabled(enabled: Boolean) { prefs.edit().putBoolean(KEY_MONITOR_QR, enabled).commit() }

    fun overlayEnabled(): Boolean = prefs.getBoolean(KEY_OVERLAY, false)
    fun setOverlayEnabled(enabled: Boolean) { prefs.edit().putBoolean(KEY_OVERLAY, enabled).commit() }

    /** Show decrypted text inside notifications (hidden on the lock screen either way). */
    fun notifyShowContent(): Boolean = prefs.getBoolean(KEY_NOTIFY_CONTENT, true)
    fun setNotifyShowContent(enabled: Boolean) { prefs.edit().putBoolean(KEY_NOTIFY_CONTENT, enabled).commit() }

    /** Blocks screenshots and hides the app preview in the recent-apps screen. */
    fun secureWindow(): Boolean = prefs.getBoolean(KEY_SECURE_WINDOW, false)
    fun setSecureWindow(enabled: Boolean) { prefs.edit().putBoolean(KEY_SECURE_WINDOW, enabled).commit() }

    /** Seconds in the background before the startup password is asked again. -1 = never. */
    fun autoLockSeconds(): Int = prefs.getInt(KEY_AUTO_LOCK, 60)
    fun setAutoLockSeconds(seconds: Int) { prefs.edit().putInt(KEY_AUTO_LOCK, seconds).commit() }

    fun lastClipboardTimestamp(): Long = prefs.getLong(KEY_LAST_CLIP_TS, 0L)
    fun setLastClipboardTimestamp(ts: Long) { prefs.edit().putLong(KEY_LAST_CLIP_TS, ts).apply() }

    fun mediaWatermark(): Pair<Long, Long>? {
        val date = prefs.getLong(KEY_MONITOR_MEDIA_DATE, -1L)
        val id = prefs.getLong(KEY_MONITOR_MEDIA_ID, -1L)
        return if (date >= 0L && id >= 0L) date to id else null
    }

    fun setMediaWatermark(dateAdded: Long, id: Long) {
        prefs.edit().putLong(KEY_MONITOR_MEDIA_DATE, dateAdded).putLong(KEY_MONITOR_MEDIA_ID, id).commit()
    }

    fun clearMediaWatermark() {
        prefs.edit().remove(KEY_MONITOR_MEDIA_DATE).remove(KEY_MONITOR_MEDIA_ID).commit()
    }

    // ---------------------------------------------------------------- internals

    private fun derivePassword(password: String, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, iterations, PASSWORD_KEY_BITS)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded.also { spec.clearPassword() }
    }

    companion object {
        const val KIND_TEXT = 0
        const val KIND_FILE = 1

        private const val KEY_PUBLIC = "identity_public"
        private const val KEY_PRIVATE = "identity_private"
        private const val KEY_PUBLIC_CARD = "identity_public_card"
        private const val KEY_FINGERPRINT = "identity_fingerprint"
        private const val KEY_CONTACTS = "contacts"
        private const val KEY_ACTIVE = "active_contact"
        private const val KEY_APP_PASSWORD_SALT = "app_password_salt"
        private const val KEY_APP_PASSWORD_HASH = "app_password_hash"
        private const val KEY_APP_PASSWORD_ITERATIONS = "app_password_iterations"
        private const val KEY_PW_FAILS = "app_password_fails"
        private const val KEY_PW_LOCK_UNTIL = "app_password_lock_until"
        private const val KEY_PROCESSED_PAYLOADS = "processed_payloads_v1"
        private const val KEY_QUICK_NOTIFICATION = "quick_notification_enabled"
        private const val KEY_MONITOR_CLIPBOARD = "monitor_clipboard"
        private const val KEY_MONITOR_QR = "monitor_qr"
        private const val KEY_OVERLAY = "overlay_enabled"
        private const val KEY_NOTIFY_CONTENT = "notify_show_content"
        private const val KEY_SECURE_WINDOW = "secure_window"
        private const val KEY_AUTO_LOCK = "auto_lock_seconds"
        private const val KEY_LAST_CLIP_TS = "last_clip_ts"
        private const val KEY_MONITOR_MEDIA_DATE = "monitor_media_date"
        private const val KEY_MONITOR_MEDIA_ID = "monitor_media_id"
        private const val PASSWORD_SALT_BYTES = 16
        private const val PASSWORD_ITERATIONS = 210_000
        private const val PASSWORD_KEY_BITS = 256
        private const val MAX_PROCESSED_PAYLOADS = 512
        private const val MAX_HISTORY = 100

        private val PROCESSED_LOCK = Any()
        private val HISTORY_LOCK = Any()
        private val IDENTITY_LOCK = Any()

        @Volatile
        private var cachedIdentity: KeyPair? = null

        fun digestOf(text: String): String = digestOf(text.toByteArray(Charsets.UTF_8))

        fun digestOf(bytes: ByteArray): String =
            MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

        private fun b64(bytes: ByteArray): String = android.util.Base64.encodeToString(
            bytes,
            android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING or android.util.Base64.URL_SAFE
        )

        private fun fromB64(value: String): ByteArray = android.util.Base64.decode(
            value,
            android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING or android.util.Base64.URL_SAFE
        )

        private fun decodePublicKey(encoded: String): PublicKey =
            KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(fromB64(encoded)))

        private fun decodePrivateKey(pkcs8: ByteArray): PrivateKey =
            KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(pkcs8))
    }
}

/** AES-256-GCM key in the Android Keystore protects the private key and local history. */
class KeyStoreVault {
    private val alias = "cipherlink_vault_v3"

    private fun getOrCreateKey(): javax.crypto.SecretKey {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? javax.crypto.SecretKey)?.let { return it }
        val gen = javax.crypto.KeyGenerator.getInstance(
            android.security.keystore.KeyProperties.KEY_ALGORITHM_AES,
            "AndroidKeyStore"
        )
        gen.init(
            android.security.keystore.KeyGenParameterSpec.Builder(
                alias,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plaintext: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        return cipher.iv + cipher.doFinal(plaintext)
    }

    fun decrypt(blob: ByteArray): ByteArray {
        require(blob.size > 12) { "本机密钥存储损坏" }
        val iv = blob.copyOfRange(0, 12)
        val ct = blob.copyOfRange(12, blob.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ct)
    }

    fun deleteKey() {
        runCatching {
            val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (ks.containsAlias(alias)) ks.deleteEntry(alias)
        }
    }
}
