package com.cipherlink.app.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import com.cipherlink.app.MainActivity
import com.cipherlink.app.QuickActivity
import com.cipherlink.app.R
import com.cipherlink.app.receiver.ComposeReceiver
import com.cipherlink.app.service.BackgroundMonitorService
import com.cipherlink.app.service.OverlayService
import com.cipherlink.app.storage.AppStore

/**
 * CipherLink shows exactly ONE notification (fixed id [ID_MAIN]). It carries everything:
 *  - the "加密发送" input box,
 *  - the "解密" input box,
 *  - the latest decrypted message (or the result of the last action),
 *  - a "解密剪贴板" button.
 *
 * The background monitor and the floating window are foreground services, and Android
 * requires a notification for those. They reuse this same notification instead of adding
 * their own, so turning monitors on never creates a second entry in the shade.
 *
 * The channel is high importance but silent: that ranks the notification at the top of the
 * shade (where many systems show it expanded) and lets a freshly decrypted message pop up.
 * The text is a BigTextStyle, so it can be expanded to the full message.
 */
object Notifier {
    const val CH_MAIN = "cipherlink_main_v3"
    const val ID_MAIN = 7601

    /** Channels of earlier versions; removed so they do not clutter the system settings. */
    private val OLD_CHANNELS = listOf(
        "cipherlink_quick", "cipherlink_result_v2", "cipherlink_monitor_v2", "cipherlink_overlay"
    )

    private const val DEFAULT_TITLE = "CipherLink 快捷加解密"
    private const val DEFAULT_DETAIL = "在下方输入框加密发送，或粘贴密文解密"

    @Volatile
    private var title: String = DEFAULT_TITLE

    @Volatile
    private var detail: String = DEFAULT_DETAIL

    @Volatile
    private var opensInbox = false

    private fun manager(context: Context): NotificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannels(context: Context) {
        val m = manager(context)
        if (m.getNotificationChannel(CH_MAIN) != null) return
        // First run of this version: drop the channels of earlier versions, then create the one channel.
        OLD_CHANNELS.forEach { id -> runCatching { m.deleteNotificationChannel(id) } }
        val channel = NotificationChannel(CH_MAIN, "CipherLink 快捷加解密", NotificationManager.IMPORTANCE_HIGH)
        channel.description = "唯一的一条通知：加密发送、解密、解密结果都在这里"
        channel.setShowBadge(false)
        channel.setSound(null, null)
        channel.enableVibration(false)
        channel.enableLights(false)
        channel.lockscreenVisibility = Notification.VISIBILITY_PRIVATE
        m.createNotificationChannel(channel)
    }

    private fun immutable(): Int = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun openAppIntent(context: Context, openInbox: Boolean): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(MainActivity.EXTRA_OPEN_INBOX, openInbox)
        // Different request codes: the two variants must not overwrite each other's extras.
        return PendingIntent.getActivity(context, if (openInbox) 7611 else 7602, intent, immutable())
    }

    /** True while something needs the notification to stay (user setting or a running service). */
    private fun isPersistent(context: Context): Boolean =
        AppStore(context).isQuickNotificationEnabled() ||
            BackgroundMonitorService.running ||
            OverlayService.running

    // ------------------------------------------------------------------ public API

    /** User turned the quick notification on. */
    fun postQuick(context: Context, title: String = DEFAULT_TITLE, detail: String = DEFAULT_DETAIL) {
        AppStore(context).setQuickNotificationEnabled(true)
        show(context, title, detail, alert = false, inbox = false)
    }

    /** Result of a notification action (sent / decrypted / error). Replaces the shown text. */
    fun updateQuick(context: Context, title: String, detail: String) {
        show(context, title, detail, alert = false, inbox = false)
    }

    /** Re-posts the notification with whatever it currently shows (does not reset the text). */
    fun refresh(context: Context) {
        ensureChannels(context)
        runCatching { manager(context).notify(ID_MAIN, buildMain(context, alert = false, forceOngoing = false)) }
    }

    /** User turned the quick notification off. Stays only if a monitor / the overlay needs it. */
    fun cancelQuick(context: Context) {
        AppStore(context).setQuickNotificationEnabled(false)
        releaseIfUnused(context)
    }

    /** A message was decrypted automatically: show it in the one notification and let it pop up. */
    fun showResult(context: Context, item: AppStore.HistoryItem) {
        val showContent = AppStore(context).notifyShowContent()
        val sender = Fmt.senderLabel(item.senderName, item.senderFp)
        val newTitle: String
        val body: String
        if (item.isFile) {
            newTitle = "收到加密文件 · $sender"
            body = "${item.fileName ?: "附件"}（${Fmt.size(item.fileSize)}）\n点按打开 CipherLink 保存或查看"
        } else {
            newTitle = "收到加密消息 · $sender"
            val text = item.text.orEmpty()
            body = if (!showContent) {
                "点按打开 CipherLink 查看"
            } else if (text.length > 3500) {
                text.take(3500) + "\n…（已截断，完整内容在 CipherLink 收件箱）"
            } else {
                text
            }
        }
        show(context, newTitle, body, alert = true, inbox = true)
    }

    /** Called when a foreground service ends: keep the notification only if still needed. */
    fun releaseIfUnused(context: Context) {
        if (isPersistent(context)) {
            refresh(context)
        } else {
            runCatching { manager(context).cancel(ID_MAIN) }
        }
    }

    // ------------------------------------------------------------------- building

    private fun show(context: Context, newTitle: String, newDetail: String, alert: Boolean, inbox: Boolean) {
        title = newTitle
        detail = newDetail
        opensInbox = inbox
        ensureChannels(context)
        runCatching { manager(context).notify(ID_MAIN, buildMain(context, alert, forceOngoing = false)) }
    }

    /**
     * The single notification. Foreground services pass [forceOngoing] = true because Android
     * treats their notification as ongoing anyway and it must exist before they are marked running.
     */
    fun buildMain(context: Context, alert: Boolean = false, forceOngoing: Boolean = false): Notification {
        ensureChannels(context)
        val mutableFlag = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val sendPending = PendingIntent.getBroadcast(
            context, 7603,
            Intent(context, ComposeReceiver::class.java).setAction(ComposeReceiver.ACTION_SEND),
            PendingIntent.FLAG_UPDATE_CURRENT or mutableFlag
        )
        val decryptPending = PendingIntent.getBroadcast(
            context, 7604,
            Intent(context, ComposeReceiver::class.java).setAction(ComposeReceiver.ACTION_DECRYPT),
            PendingIntent.FLAG_UPDATE_CURRENT or mutableFlag
        )
        val clipboardPending = PendingIntent.getActivity(
            context, 7605,
            Intent(context, QuickActivity::class.java)
                .setAction(QuickActivity.ACTION_CLIPBOARD)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            immutable()
        )
        val sendInput = RemoteInput.Builder(ComposeReceiver.KEY_SEND).setLabel("输入要加密的内容").build()
        val decryptInput = RemoteInput.Builder(ComposeReceiver.KEY_DECRYPT).setLabel("粘贴密文").build()
        val sendAction = Notification.Action.Builder(
            Icon.createWithResource(context, R.drawable.ic_send), "加密发送", sendPending
        ).addRemoteInput(sendInput).build()
        val decryptAction = Notification.Action.Builder(
            Icon.createWithResource(context, R.drawable.ic_notification), "解密", decryptPending
        ).addRemoteInput(decryptInput).build()
        val clipboardAction = Notification.Action.Builder(
            Icon.createWithResource(context, R.drawable.ic_notification), "解密剪贴板", clipboardPending
        ).build()

        val store = AppStore(context)
        val recipient = store.activeContact()?.name
        val subtitle = if (recipient != null) "收件人：$recipient" else "尚未选择收件人"
        val currentTitle = title
        val currentDetail = detail

        val publicVersion = Notification.Builder(context, CH_MAIN)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("CipherLink")
            .setContentText("加密消息通知（解锁后查看）")
            .build()

        return Notification.Builder(context, CH_MAIN)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(currentTitle)
            .setContentText(currentDetail.replace('\n', ' '))
            .setSubText(subtitle)
            .setStyle(Notification.BigTextStyle().bigText(currentDetail))
            .setContentIntent(openAppIntent(context, opensInbox))
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setWhen(System.currentTimeMillis())
            .setShowWhen(true)
            .setOngoing(forceOngoing || isPersistent(context))
            .setOnlyAlertOnce(!alert)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .addAction(sendAction)
            .addAction(decryptAction)
            .addAction(clipboardAction)
            .build()
    }
}
