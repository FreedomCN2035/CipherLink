package com.cipherlink.app.service

import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import com.cipherlink.app.MainActivity
import com.cipherlink.app.core.Clip
import com.cipherlink.app.core.ImageIo
import com.cipherlink.app.core.Inbox
import com.cipherlink.app.core.Notifier
import com.cipherlink.app.storage.AppStore
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Optional, user-enabled monitor for the clipboard and newly saved images.
 *
 * Rules that keep it "invisible" unless there is something real to show:
 *  - only CipherLink data that decrypts for THIS device produces a notification;
 *  - every message is reported at most once (persistent digest log in [AppStore]);
 *  - only fresh items count: a clip copied / an image saved within the last [Inbox.FRESH_MS];
 *    enabling the monitor or restarting the service never replays old content;
 *  - the notification has one fixed id, so a new message replaces the previous one.
 *
 * Android 10+ lets a background app see the clipboard description but not its content;
 * where the content is blocked this silently does nothing (the notification action
 * "解密剪贴板" and the floating window cover that case with one tap).
 */
class BackgroundMonitorService : Service() {
    private lateinit var store: AppStore
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var clipboard: ClipboardManager? = null
    private var clipboardListener: ClipboardManager.OnPrimaryClipChangedListener? = null
    private var imageObserver: ContentObserver? = null
    private var mediaScanScheduled = false
    private var lastClipTimestamp = 0L

    override fun onCreate() {
        super.onCreate()
        store = AppStore(this)
        running = true
        if (!startForegroundSafely()) {
            running = false
            stopSelf()
            return
        }
        reconfigure()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!store.monitorClipboardEnabled() && !store.monitorQrEnabled()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_RECONFIGURE) reconfigure()
        return START_STICKY
    }

    private fun startForegroundSafely(): Boolean {
        return try {
            // The one shared CipherLink notification doubles as the foreground-service notification.
            val notification = Notifier.buildMain(this, alert = false, forceOngoing = true)
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(Notifier.ID_MAIN, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(Notifier.ID_MAIN, notification)
            }
            true
        } catch (t: Throwable) {
            // Android 12+ refuses foreground starts from the background in some restart paths.
            false
        }
    }

    /** Registers exactly the monitors that are enabled right now. */
    private fun reconfigure() {
        unregisterMonitors()
        if (store.monitorClipboardEnabled()) registerClipboardMonitor()
        if (store.monitorQrEnabled() && hasFullImageAccess()) registerImageMonitor()
    }

    private fun unregisterMonitors() {
        clipboardListener?.let { listener -> runCatching { clipboard?.removePrimaryClipChangedListener(listener) } }
        clipboardListener = null
        imageObserver?.let { observer -> runCatching { contentResolver.unregisterContentObserver(observer) } }
        imageObserver = null
    }

    // ------------------------------------------------------------------ clipboard

    private fun registerClipboardMonitor() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard = cm
        val listener = ClipboardManager.OnPrimaryClipChangedListener {
            runOnWorker { scanClipboard() }
        }
        clipboardListener = listener
        cm.addPrimaryClipChangedListener(listener)
        // A clip copied moments before the monitor started is still fresh and may be processed.
        runOnWorker { scanClipboard() }
    }

    private fun scanClipboard() {
        if (!store.monitorClipboardEnabled()) return
        val ts = Clip.currentTimestamp(this)
        val now = System.currentTimeMillis()
        // Stale clip, or one we already looked at: do not even touch its content.
        if (ts <= 0L || now - ts > Inbox.FRESH_MS || ts <= lastClipTimestamp || ts <= store.lastClipboardTimestamp()) return
        if (!Clip.currentIsText(this)) return

        val text = Clip.readText(this)
        if (text == null) return // blocked by Android in the background: stay silent and try again next time
        lastClipTimestamp = ts
        store.setLastClipboardTimestamp(ts)
        if (!Inbox.looksLikeCipherLink(text) || text.length > 2_000_000) return
        handle(Inbox.processText(this, text, "剪贴板", Inbox.Mode.AUTO))
    }

    // --------------------------------------------------------------------- images

    private fun registerImageMonitor() {
        val observer = object : ContentObserver(mainHandler) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                scheduleMediaScan()
            }
        }
        imageObserver = observer
        contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer)
        runOnWorker { establishBaselineOrScan() }
    }

    private fun scheduleMediaScan() {
        synchronized(this) {
            if (mediaScanScheduled) return
            mediaScanScheduled = true
        }
        mainHandler.postDelayed({
            synchronized(this) { mediaScanScheduled = false }
            runOnWorker { scanNewImages() }
        }, 600L)
    }

    private fun establishBaselineOrScan() {
        if (store.mediaWatermark() == null) {
            // Enabling the monitor never re-processes old photos: the newest image is the baseline.
            ImageIo.queryRecentImages(this, 1).firstOrNull()?.let { store.setMediaWatermark(it.dateAdded, it.id) }
                ?: store.setMediaWatermark(System.currentTimeMillis() / 1000L, 0L)
            return
        }
        scanNewImages()
    }

    private fun scanNewImages() {
        if (!store.monitorQrEnabled() || !hasFullImageAccess()) return
        val watermark = store.mediaWatermark()
        if (watermark == null) {
            establishBaselineOrScan()
            return
        }
        val nowSeconds = System.currentTimeMillis() / 1000L
        val rows = ImageIo.queryRecentImages(this, 30, nowSeconds - Inbox.FRESH_MS / 1000L)
        val newer = rows
            .filter { it.dateAdded > watermark.first || (it.dateAdded == watermark.first && it.id > watermark.second) }
            .sortedWith(compareBy<ImageIo.MediaRow> { it.dateAdded }.thenBy { it.id })
        if (newer.isEmpty()) return

        for (row in newer) {
            // Images CipherLink saved itself (its own outgoing QR sheets) are not incoming messages.
            if (row.path.contains("CipherLink")) continue
            var texts = runCatching { ImageIo.decodeQrTexts(contentResolver, row.uri, deep = false) }.getOrNull()
            if (texts == null) {
                // The file may still be finishing its write: one short retry.
                Thread.sleep(800L)
                texts = runCatching { ImageIo.decodeQrTexts(contentResolver, row.uri, deep = false) }.getOrNull()
            }
            if (texts != null && texts.isNotEmpty()) {
                val relevant = texts.filter { Inbox.looksLikeCipherLink(it) }
                if (relevant.isNotEmpty()) handle(Inbox.processTexts(this, relevant, "新保存的二维码图片", Inbox.Mode.AUTO))
            }
        }
        val latest = newer.last()
        store.setMediaWatermark(latest.dateAdded, latest.id)
    }

    // --------------------------------------------------------------------- result

    private fun handle(outcome: Inbox.Outcome) {
        when (outcome) {
            is Inbox.Outcome.Decrypted -> {
                if (outcome.duplicate) return
                if (MainActivity.visible) {
                    // The inbox on screen already refreshed itself; just a light hint.
                    mainHandler.post { Toast.makeText(this, "收到新的加密消息", Toast.LENGTH_SHORT).show() }
                } else {
                    Notifier.showResult(this, outcome.item)
                }
            }
            is Inbox.Outcome.Progress -> {
                if (outcome.received < outcome.total) {
                    mainHandler.post {
                        Toast.makeText(this, "二维码已收到 ${outcome.received}/${outcome.total} 张", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            else -> Unit // Not for us / not CipherLink / failed: stay completely silent.
        }
    }

    private fun runOnWorker(task: () -> Unit) {
        try {
            executor.execute {
                try {
                    task()
                } catch (t: Throwable) {
                    // A monitor must never crash the app.
                }
            }
        } catch (t: Throwable) {
            // Executor already shut down.
        }
    }

    private fun hasFullImageAccess(): Boolean = when {
        Build.VERSION.SDK_INT >= 33 ->
            checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
        else ->
            checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    override fun onDestroy() {
        running = false
        unregisterMonitors()
        mainHandler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        // Leave the shared notification in place, then keep or remove it depending on who still needs it.
        runCatching { stopForeground(STOP_FOREGROUND_DETACH) }
        Notifier.releaseIfUnused(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_RECONFIGURE = "com.cipherlink.app.action.RECONFIGURE_MONITOR"

        @Volatile
        var running = false
    }
}
