package com.cipherlink.app.storage

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileNotFoundException

/**
 * Tiny read-only provider for files CipherLink hands to other apps (QR images, encrypted
 * files to send, decrypted attachments to open). Files live in cache/shared and are never
 * exposed as file:// URIs.
 */
class SharedFileProvider : ContentProvider() {
    private fun root(): File = SharedFiles.dir(requireNotNull(context))

    override fun onCreate(): Boolean = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (!mode.contains("r") || mode.contains("w") || mode.contains("a")) {
            throw FileNotFoundException("read-only")
        }
        val file = resolve(uri)
        if (!file.exists() || !file.isFile) throw FileNotFoundException(uri.toString())
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun getType(uri: Uri): String = mimeFor(uri.lastPathSegment ?: "")

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        val file = runCatching { resolve(uri) }.getOrNull() ?: return null
        if (!file.exists()) return null
        val cols = projection ?: arrayOf("_display_name", "_size")
        val cursor = MatrixCursor(cols)
        val row = cols.map { col ->
            when (col) {
                "_display_name" -> displayName(file.name)
                "_size" -> file.length()
                else -> null
            }
        }.toTypedArray()
        cursor.addRow(row)
        return cursor
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException("read-only")
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    private fun resolve(uri: Uri): File {
        val name = uri.lastPathSegment ?: throw FileNotFoundException("missing file")
        require(name == File(name).name) { "invalid filename" }
        val file = File(root(), name).canonicalFile
        require(file.parentFile == root().canonicalFile) { "invalid path" }
        return file
    }

    /** Files are stored as "<random>_<display name>"; strip the random prefix for display. */
    private fun displayName(stored: String): String {
        val i = stored.indexOf('_')
        return if (i in 1..16) stored.substring(i + 1) else stored
    }

    private fun mimeFor(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext == "clink") return "application/x-cipherlink"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }
}

/** Creates files that [SharedFileProvider] can serve and hands out their content URIs. */
object SharedFiles {
    private const val MAX_AGE_MS = 30 * 60 * 1000L

    fun dir(context: Context): File = File(context.cacheDir, "shared").also { it.mkdirs() }

    fun authority(context: Context): String = context.packageName + ".shared"

    fun uriFor(context: Context, file: File): Uri =
        Uri.Builder().scheme("content").authority(authority(context)).appendPath(file.name).build()

    fun create(context: Context, displayName: String, bytes: ByteArray): File {
        cleanup(context)
        val safe = com.cipherlink.app.crypto.CryptoEngine.cleanFileName(displayName)
        val prefix = java.util.UUID.randomUUID().toString().replace("-", "").take(8)
        val file = File(dir(context), prefix + "_" + safe)
        file.writeBytes(bytes)
        return file
    }

    fun cleanup(context: Context) {
        val cutoff = System.currentTimeMillis() - MAX_AGE_MS
        dir(context).listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
    }
}
