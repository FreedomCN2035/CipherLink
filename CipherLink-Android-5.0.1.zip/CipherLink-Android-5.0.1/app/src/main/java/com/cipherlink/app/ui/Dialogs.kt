package com.cipherlink.app.ui

import android.app.Activity
import android.app.AlertDialog
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.cipherlink.app.R
import com.cipherlink.app.core.Fmt
import com.cipherlink.app.core.Inbox
import com.cipherlink.app.crypto.CryptoEngine
import com.cipherlink.app.storage.AppStore

/** Reusable dialogs shared by the main screen and the transparent quick-decrypt screen. */
object Dialogs {

    fun isAlive(activity: Activity): Boolean = !activity.isFinishing && !activity.isDestroyed

    fun message(activity: Activity, title: String, text: String, onClose: (() -> Unit)? = null) {
        if (!isAlive(activity)) return
        val ui = Ui(activity)
        val view = ui.vbox().apply { setPadding(ui.dp(22), ui.dp(4), ui.dp(22), 0) }
        view.addView(
            ui.text(text, 15f, R.color.cl_text).apply { setTextIsSelectable(true); setLineSpacing(0f, 1.15f) }
        )
        val scroll = ScrollView(activity).apply { addView(view) }
        val dialog = AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton("知道了", null)
            .create()
        dialog.setOnDismissListener { onClose?.invoke() }
        dialog.show()
    }

    fun error(activity: Activity, title: String, t: Throwable, onClose: (() -> Unit)? = null) {
        message(activity, title, Inbox.describe(t), onClose)
    }

    fun confirm(
        activity: Activity,
        title: String,
        message: String,
        positive: String,
        onYes: () -> Unit
    ) {
        if (!isAlive(activity)) return
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setNegativeButton("取消", null)
            .setPositiveButton(positive) { _, _ -> onYes() }
            .show()
    }

    fun prompt(
        activity: Activity,
        title: String,
        hint: String,
        initial: String,
        positive: String,
        onOk: (String) -> Unit
    ) {
        if (!isAlive(activity)) return
        val ui = Ui(activity)
        val input = ui.input(hint).apply { setText(initial); setSelection(initial.length) }
        val box = LinearLayout(activity).apply { setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0) }
        box.addView(input, ui.lp())
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(box)
            .setNegativeButton("取消", null)
            .setPositiveButton(positive) { _, _ -> onOk(input.text.toString().trim()) }
            .show()
    }

    /** Content view for a decrypted message: sender, trust level and body. */
    fun decryptedContent(activity: Activity, store: AppStore, item: AppStore.HistoryItem): View {
        val ui = Ui(activity)
        val box = ui.vbox().apply { setPadding(ui.dp(22), ui.dp(4), ui.dp(22), 0) }
        val trusted = store.findContact(item.senderFp) != null

        val meta = ui.hbox()
        meta.addView(
            if (trusted) ui.chip("已验证联系人", R.color.cl_green, R.color.cl_green_soft)
            else ui.chip("未保存的发送方", R.color.cl_warn, R.color.cl_warn_soft)
        )
        meta.addView(ui.muted(Fmt.time(item.time)), ui.lp(l = 10))
        box.addView(meta)
        box.addView(ui.muted("指纹 " + Fmt.fingerprint(item.senderFp), 11f), ui.lp(t = 6))

        if (item.isFile) {
            box.addView(ui.text(item.fileName ?: "附件", 16f, R.color.cl_text, true), ui.lp(t = 14))
            box.addView(ui.muted(Fmt.size(item.fileSize)), ui.lp(t = 2))
            if (!item.text.isNullOrBlank()) {
                box.addView(ui.text(item.text, 14f, R.color.cl_text).apply { setTextIsSelectable(true) }, ui.lp(t = 10))
            }
            box.addView(ui.muted("文件来自对方，打开前请确认可信。", 11f), ui.lp(t = 10))
        } else {
            val body = ui.text(item.text.orEmpty(), 16f, R.color.cl_text).apply {
                setTextIsSelectable(true)
                setLineSpacing(0f, 1.15f)
                setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12))
                background = ui.rounded(ui.color(R.color.cl_input), 14)
            }
            box.addView(body, ui.lp(t = 12))
        }
        return ScrollView(activity).apply { addView(box) }
    }

    /** Asks for a name and saves a public key card as a contact. */
    fun importPublicKey(
        activity: Activity,
        store: AppStore,
        card: String,
        suggestedName: String = "",
        onClose: (() -> Unit)? = null,
        onSaved: () -> Unit
    ) {
        if (!isAlive(activity)) return
        val parsed = try {
            CryptoEngine.parsePublicKeyCard(card)
        } catch (t: Throwable) {
            error(activity, "公钥无效", t, onClose)
            return
        }
        val ui = Ui(activity)
        val existing = store.findContact(parsed.id)
        val name = ui.input("给对方起个名字").apply {
            val initial = existing?.name ?: suggestedName
            setText(initial)
            setSelection(initial.length)
        }
        val box = ui.vbox().apply { setPadding(ui.dp(22), ui.dp(4), ui.dp(22), 0) }
        box.addView(ui.muted("指纹（可与对方电话/当面核对）"))
        box.addView(ui.mono(Fmt.fingerprint(parsed.id), 13f), ui.lp(t = 4, b = 12))
        box.addView(name, ui.lp())
        AlertDialog.Builder(activity)
            .setTitle(if (existing != null) "更新联系人" else "保存联系人")
            .setView(box)
            .setOnDismissListener { onClose?.invoke() }
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                val finalName = name.text.toString().trim().ifEmpty { "未命名联系人" }
                store.upsertContact(AppStore.Contact(parsed.id, finalName, CryptoEngine.buildPublicKeyCard(parsed.key)))
                if (store.activeContactId() == null) store.setActiveContact(parsed.id)
                Toast.makeText(activity, "已保存联系人：$finalName", Toast.LENGTH_SHORT).show()
                onSaved()
            }
            .show()
    }

    fun centered(ui: Ui, text: String): TextView = ui.muted(text, 14f).apply {
        gravity = Gravity.CENTER
        setPadding(ui.dp(12), ui.dp(24), ui.dp(12), ui.dp(24))
    }
}
