package com.cipherlink.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.cipherlink.app.R
import com.cipherlink.app.core.Clip
import com.cipherlink.app.core.Fmt
import com.cipherlink.app.core.Inbox
import com.cipherlink.app.core.Notifier
import com.cipherlink.app.crypto.CryptoEngine
import com.cipherlink.app.storage.AppStore
import com.cipherlink.app.ui.Ui
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Floating window: a draggable bubble that expands into a compact send / decrypt panel,
 * usable on top of any chat app.
 */
class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var ui: Ui
    private lateinit var store: AppStore
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()

    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var failed = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        ui = Ui(this)
        store = AppStore(this)
        running = true
        if (!startForegroundSafely()) {
            failed = true
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (failed || intent?.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble == null) showBubble()
        return START_NOT_STICKY
    }

    private fun startForegroundSafely(): Boolean {
        return try {
            // The one shared CipherLink notification doubles as the foreground-service notification.
            val notification = Notifier.buildMain(this, alert = false, forceOngoing = true)
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(Notifier.ID_MAIN, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(Notifier.ID_MAIN, notification)
            }
            true
        } catch (t: Throwable) {
            false
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ bubble

    private fun showBubble() {
        val prefs = getSharedPreferences("cipherlink_overlay", Context.MODE_PRIVATE)
        val size = ui.dp(54)
        val metrics = resources.displayMetrics

        val view = TextView(this).apply {
            text = "C"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(ui.color(R.color.cl_dark))
                setStroke(ui.dp(2), ui.color(R.color.cl_primary))
            }
            elevation = ui.dp(6).toFloat()
        }
        val params = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", metrics.widthPixels - size - ui.dp(8))
            y = prefs.getInt("y", ui.dp(220))
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > ui.dp(6) || abs(dy) > ui.dp(6)) moved = true
                    if (moved) {
                        params.x = (startX + dx).coerceIn(0, metrics.widthPixels - size)
                        params.y = (startY + dy).coerceIn(0, metrics.heightPixels - size)
                        runCatching { windowManager.updateViewLayout(v, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        showPanel()
                    } else {
                        prefs.edit().putInt("x", params.x).putInt("y", params.y).apply()
                    }
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(view, params)
            bubble = view
            bubbleParams = params
        } catch (t: Throwable) {
            stopSelf()
        }
    }

    private fun overlayType(): Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    // ------------------------------------------------------------------- panel

    private fun showPanel() {
        if (panel != null) return
        val view = buildPanel()
        val width = minOf(resources.displayMetrics.widthPixels - ui.dp(24), ui.dp(380))
        val params = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = ui.dp(72)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            windowManager.addView(view, params)
            panel = view
            bubble?.visibility = View.GONE
        } catch (t: Throwable) {
            toast("无法显示悬浮窗")
        }
    }

    private fun hidePanel() {
        panel?.let { runCatching { windowManager.removeViewImmediate(it) } }
        panel = null
        bubble?.visibility = View.VISIBLE
    }

    private fun buildPanel(): View {
        val root = object : LinearLayout(this@OverlayService) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    hidePanel()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ui.dp(16), ui.dp(12), ui.dp(16), ui.dp(16))
        root.background = ui.outlined(ui.color(R.color.cl_surface), ui.color(R.color.cl_divider), 22)
        root.elevation = ui.dp(12).toFloat()

        // Header
        val header = ui.hbox()
        header.addView(ui.text("CipherLink", 16f, R.color.cl_text, true), ui.lp(w = 0, weight = 1f))
        val stop = ui.text("关闭悬浮窗", 13f, R.color.cl_danger, true).apply {
            setPadding(ui.dp(8), ui.dp(6), ui.dp(8), ui.dp(6))
            setOnClickListener {
                hidePanel()
                stopSelf()
            }
        }
        header.addView(stop)
        val close = ui.text("收起  ✕", 13f, R.color.cl_muted, true).apply {
            setPadding(ui.dp(10), ui.dp(6), ui.dp(4), ui.dp(6))
            setOnClickListener { hidePanel() }
        }
        header.addView(close)
        root.addView(header)

        // Recipient
        val recipientRow = ui.hbox().apply { setPadding(0, ui.dp(4), 0, ui.dp(8)) }
        recipientRow.addView(ui.muted("收件人"), ui.lp(r = 8))
        val recipientName = ui.text(store.activeContact()?.name ?: "未选择", 14f, R.color.cl_primary, true)
        recipientRow.addView(recipientName, ui.lp(w = 0, weight = 1f))
        recipientRow.addView(ui.button("切换", Ui.BTN_GHOST) {
            val contacts = store.listContacts()
            if (contacts.isEmpty()) {
                toast("还没有联系人，请先在 CipherLink 中添加")
            } else {
                val index = contacts.indexOfFirst { it.id == store.activeContactId() }
                val next = contacts[(index + 1) % contacts.size]
                store.setActiveContact(next.id)
                recipientName.text = next.name
            }
        })
        root.addView(recipientRow)

        // Sections
        val sendSection = ui.vbox()
        val sendInput = ui.input("输入要发送的内容", 2, 4)
        sendSection.addView(sendInput)
        val sendStatus = ui.muted("").apply { setPadding(0, ui.dp(6), 0, 0) }
        sendSection.addView(ui.button("加密并复制", Ui.BTN_PRIMARY) {
            val plain = sendInput.text.toString().trim()
            if (plain.isEmpty()) {
                sendStatus.text = "请先输入内容"
            } else {
                encryptAndCopy(plain, sendInput, sendStatus)
            }
        }, ui.lp(t = 8))
        sendSection.addView(sendStatus)

        val receiveSection = ui.vbox()
        val receiveInput = ui.input("在这里粘贴密文，或点“粘贴并解密”", 2, 3)
        receiveSection.addView(receiveInput)
        val result = ui.text("解密结果会显示在这里", 14f, R.color.cl_text).apply {
            setTextIsSelectable(true)
            setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10))
            background = ui.rounded(ui.color(R.color.cl_green_soft), 14)
        }
        val buttons = ui.hbox()
        buttons.addView(ui.button("粘贴并解密", Ui.BTN_PRIMARY) {
            val pasted = Clip.readText(this)
            if (pasted == null) {
                result.text = "剪贴板为空，或系统不允许读取。请长按上方输入框手动粘贴。"
            } else {
                receiveInput.setText(pasted)
                decryptInto(pasted, result)
            }
        }, ui.lp(w = 0, weight = 1f, t = 8, r = 4))
        buttons.addView(ui.button("解密输入框") {
            val raw = receiveInput.text.toString()
            if (raw.isBlank()) result.text = "请先粘贴密文" else decryptInto(raw, result)
        }, ui.lp(w = 0, weight = 1f, t = 8, l = 4))
        receiveSection.addView(buttons)
        val resultScroll = ScrollView(this).apply { addView(result) }
        receiveSection.addView(resultScroll, ui.lp(h = ui.dp(150), t = 8))

        // Tabs
        val tabs = ui.hbox().apply { setPadding(0, 0, 0, ui.dp(8)) }
        val tabSend = ui.text("加密发送", 14f, R.color.cl_text, true).apply { gravity = Gravity.CENTER }
        val tabReceive = ui.text("解密接收", 14f, R.color.cl_text, true).apply { gravity = Gravity.CENTER }
        fun select(send: Boolean) {
            sendSection.visibility = if (send) View.VISIBLE else View.GONE
            receiveSection.visibility = if (send) View.GONE else View.VISIBLE
            tabSend.background = ui.rounded(if (send) ui.color(R.color.cl_primary_soft) else 0x00000000, 12)
            tabReceive.background = ui.rounded(if (send) 0x00000000 else ui.color(R.color.cl_primary_soft), 12)
            tabSend.setTextColor(ui.color(if (send) R.color.cl_primary else R.color.cl_muted))
            tabReceive.setTextColor(ui.color(if (send) R.color.cl_muted else R.color.cl_primary))
        }
        tabSend.setPadding(0, ui.dp(9), 0, ui.dp(9))
        tabReceive.setPadding(0, ui.dp(9), 0, ui.dp(9))
        tabSend.setOnClickListener { select(true) }
        tabReceive.setOnClickListener { select(false) }
        tabs.addView(tabSend, ui.lp(w = 0, weight = 1f, r = 4))
        tabs.addView(tabReceive, ui.lp(w = 0, weight = 1f, l = 4))
        root.addView(tabs)
        root.addView(sendSection)
        root.addView(receiveSection)
        select(true)
        return root
    }

    private fun encryptAndCopy(plain: String, input: EditText, status: TextView) {
        status.text = "正在加密…"
        executor.execute {
            try {
                val identity = store.loadIdentity() ?: throw IllegalStateException("本机密钥不可用，请先在 CipherLink 中创建")
                val contact = store.activeContact() ?: throw IllegalStateException("请先选择收件人")
                val key = CryptoEngine.parsePublicKeyCard(contact.publicKeyCard).key
                val encrypted = CryptoEngine.encrypt(plain, key, identity)
                mainHandler.post {
                    Clip.copyText(this, encrypted, "CipherLink")
                    input.setText("")
                    status.text = "✓ 已加密并复制（发给 ${contact.name}）。到聊天软件里粘贴发送即可。"
                }
            } catch (t: Throwable) {
                mainHandler.post { status.text = "✗ " + Inbox.describe(t) }
            }
        }
    }

    private fun decryptInto(raw: String, target: TextView) {
        target.text = "正在解密…"
        executor.execute {
            val message = try {
                when (val outcome = Inbox.processText(this, raw, "悬浮窗", Inbox.Mode.MANUAL)) {
                    is Inbox.Outcome.Decrypted -> {
                        val item = outcome.item
                        val from = Fmt.senderLabel(item.senderName, item.senderFp)
                        if (item.isFile) {
                            "✓ 收到文件「${item.fileName}」（${Fmt.size(item.fileSize)}）来自 $from\n请打开 CipherLink 收件箱保存或查看。"
                        } else {
                            "来自 $from\n\n" + item.text.orEmpty()
                        }
                    }
                    is Inbox.Outcome.PublicKeyCard -> "这是公钥卡，不是密文。请到 CipherLink → 联系人 添加。"
                    is Inbox.Outcome.Progress -> "二维码已收到 ${outcome.received}/${outcome.total} 张，缺少第 ${outcome.missing.joinToString("、")} 张"
                    is Inbox.Outcome.Failed -> "✗ " + Inbox.describe(outcome.error)
                    Inbox.Outcome.Ignored -> "无法识别：请粘贴以 CL2M. 开头的密文"
                }
            } catch (t: Throwable) {
                "✗ " + Inbox.describe(t)
            }
            mainHandler.post { target.text = message }
        }
    }

    override fun onDestroy() {
        running = false
        mainHandler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        panel?.let { runCatching { windowManager.removeViewImmediate(it) } }
        bubble?.let { runCatching { windowManager.removeViewImmediate(it) } }
        panel = null
        bubble = null
        // Leave the shared notification in place, then keep or remove it depending on who still needs it.
        runCatching { stopForeground(STOP_FOREGROUND_DETACH) }
        Notifier.releaseIfUnused(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.cipherlink.app.action.STOP_OVERLAY"

        @Volatile
        var running = false
    }
}
