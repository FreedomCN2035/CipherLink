package com.cipherlink.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.cipherlink.app.core.Clip
import com.cipherlink.app.core.Fmt
import com.cipherlink.app.core.ImageIo
import com.cipherlink.app.core.Inbox
import com.cipherlink.app.core.Monitor
import com.cipherlink.app.core.Notifier
import com.cipherlink.app.core.Uris
import com.cipherlink.app.crypto.CryptoEngine
import com.cipherlink.app.qr.QrCodec
import com.cipherlink.app.qr.QrTransfer
import com.cipherlink.app.service.BackgroundMonitorService
import com.cipherlink.app.service.OverlayService
import com.cipherlink.app.storage.AppStore
import com.cipherlink.app.storage.SharedFiles
import com.cipherlink.app.ui.ContactsTab
import com.cipherlink.app.ui.Dialogs
import com.cipherlink.app.ui.EntropyDialog
import com.cipherlink.app.ui.MessagesTab
import com.cipherlink.app.ui.SettingsTab
import com.cipherlink.app.ui.Ui
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors

/** A file the user chose to encrypt and send. Bytes are read right away so the grant cannot expire. */
class PendingAttachment(val name: String, val mime: String, val bytes: ByteArray)

class MainActivity : Activity() {
    lateinit var store: AppStore
    lateinit var ui: Ui

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var messagesTab: MessagesTab
    private lateinit var contactsTab: ContactsTab
    private lateinit var settingsTab: SettingsTab

    private lateinit var content: FrameLayout
    private val navItems = ArrayList<TextView>()
    private var tab = 0
    private var uiBuilt = false
    private var unlocked = false
    private var stoppedAt = 0L
    private var lockGraceUntil = 0L
    private var entropy: EntropyDialog? = null
    private var pendingIntent: Intent? = null
    private var permissionCallback: (() -> Unit)? = null
    private var pendingSave: PendingSave? = null

    /** Draft of the composer; survives re-rendering and tab switches. */
    var draftText: String = ""
    var draftAttachment: PendingAttachment? = null

    private class PendingSave(val name: String, val mime: String, val file: File?, val item: AppStore.HistoryItem?)
    private class EncryptedAttachment(val packet: ByteArray, val file: File?)

    private val inboxReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Inbox.ACTION_UPDATED && uiBuilt && tab == 0) {
                mainHandler.post { messagesTab.refreshInbox() }
            }
        }
    }

    // ----------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = AppStore(this)
        ui = Ui(this)
        messagesTab = MessagesTab(this)
        contactsTab = ContactsTab(this)
        settingsTab = SettingsTab(this)
        tab = savedInstanceState?.getInt("tab", 0) ?: 0
        // A recreated activity (rotation, dark-mode switch) must not replay the share intent.
        pendingIntent = if (savedInstanceState == null) intent else null
        applyWindowFlags()
        if (store.isAppPasswordEnabled()) showLockScreen() else unlockAndStart()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingIntent = intent
        if (uiBuilt && unlocked) handlePendingIntent()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(Inbox.ACTION_UPDATED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(inboxReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(inboxReceiver, filter)
        }
        val now = System.currentTimeMillis()
        if (now < lockGraceUntil) {
            // Returning from a file picker / chooser we opened ourselves: do not lock.
            lockGraceUntil = 0L
        } else if (uiBuilt && unlocked && store.isAppPasswordEnabled() && stoppedAt > 0L) {
            val limit = store.autoLockSeconds()
            if (limit >= 0 && now - stoppedAt > limit * 1000L) showLockScreen()
        }
    }

    override fun onResume() {
        super.onResume()
        visible = true
        if (uiBuilt) {
            if (tab == 0) messagesTab.refreshInbox() else renderTab(true)
        }
    }

    override fun onPause() {
        visible = false
        super.onPause()
    }

    override fun onStop() {
        runCatching { unregisterReceiver(inboxReceiver) }
        stoppedAt = System.currentTimeMillis()
        super.onStop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Android only lets the focused app read the clipboard, so this is the reliable moment.
        if (hasFocus && uiBuilt && unlocked && store.monitorClipboardEnabled()) autoClipboardCheck()
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun applyWindowFlags() {
        if (store.secureWindow()) {
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        var flags = 0
        if (!night) {
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags
    }

    fun setSecureWindow(enabled: Boolean) {
        store.setSecureWindow(enabled)
        applyWindowFlags()
        toast(if (enabled) "隐私屏已开启" else "隐私屏已关闭")
    }

    // ---------------------------------------------------------------- lock screen

    private fun installInsets(root: View) {
        root.setOnApplyWindowInsetsListener { view, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                view.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            } else {
                @Suppress("DEPRECATION")
                view.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }
        root.requestApplyInsets()
    }

    private fun showLockScreen() {
        unlocked = false
        uiBuilt = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(ui.color(R.color.cl_bg))
        }
        val card = ui.card()
        card.setPadding(ui.dp(22), ui.dp(24), ui.dp(22), ui.dp(22))
        card.addView(ui.text("CipherLink 已锁定", 22f, R.color.cl_text, true).apply { gravity = Gravity.CENTER }, ui.lp())
        card.addView(
            ui.muted("请输入启动密码", 13f).apply { gravity = Gravity.CENTER },
            ui.lp(t = 6, b = 14)
        )
        val password = ui.input("启动密码", password = true)
        card.addView(password, ui.lp(h = ui.dp(52)))
        val message = ui.muted("", 12f).apply { gravity = Gravity.CENTER }
        card.addView(message, ui.lp(t = 8))

        lateinit var unlock: Button

        fun updateLockState() {
            val remaining = store.passwordLockRemainingMs()
            if (remaining > 0L) {
                message.text = "尝试次数过多，请 ${remaining / 1000L + 1L} 秒后再试"
                unlock.isEnabled = false
                mainHandler.postDelayed({ updateLockState() }, 1000L)
            } else {
                message.text = ""
                unlock.isEnabled = true
            }
        }

        unlock = ui.button("解锁", Ui.BTN_PRIMARY) {
            val entered = password.text.toString()
            if (store.passwordLockRemainingMs() > 0L) {
                updateLockState()
            } else if (entered.isEmpty()) {
                toast("请输入启动密码")
            } else {
                unlock.isEnabled = false
                background("解锁失败", { store.verifyAppPassword(entered) }) { ok ->
                    if (ok) {
                        store.clearPasswordFailures()
                        unlockAndStart()
                    } else {
                        store.recordPasswordFailure()
                        password.text.clear()
                        toast("启动密码错误")
                        updateLockState()
                        unlock.isEnabled = store.passwordLockRemainingMs() <= 0L
                    }
                }
            }
        }
        card.addView(unlock, ui.lp(h = ui.dp(48), t = 12))
        root.addView(card, ui.lp(l = 24, r = 24))
        setContentView(root)
        installInsets(root)
        updateLockState()
        password.requestFocus()
    }

    private fun unlockAndStart() {
        unlocked = true
        if (!uiBuilt) {
            uiBuilt = true
            buildShell()
        }
        mainHandler.post { startupChecks() }
    }

    private fun startupChecks() {
        if (!Dialogs.isAlive(this)) return
        Notifier.ensureChannels(this)
        executor.execute { SharedFiles.cleanup(this) }
        when (store.identityState()) {
            AppStore.IdentityState.NONE -> startKeyCreation()
            AppStore.IdentityState.CORRUPT -> Unit
            AppStore.IdentityState.READY -> {
                Monitor.sync(this)
                if (store.isQuickNotificationEnabled()) Notifier.refresh(this)
            }
        }
        handlePendingIntent()
    }

    // ------------------------------------------------------------------ shell / tabs

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ui.color(R.color.cl_bg))
        }
        setContentView(root)
        installInsets(root)

        // Header
        val bar = ui.hbox().apply { setPadding(ui.dp(20), ui.dp(12), ui.dp(20), ui.dp(8)) }
        bar.addView(
            TextView(this).apply {
                text = "C"
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                background = ui.rounded(ui.color(R.color.cl_dark), 16)
            },
            ui.lp(w = ui.dp(46), h = ui.dp(46))
        )
        val titles = ui.vbox()
        titles.addView(ui.text(getString(R.string.app_name), 21f, R.color.cl_text, true))
        titles.addView(ui.muted(getString(R.string.app_subtitle)), ui.lp(t = 2))
        bar.addView(titles, ui.lp(w = 0, weight = 1f, l = 12))
        root.addView(bar)

        content = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        root.addView(content)

        // Bottom navigation with a visible selected state
        navItems.clear()
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6))
            background = ui.rounded(ui.color(R.color.cl_surface), 24)
            elevation = ui.dp(4).toFloat()
        }
        listOf("消息", "联系人", "设置").forEachIndexed { index, title ->
            val item = TextView(this).apply {
                text = title
                textSize = 14f
                gravity = Gravity.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setOnClickListener {
                    tab = index
                    renderTab(false)
                }
            }
            navItems.add(item)
            nav.addView(item, ui.lp(w = 0, h = ui.dp(44), weight = 1f, l = 3, r = 3))
        }
        root.addView(nav, ui.lp(l = 12, r = 12, b = 8))
        renderTab(false)
    }

    fun openTab(index: Int) {
        tab = index
        renderTab(false)
    }

    fun renderTab(keepScroll: Boolean = true) {
        if (!uiBuilt || !::content.isInitialized) return
        val oldScroll = if (keepScroll) (content.getChildAt(0) as? ScrollView)?.scrollY ?: 0 else 0
        content.removeAllViews()
        val view: View = when (tab) {
            0 -> messagesTab.build()
            1 -> contactsTab.build()
            else -> settingsTab.build()
        }
        content.addView(view)
        if (oldScroll > 0) view.post { view.scrollTo(0, oldScroll) }
        updateNav()
    }

    private fun updateNav() {
        navItems.forEachIndexed { index, item ->
            val selected = index == tab
            item.background = ui.rounded(if (selected) ui.color(R.color.cl_primary_soft) else 0x00000000, 18)
            item.setTextColor(ui.color(if (selected) R.color.cl_primary else R.color.cl_muted))
        }
    }

    // --------------------------------------------------------------- basic helpers

    fun toast(message: String) {
        if (!Dialogs.isAlive(this)) return
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        } else {
            mainHandler.post { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
        }
    }

    fun copyText(text: String) {
        Clip.copyText(this, text)
    }

    /** Runs [task] off the main thread, then [onSuccess] on it; failures become an error dialog. */
    fun <T> background(errorTitle: String, task: () -> T, onSuccess: (T) -> Unit) {
        executor.execute {
            try {
                val result = task()
                mainHandler.post { if (Dialogs.isAlive(this)) onSuccess(result) }
            } catch (t: Throwable) {
                mainHandler.post { if (Dialogs.isAlive(this)) Dialogs.error(this, errorTitle, t) }
            }
        }
    }

    /** Starts another screen; the lock grace keeps CipherLink from locking itself on return. */
    fun launch(intent: Intent, requestCode: Int = -1) {
        lockGraceUntil = System.currentTimeMillis() + 120_000L
        try {
            if (requestCode >= 0) startActivityForResult(intent, requestCode) else startActivity(intent)
        } catch (t: Throwable) {
            lockGraceUntil = 0L
            throw t
        }
    }

    fun versionName(): String = runCatching {
        packageManager.getPackageInfo(packageName, 0).versionName
    }.getOrNull() ?: ""

    private fun has(permission: String): Boolean = checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsThen(permissions: Array<String>, callback: () -> Unit) {
        permissionCallback = callback
        requestPermissions(permissions, REQ_PERMISSIONS)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMISSIONS) {
            val callback = permissionCallback
            permissionCallback = null
            callback?.invoke()
        }
    }

    private fun hasNotificationPermission(): Boolean =
        Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS)

    private fun ensureNotificationPermission(onResult: (Boolean) -> Unit) {
        if (hasNotificationPermission()) {
            onResult(true)
        } else {
            requestPermissionsThen(arrayOf(Manifest.permission.POST_NOTIFICATIONS)) { onResult(hasNotificationPermission()) }
        }
    }

    private fun imagePermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun hasFullImageAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 33) has(Manifest.permission.READ_MEDIA_IMAGES) else has(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasAnyImageAccess(): Boolean =
        hasFullImageAccess() || (Build.VERSION.SDK_INT >= 34 && has(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED))

    private fun requireImageAccess(then: () -> Unit) {
        if (hasAnyImageAccess()) {
            then()
        } else {
            requestPermissionsThen(imagePermissions()) {
                if (hasAnyImageAccess()) then() else toast("需要允许访问照片，才能识别截图")
            }
        }
    }

    // ------------------------------------------------------------------ key creation

    fun startKeyCreation() {
        if (entropy?.isShowing == true) return
        val dialog = EntropyDialog(this, store) {
            renderTab()
            Monitor.sync(this)
        }
        entropy = dialog
        dialog.show()
    }

    fun confirmRegenerate() {
        val message = if (store.identityState() == AppStore.IdentityState.READY) {
            "旧私钥会被删除。别人之前发给你的旧密文将无法再解密，你也必须把新的公钥重新发给所有联系人。已解密的收件箱内容不受影响。"
        } else {
            "将清除现有密钥数据并重新创建一套新密钥。"
        }
        Dialogs.confirm(this, "重新生成密钥？", message, "继续") {
            store.eraseIdentityPermanently()
            renderTab()
            startKeyCreation()
        }
    }

    // ----------------------------------------------------------------- contacts

    fun showAddContactDialog() {
        val box = ui.vbox().apply { setPadding(ui.dp(20), ui.dp(6), ui.dp(20), 0) }
        val name = ui.input("联系人名称（例如：小王）")
        val key = ui.input("粘贴对方的 CL2P. 公钥卡", 5, 8)
        box.addView(name, ui.lp(h = ui.dp(52)))
        box.addView(key, ui.lp(t = 8))
        box.addView(ui.button("从剪贴板粘贴", Ui.BTN_GHOST) {
            val pasted = Clip.readText(this)
            if (pasted == null) toast("剪贴板里没有文本") else key.setText(pasted)
        }, ui.lp(t = 4))
        val dialog = AlertDialog.Builder(this)
            .setTitle("添加联系人")
            .setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton("取消", null)
            .setPositiveButton("保存", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                try {
                    val normalized = try {
                        CryptoEngine.normalizeIncoming(key.text.toString())
                    } catch (t: Throwable) {
                        key.text.toString()
                    }
                    val parsed = CryptoEngine.parsePublicKeyCard(normalized)
                    val contact = AppStore.Contact(
                        parsed.id,
                        name.text.toString().trim().ifEmpty { "未命名联系人" },
                        CryptoEngine.buildPublicKeyCard(parsed.key)
                    )
                    store.upsertContact(contact)
                    if (store.activeContactId() == null) store.setActiveContact(contact.id)
                    dialog.dismiss()
                    renderTab()
                    toast("已保存联系人：${contact.name}")
                } catch (t: Throwable) {
                    Dialogs.error(this, "公钥无效", t)
                }
            }
        }
        dialog.show()
    }

    fun addContactFromClipboard() {
        val text = Clip.readText(this)
        if (text == null) {
            toast("剪贴板里没有文本")
            return
        }
        val card = runCatching { CryptoEngine.normalizeIncoming(text) }.getOrNull()
        if (card != null && card.startsWith(CryptoEngine.PUBLIC_PREFIX)) {
            importContactCard(card) { renderTab() }
        } else {
            Dialogs.message(this, "没找到公钥", "剪贴板里没有 CL2P. 开头的公钥卡。请先复制对方发来的整段公钥。")
        }
    }

    fun addContactFromScreenshot() {
        requireImageAccess {
            toast("正在识别最近的截图…")
            background("识别失败", { ImageIo.scanLatestForCipherLink(this) }) { texts ->
                val card = texts.mapNotNull { runCatching { CryptoEngine.normalizeIncoming(it) }.getOrNull() }
                    .firstOrNull { it.startsWith(CryptoEngine.PUBLIC_PREFIX) }
                if (card != null) {
                    importContactCard(card) { renderTab() }
                } else {
                    Dialogs.message(this, "没找到公钥二维码", "最近的图片里没有识别到公钥二维码。请先让对方截图发来，或直接粘贴公钥文本。")
                }
            }
        }
    }

    fun importContactCard(card: String, onSaved: () -> Unit) {
        Dialogs.importPublicKey(this, store, card, "", null, onSaved)
    }

    fun showContactChooser() {
        val contacts = store.listContacts()
        if (contacts.isEmpty()) {
            showAddContactDialog()
            return
        }
        val names = contacts.map { it.name }.toTypedArray()
        val current = contacts.indexOfFirst { it.id == store.activeContactId() }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("选择收件人")
            .setSingleChoiceItems(names, current) { dialog, which ->
                store.setActiveContact(contacts[which].id)
                dialog.dismiss()
                renderTab()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    fun renameContact(contact: AppStore.Contact) {
        Dialogs.prompt(this, "重命名联系人", "名称", contact.name, "保存") { name ->
            if (name.isNotEmpty()) {
                store.renameContact(contact.id, name)
                renderTab()
            }
        }
    }

    fun deleteContact(contact: AppStore.Contact) {
        Dialogs.confirm(this, "删除联系人？", "只删除本机保存的“${contact.name}”的公钥，之后无法再给 TA 加密，已收到的消息不受影响。", "删除") {
            store.deleteContact(contact.id)
            renderTab()
        }
    }

    fun shareText(title: String, text: String) {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        launch(Intent.createChooser(send, title))
    }

    fun shareMyPublicKey() {
        val card = store.publicKeyCard()
        if (card == null) {
            toast("还没有密钥")
            return
        }
        shareText("发送我的公钥", "这是我的 CipherLink 公钥，请复制整段后在 CipherLink 里添加联系人：\n$card")
    }

    // ---------------------------------------------------------------- encrypt / send

    private fun requireRecipient(): AppStore.Contact? {
        val contact = store.activeContact()
        if (contact == null) toast("请先选择收件人")
        return contact
    }

    fun encryptTextAsync(text: String, onDone: (String) -> Unit) {
        val contact = requireRecipient() ?: return
        background("加密失败", {
            val identity = store.loadIdentity() ?: error("本机密钥不可用")
            val recipient = CryptoEngine.parsePublicKeyCard(contact.publicKeyCard).key
            CryptoEngine.encrypt(text, recipient, identity)
        }, onDone)
    }

    fun clearDraft() {
        draftText = ""
        draftAttachment = null
    }

    fun pickAttachment() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
        launch(intent, REQ_PICK_ATTACHMENT)
    }

    private fun setAttachmentFromUri(uri: Uri) {
        toast("正在读取文件…")
        background("无法添加附件", {
            val name = Uris.displayName(contentResolver, uri)
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            val bytes = ImageIo.readBytesLimited(contentResolver, uri, CryptoEngine.MAX_ATTACHMENT_BYTES)
            PendingAttachment(name, mime, bytes)
        }) { attachment ->
            draftAttachment = attachment
            tab = 0
            renderTab()
            toast("已添加附件：${attachment.name}")
        }
    }

    fun encryptAttachmentFlow(attachment: PendingAttachment, caption: String, asQr: Boolean) {
        val contact = requireRecipient() ?: return
        toast("正在加密附件…")
        background("加密附件失败", {
            val identity = store.loadIdentity() ?: error("本机密钥不可用")
            val recipient = CryptoEngine.parsePublicKeyCard(contact.publicKeyCard).key
            val packet = CryptoEngine.encryptAttachment(attachment.name, attachment.mime, attachment.bytes, caption, recipient, identity)
            if (asQr) {
                require(packet.size <= QR_MAX_PACKET_BYTES) {
                    "这个附件加密后约 ${Fmt.size(packet.size.toLong())}，超过二维码上限（约 34 KB）。请改用“加密附件并发送”以文件方式发送。"
                }
                EncryptedAttachment(packet, null)
            } else {
                val file = SharedFiles.create(this, attachment.name + ".clink", CryptoEngine.packetToFile(packet))
                EncryptedAttachment(packet, file)
            }
        }) { result ->
            clearDraft()
            renderTab()
            if (asQr) {
                showQrDialog(CryptoEngine.packetToText(result.packet))
            } else {
                val file = result.file
                if (file != null) showEncryptedFileDialog(file, result.packet, contact.name)
            }
        }
    }

    private fun showEncryptedFileDialog(file: File, packet: ByteArray, contactName: String) {
        if (!Dialogs.isAlive(this)) return
        val box = ui.vbox().apply { setPadding(ui.dp(22), ui.dp(4), ui.dp(22), 0) }
        box.addView(
            ui.text(
                "已为“$contactName”加密。把这个文件当作“文件”通过聊天软件发给对方，对方用 CipherLink 打开即可。",
                14f, R.color.cl_text
            ).apply { setLineSpacing(0f, 1.15f) }
        )
        box.addView(ui.muted("${file.name.substringAfter('_')} · ${Fmt.size(file.length())}"), ui.lp(t = 8, b = 8))
        var dialog: AlertDialog? = null
        box.addView(ui.button("分享加密文件", Ui.BTN_PRIMARY) { dialog?.dismiss(); shareFile(file) }, ui.lp(t = 4))
        box.addView(ui.button("保存到手机…") {
            dialog?.dismiss()
            startSaveAs(file.name.substringAfter('_'), "application/octet-stream", file, null)
        }, ui.lp(t = 8))
        if (packet.size <= QR_MAX_PACKET_BYTES) {
            val text = CryptoEngine.packetToText(packet)
            box.addView(ui.button("生成二维码拼图") { dialog?.dismiss(); showQrDialog(text) }, ui.lp(t = 8))
            box.addView(ui.button("复制成文本密文") {
                copyText(text)
                toast("已复制 ${text.length} 字符的密文")
                dialog?.dismiss()
            }, ui.lp(t = 8))
        }
        dialog = AlertDialog.Builder(this)
            .setTitle("附件已加密")
            .setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton("关闭", null)
            .show()
    }

    private fun shareFile(file: File) {
        val uri = SharedFiles.uriFor(this, file)
        val send = Intent(Intent.ACTION_SEND)
            .setType("application/octet-stream")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        send.clipData = ClipData.newRawUri("", uri)
        launch(Intent.createChooser(send, "发送加密文件").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }

    // ------------------------------------------------------------- receive / decrypt

    fun pasteAndDecrypt() {
        val text = Clip.readText(this)
        if (text == null) {
            toast("剪贴板里没有文本（或系统未允许读取）")
        } else {
            decryptText(text, "剪贴板")
        }
    }

    fun decryptText(text: String, source: String) {
        background("解密失败", { Inbox.processText(this, text, source, Inbox.Mode.MANUAL) }) { outcome ->
            handleOutcomes(listOf(outcome))
        }
    }

    fun decryptLatestScreenshot() {
        requireImageAccess {
            toast("正在识别最近的截图…")
            background("识别失败", {
                val texts = ImageIo.scanLatestForCipherLink(this)
                if (texts.isEmpty()) null else Inbox.processTexts(this, texts, "最近截图", Inbox.Mode.MANUAL)
            }) { outcome ->
                if (outcome == null) {
                    Dialogs.message(
                        this, "没有找到二维码",
                        "最近的几张图片里没有识别到 CipherLink 二维码。\n\n请确认二维码截图已保存到相册；如果只授权了“部分照片”，请改为允许访问全部照片，或用下面的“选择二维码图片”。"
                    )
                } else {
                    handleOutcomes(listOf(outcome))
                }
            }
        }
    }

    fun pickEncryptedOrImages() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        launch(intent, REQ_PICK_DECRYPT)
    }

    /** Images (QR codes) and .clink files, e.g. picked from storage or shared into the app. */
    fun processUris(uris: List<Uri>, source: String) {
        toast("正在识别…")
        background("读取失败", {
            val outcomes = ArrayList<Inbox.Outcome>()
            val texts = ArrayList<String>()
            for (uri in uris) {
                try {
                    val head = ImageIo.peekHead(contentResolver, uri, 4)
                    if (CryptoEngine.hasFileMagic(head)) {
                        val bytes = ImageIo.readBytesLimited(contentResolver, uri, CryptoEngine.MAX_FILE_BYTES)
                        outcomes.add(Inbox.processFileBytes(this, bytes, source, Inbox.Mode.MANUAL))
                    } else {
                        texts.addAll(ImageIo.decodeQrTexts(contentResolver, uri, true))
                    }
                } catch (t: Throwable) {
                    outcomes.add(Inbox.Outcome.Failed(t))
                }
            }
            if (texts.isNotEmpty()) outcomes.add(Inbox.processTexts(this, texts, source, Inbox.Mode.MANUAL))
            outcomes.toList()
        }) { outcomes -> handleOutcomes(outcomes) }
    }

    private fun handleOutcomes(outcomes: List<Inbox.Outcome>) {
        val decrypted = outcomes.filterIsInstance<Inbox.Outcome.Decrypted>()
        if (decrypted.isNotEmpty()) {
            tab = 0
            renderTab()
            if (decrypted.size > 1) toast("已解密 ${decrypted.size} 条，已放入收件箱")
            showDecryptedDialog(decrypted.first().item)
            return
        }
        val outcome: Inbox.Outcome = outcomes.firstOrNull { it is Inbox.Outcome.Failed }
            ?: outcomes.firstOrNull { it is Inbox.Outcome.Progress }
            ?: outcomes.firstOrNull { it is Inbox.Outcome.PublicKeyCard }
            ?: Inbox.Outcome.Ignored
        when (outcome) {
            is Inbox.Outcome.Failed -> Dialogs.error(this, "解密失败", outcome.error)
            is Inbox.Outcome.Progress ->
                Dialogs.message(
                    this, "二维码还没收齐",
                    "已收到 ${outcome.received}/${outcome.total} 张，缺少第 ${outcome.missing.joinToString("、")} 张。\n把剩下的二维码图片也选进来，收齐后会自动解密（20 分钟内有效）。"
                )
            is Inbox.Outcome.PublicKeyCard -> importContactCard(outcome.card) { renderTab() }
            is Inbox.Outcome.Decrypted -> showDecryptedDialog(outcome.item)
            Inbox.Outcome.Ignored ->
                Dialogs.message(this, "不是 CipherLink 数据", "没有发现可以解密的 CipherLink 内容。请确认复制了完整的密文（以 CL2M. 开头），或选择了包含二维码的图片。")
        }
    }

    fun showDecryptedDialog(item: AppStore.HistoryItem) {
        if (!Dialogs.isAlive(this)) return
        val builder = AlertDialog.Builder(this)
            .setTitle(if (item.isFile) "收到加密文件" else "收到加密消息")
            .setView(Dialogs.decryptedContent(this, store, item))
            .setNegativeButton("关闭", null)
        if (item.isFile) {
            builder.setPositiveButton("保存到…") { _, _ -> saveReceivedFile(item) }
            builder.setNeutralButton("打开") { _, _ -> openReceivedFile(item) }
        } else {
            builder.setPositiveButton("复制") { _, _ ->
                copyText(item.text.orEmpty())
                toast("已复制")
            }
            val card = item.senderCard
            if (card != null && store.findContact(item.senderFp) == null) {
                builder.setNeutralButton("保存发送方") { _, _ -> importContactCard(card) { renderTab() } }
            }
        }
        builder.show()
    }

    /** Clipboard check while CipherLink is on screen (the only time Android always allows it). */
    private fun autoClipboardCheck() {
        val ts = Clip.currentTimestamp(this)
        if (ts <= 0L || System.currentTimeMillis() - ts > Inbox.FRESH_MS || ts <= store.lastClipboardTimestamp()) return
        if (!Clip.currentIsText(this)) return
        val text = Clip.readText(this) ?: return
        store.setLastClipboardTimestamp(ts)
        if (!Inbox.looksLikeCipherLink(text)) return
        background("解密失败", { Inbox.processText(this, text, "剪贴板", Inbox.Mode.AUTO) }) { outcome ->
            if (outcome is Inbox.Outcome.Decrypted && !outcome.duplicate) {
                tab = 0
                renderTab()
                showDecryptedDialog(outcome.item)
            }
        }
    }

    // ------------------------------------------------------------- inbox management

    fun deleteHistoryItem(item: AppStore.HistoryItem) {
        Dialogs.confirm(this, "删除这条消息？", "只从本机收件箱删除，不影响对方。", "删除") {
            store.deleteHistory(item.id)
            messagesTab.refreshInbox()
        }
    }

    fun clearInbox() {
        if (store.historyList().isEmpty()) {
            toast("收件箱已经是空的")
            return
        }
        Dialogs.confirm(this, "清空收件箱？", "本机保存的所有已解密消息和文件都会被删除。", "清空") {
            store.clearHistory()
            renderTab()
        }
    }

    // ------------------------------------------------------------ files: save / open

    fun saveReceivedFile(item: AppStore.HistoryItem) {
        startSaveAs(item.fileName ?: "attachment.bin", item.fileMime ?: "application/octet-stream", null, item)
    }

    private fun startSaveAs(name: String, mime: String, file: File?, item: AppStore.HistoryItem?) {
        pendingSave = PendingSave(name, mime, file, item)
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(mime)
            .putExtra(Intent.EXTRA_TITLE, name)
        launch(intent, REQ_SAVE_FILE)
    }

    fun openReceivedFile(item: AppStore.HistoryItem) {
        background("打开失败", {
            val bytes = store.readAttachmentBytes(item)
            SharedFiles.create(this, item.fileName ?: "attachment.bin", bytes)
        }) { file ->
            val uri = SharedFiles.uriFor(this, file)
            val view = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, item.fileMime ?: "application/octet-stream")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try {
                launch(view)
            } catch (e: ActivityNotFoundException) {
                toast("没有能打开这类文件的应用，请先“保存到…”再用其他应用打开")
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) {
            if (requestCode == REQ_SAVE_FILE) pendingSave = null
            return
        }
        when (requestCode) {
            REQ_PICK_ATTACHMENT -> data.data?.let { setAttachmentFromUri(it) }
            REQ_PICK_DECRYPT -> {
                val uris = ArrayList<Uri>()
                val clip = data.clipData
                if (clip != null) {
                    for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
                } else {
                    data.data?.let { uris.add(it) }
                }
                if (uris.isNotEmpty()) processUris(uris, "所选文件")
            }
            REQ_SAVE_FILE -> {
                val save = pendingSave
                pendingSave = null
                val target = data.data
                if (save != null && target != null) {
                    background("保存失败", {
                        val out = contentResolver.openOutputStream(target) ?: error("无法写入所选位置")
                        out.use { stream ->
                            val file = save.file
                            val item = save.item
                            if (file != null) {
                                file.inputStream().use { it.copyTo(stream) }
                            } else if (item != null) {
                                stream.write(store.readAttachmentBytes(item))
                            }
                        }
                        true
                    }) { toast("已保存：${save.name}") }
                }
            }
        }
    }

    // ------------------------------------------------------------ share-in handling

    private fun handlePendingIntent() {
        val incoming = pendingIntent ?: return
        pendingIntent = null
        if (incoming.getBooleanExtra(EXTRA_OPEN_INBOX, false)) {
            tab = 0
            renderTab(false)
        }
        if (incoming.action == Intent.ACTION_SEND) handleShareIn(incoming)
    }

    private fun handleShareIn(incoming: Intent) {
        val stream = Uris.stream(incoming)
        if (stream != null) {
            toast("正在读取分享的文件…")
            background("无法读取分享的文件", {
                val head = ImageIo.peekHead(contentResolver, stream, 4)
                if (CryptoEngine.hasFileMagic(head)) {
                    val bytes = ImageIo.readBytesLimited(contentResolver, stream, CryptoEngine.MAX_FILE_BYTES)
                    Pair<Inbox.Outcome?, PendingAttachment?>(Inbox.processFileBytes(this, bytes, "分享的文件", Inbox.Mode.MANUAL), null)
                } else {
                    val name = Uris.displayName(contentResolver, stream)
                    val mime = incoming.type ?: contentResolver.getType(stream) ?: "application/octet-stream"
                    val bytes = ImageIo.readBytesLimited(contentResolver, stream, CryptoEngine.MAX_ATTACHMENT_BYTES)
                    Pair<Inbox.Outcome?, PendingAttachment?>(null, PendingAttachment(name, mime, bytes))
                }
            }) { result ->
                val outcome = result.first
                val attachment = result.second
                if (outcome != null) {
                    handleOutcomes(listOf(outcome))
                } else if (attachment != null) {
                    draftAttachment = attachment
                    tab = 0
                    renderTab(false)
                    toast("已添加附件：${attachment.name}，选好收件人后点“加密附件并发送”")
                }
            }
            return
        }
        val text = incoming.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
        if (!text.isNullOrBlank()) {
            if (Inbox.looksLikeCipherLink(text)) {
                decryptText(text, "分享的文字")
            } else {
                draftText = text
                tab = 0
                renderTab(false)
                toast("已放入输入框，选好收件人后加密")
            }
        }
    }

    // --------------------------------------------------------------- QR images

    fun showQrDialog(payload: String) {
        toast("正在生成二维码…")
        executor.execute {
            try {
                require(payload.startsWith(CryptoEngine.MESSAGE_PREFIX)) { "内部错误：不是 CL2M. 密文" }
                val parts = QrTransfer.split(payload)
                val sheet = QrCodec.encodeSheet(parts)
                mainHandler.post { presentQrSheet(sheet, parts.size) }
            } catch (t: Throwable) {
                mainHandler.post { Dialogs.error(this, "二维码生成失败", t) }
            }
        }
    }

    private fun presentQrSheet(sheet: Bitmap, count: Int) {
        if (!Dialogs.isAlive(this)) {
            if (!sheet.isRecycled) sheet.recycle()
            return
        }
        val root = ui.vbox().apply { setPadding(ui.dp(6), 0, ui.dp(6), 0) }
        val image = ImageView(this).apply {
            setImageBitmap(sheet)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        val scroll = ScrollView(this).apply { addView(image, LinearLayout.LayoutParams(-1, -2)) }
        root.addView(scroll, ui.lp(h = 0, weight = 1f))
        val info = if (count == 1) {
            "单张二维码，M 级纠错，适合截图。"
        } else {
            "共 $count 张二维码，承载同一条已加密并签名的消息。对方收齐全部后才会解密；整张图一起发过去最方便。"
        }
        root.addView(ui.muted(info).apply { setPadding(ui.dp(8), ui.dp(6), ui.dp(8), ui.dp(6)) })
        val row = ui.hbox()
        row.addView(ui.button("保存到相册") { saveImageToGallery(sheet) }, ui.lp(w = 0, weight = 1f, r = 4))
        row.addView(ui.button("复制图片") {
            try {
                Clip.copyUri(this, SharedFiles.uriFor(this, bitmapToSharedFile(sheet)), "CipherLink QR image")
                toast("图片已复制，可直接粘贴到聊天里")
            } catch (t: Throwable) {
                Dialogs.error(this, "复制图片失败", t)
            }
        }, ui.lp(w = 0, weight = 1f, l = 4, r = 4))
        row.addView(ui.button("分享…", Ui.BTN_PRIMARY) {
            try {
                val uri = SharedFiles.uriFor(this, bitmapToSharedFile(sheet))
                val send = Intent(Intent.ACTION_SEND)
                    .setType("image/png")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                send.clipData = ClipData.newRawUri("", uri)
                launch(Intent.createChooser(send, "发送二维码").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (t: Throwable) {
                Dialogs.error(this, "分享失败", t)
            }
        }, ui.lp(w = 0, weight = 1f, l = 4))
        root.addView(row, ui.lp(b = 6))

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (count == 1) "CipherLink 二维码" else "CipherLink 二维码拼图 · $count 张")
            .setView(root)
            .setNegativeButton("关闭", null)
            .create()
        dialog.setOnDismissListener { if (!sheet.isRecycled) sheet.recycle() }
        dialog.show()
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.96).toInt(),
            (resources.displayMetrics.heightPixels * 0.88).toInt()
        )
    }

    private fun bitmapToSharedFile(bitmap: Bitmap): File {
        val out = ByteArrayOutputStream()
        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) { "PNG 编码失败" }
        return SharedFiles.create(this, "CipherLink.png", out.toByteArray())
    }

    fun saveImageToGallery(bitmap: Bitmap) {
        if (Build.VERSION.SDK_INT <= 28 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            requestPermissionsThen(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                if (has(Manifest.permission.WRITE_EXTERNAL_STORAGE) && !bitmap.isRecycled) {
                    saveImageToGallery(bitmap)
                } else {
                    toast("没有存储权限，无法保存")
                }
            }
            return
        }
        try {
            saveBitmapToPictures(bitmap)
            toast("已保存到相册 · CipherLink")
        } catch (t: Throwable) {
            Dialogs.error(this, "保存失败", t)
        }
    }

    private fun saveBitmapToPictures(bitmap: Bitmap): Uri {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "CipherLink_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CipherLink")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("无法创建相册文件")
            try {
                val out = contentResolver.openOutputStream(uri) ?: error("无法写入相册文件")
                out.use { stream -> check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)) { "PNG 编码失败" } }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                return uri
            } catch (t: Throwable) {
                contentResolver.delete(uri, null, null)
                throw t
            }
        }
        @Suppress("DEPRECATION")
        val url = MediaStore.Images.Media.insertImage(contentResolver, bitmap, "CipherLink_${System.currentTimeMillis()}", "CipherLink QR")
            ?: error("无法写入相册")
        return Uri.parse(url)
    }

    // ------------------------------------------------------------------ password

    fun showSetPasswordDialog() {
        val enabled = store.isAppPasswordEnabled()
        val current = ui.input("当前启动密码", password = true)
        val first = ui.input("新密码（至少 6 位）", password = true)
        val second = ui.input("再输入一次", password = true)
        val box = ui.vbox().apply { setPadding(ui.dp(20), ui.dp(6), ui.dp(20), 0) }
        if (enabled) box.addView(current, ui.lp(h = ui.dp(52), b = 8))
        box.addView(first, ui.lp(h = ui.dp(52)))
        box.addView(second, ui.lp(h = ui.dp(52), t = 8))
        AlertDialog.Builder(this)
            .setTitle(if (enabled) "修改启动密码" else "设置启动密码")
            .setView(box)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                val oldPassword = current.text.toString()
                val a = first.text.toString()
                val b = second.text.toString()
                if (a.length < 6 || a != b) {
                    toast("密码至少 6 位，且两次输入必须一致")
                } else {
                    background("保存失败", {
                        if (enabled && !store.verifyAppPassword(oldPassword)) {
                            false
                        } else {
                            store.setAppPassword(a)
                            true
                        }
                    }) { ok ->
                        if (ok) {
                            toast("启动密码已保存")
                            renderTab()
                        } else {
                            toast("当前密码错误，未修改")
                        }
                    }
                }
            }
            .show()
    }

    fun showDisablePasswordDialog() {
        val password = ui.input("当前启动密码", password = true)
        val box = ui.vbox().apply { setPadding(ui.dp(20), ui.dp(6), ui.dp(20), 0) }
        box.addView(password, ui.lp(h = ui.dp(52)))
        AlertDialog.Builder(this)
            .setTitle("关闭启动密码")
            .setMessage("需要验证当前密码")
            .setView(box)
            .setNegativeButton("取消", null)
            .setPositiveButton("关闭") { _, _ ->
                val entered = password.text.toString()
                background("操作失败", { store.verifyAppPassword(entered) }) { ok ->
                    if (ok) {
                        store.disableAppPassword()
                        toast("启动密码已关闭")
                        renderTab()
                    } else {
                        toast("密码错误，未关闭")
                    }
                }
            }
            .show()
    }

    fun autoLockLabel(): String = when (val seconds = store.autoLockSeconds()) {
        -1 -> "从不"
        0 -> "立即"
        30 -> "30 秒"
        60 -> "1 分钟"
        300 -> "5 分钟"
        900 -> "15 分钟"
        else -> "$seconds 秒"
    }

    fun chooseAutoLock() {
        val labels = arrayOf("立即（每次离开都锁）", "30 秒", "1 分钟", "5 分钟", "15 分钟", "从不")
        val values = intArrayOf(0, 30, 60, 300, 900, -1)
        val current = values.indexOf(store.autoLockSeconds()).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("离开 CipherLink 多久后自动锁定")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                store.setAutoLockSeconds(values[which])
                dialog.dismiss()
                renderTab()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    // -------------------------------------------------------- quick access & monitors

    fun setQuickNotification(enabled: Boolean) {
        if (!enabled) {
            Notifier.cancelQuick(this)
            toast(
                if (BackgroundMonitorService.running || OverlayService.running) {
                    "已关闭。自动解密/悬浮窗仍在运行，系统要求它们保留这一条通知"
                } else {
                    "通知栏快捷输入已关闭"
                }
            )
            renderTab()
            return
        }
        ensureNotificationPermission { granted ->
            if (granted) {
                Notifier.postQuick(this)
                toast("已开启：下拉通知栏即可使用")
            } else {
                toast("需要通知权限才能在通知栏使用")
            }
            renderTab()
        }
    }

    fun setOverlay(enabled: Boolean) {
        val intent = Intent(this, OverlayService::class.java)
        if (!enabled) {
            stopService(intent)
            toast("悬浮窗已关闭")
        } else if (!Settings.canDrawOverlays(this)) {
            launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("请允许“显示在其他应用上层”，然后回来再打开一次")
        } else {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            toast("悬浮球已显示，点它展开输入框")
        }
        mainHandler.postDelayed({ if (uiBuilt) renderTab() }, 500L)
    }

    fun setClipboardMonitor(enabled: Boolean) {
        if (!enabled) {
            store.setMonitorClipboardEnabled(false)
            Monitor.sync(this)
            toast("剪贴板自动解密已关闭")
            renderTab()
            return
        }
        ensureNotificationPermission { granted ->
            store.setMonitorClipboardEnabled(true)
            Monitor.sync(this)
            toast(
                if (granted) "已开启。注意：后台读取剪贴板受 Android 限制，打开 CipherLink 时一定会检查"
                else "已开启，但没有通知权限，解密结果将不会弹出"
            )
            renderTab()
        }
    }

    fun setQrMonitor(enabled: Boolean) {
        if (!enabled) {
            store.setMonitorQrEnabled(false)
            Monitor.sync(this)
            toast("二维码监听已关闭")
            renderTab()
            return
        }
        ensureNotificationPermission { _ ->
            val enableNow = {
                if (hasFullImageAccess()) {
                    // Fresh baseline: only images saved from now on are ever considered.
                    store.clearMediaWatermark()
                    store.setMonitorQrEnabled(true)
                    Monitor.sync(this)
                    toast("二维码监听已开启，之后保存的二维码会自动解密")
                } else {
                    toast("必须允许访问“全部照片”，才能持续检查新保存的二维码")
                }
                renderTab()
            }
            if (hasFullImageAccess()) enableNow() else requestPermissionsThen(imagePermissions(), enableNow)
        }
    }

    fun openBatterySettings() {
        try {
            launch(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (t: Throwable) {
            toast("请在系统设置里把 CipherLink 设为“不受电池限制”")
        }
    }

    companion object {
        const val EXTRA_OPEN_INBOX = "com.cipherlink.app.extra.OPEN_INBOX"

        /** True while the app is on screen; the monitor then skips its notification. */
        @Volatile
        var visible = false

        private const val QR_MAX_PACKET_BYTES = 34_000
        private const val REQ_PERMISSIONS = 8000
        private const val REQ_PICK_ATTACHMENT = 8004
        private const val REQ_PICK_DECRYPT = 8005
        private const val REQ_SAVE_FILE = 8006
    }
}
