package com.cipherlink.app.core

import android.content.Context
import android.content.Intent
import android.os.Build
import com.cipherlink.app.service.BackgroundMonitorService
import com.cipherlink.app.storage.AppStore

/** Starts, reconfigures or stops the background monitor to match the saved settings. */
object Monitor {
    fun sync(context: Context) {
        val store = AppStore(context)
        val intent = Intent(context, BackgroundMonitorService::class.java)
        if (!store.monitorClipboardEnabled() && !store.monitorQrEnabled()) {
            context.stopService(intent)
            return
        }
        if (store.identityState() != AppStore.IdentityState.READY) return
        intent.action = BackgroundMonitorService.ACTION_RECONFIGURE
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
    }
}
