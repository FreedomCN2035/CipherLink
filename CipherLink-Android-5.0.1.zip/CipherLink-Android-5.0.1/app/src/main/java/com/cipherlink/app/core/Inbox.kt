package com.cipherlink.app.core

import android.content.Context
import android.content.Intent
import com.cipherlink.app.crypto.CryptoEngine
import com.cipherlink.app.qr.QrTransfer
import com.cipherlink.app.storage.AppStore
import java.security.KeyPair
import java.util.UUID

/**
 * The single place where incoming CipherLink data (text, QR fragments, encrypted files) is
 * recognized, decrypted, de-duplicated and stored. Every entry point - the app, the
 * notification, the floating window, the background monitors and the quick-decrypt screen -
 * goes through here, so they all behave the same.
 *
 * MANUAL: the user asked for it. Always reports a result (also for a message seen before)
 *         and reports errors.
 * AUTO:   background monitoring. Completely silent for anything that is not a new, valid
 *         message for this device; a message is reported at most once, ever.
 */
object Inbox {
    const val ACTION_UPDATED = "com.cipherlink.app.action.INBOX_UPDATED"
    private const val MAX_STORED_CHARS = 100_000

    /** Automatic monitors only look at clips / images that are at most this old. */
    const val FRESH_MS = 10 * 60 * 1000L

    enum class Mode { MANUAL, AUTO }

    sealed class Outcome {
        class Decrypted(val item: AppStore.HistoryItem, val duplicate: Boolean) : Outcome()
        class PublicKeyCard(val card: String) : Outcome()
        class Progress(val received: Int, val total: Int, val missing: List<Int>) : Outcome()
        class Failed(val error: Throwable) : Outcome()
        object Ignored : Outcome()
    }

    /** Cheap pre-check so the monitors do no work for ordinary text. */
    fun looksLikeCipherLink(text: String): Boolean =
        text.contains(CryptoEngine.MESSAGE_PREFIX) || text.contains(QrTransfer.PREFIX) ||
            text.contains(CryptoEngine.PUBLIC_PREFIX)

    fun processText(context: Context, text: String, source: String, mode: Mode): Outcome =
        processTexts(context, listOf(text), source, mode)

    fun processTexts(context: Context, values: Collection<String>, source: String, mode: Mode): Outcome {
        val app = context.applicationContext ?: context

        val normalized = ArrayList<String>()
        var normalizeError: Throwable? = null
        for (value in values) {
            try {
                val n = CryptoEngine.normalizeIncoming(value)
                if (!normalized.contains(n)) normalized.add(n)
            } catch (t: Throwable) {
                if (normalizeError == null) normalizeError = t
            }
        }
        if (normalized.isEmpty()) {
            val err = normalizeError
            return if (mode == Mode.MANUAL && err != null) Outcome.Failed(err) else Outcome.Ignored
        }

        val payloads = ArrayList<String>()
        var progress: Outcome.Progress? = null
        var partError: Throwable? = null

        val parts = normalized.filter { QrTransfer.isPart(it) }
        if (parts.isNotEmpty()) {
            try {
                for (r in QrTransfer.addScans(parts)) {
                    if (r is QrTransfer.Complete) {
                        if (!payloads.contains(r.payload)) payloads.add(r.payload)
                    } else if (r is QrTransfer.Progress) {
                        val current = progress
                        if (current == null || r.received > current.received) {
                            progress = Outcome.Progress(r.received, r.total, r.missing)
                        }
                    }
                }
            } catch (t: Throwable) {
                partError = t
            }
        }
        for (n in normalized) {
            if (n.startsWith(CryptoEngine.MESSAGE_PREFIX) && !payloads.contains(n)) payloads.add(n)
        }

        var decrypted: Outcome.Decrypted? = null
        var failure: Throwable? = null
        for (payload in payloads) {
            val digest = AppStore.digestOf(payload)
            val outcome = decryptAndStore(app, digest, source, mode) { identity, trusted ->
                CryptoEngine.decrypt(payload, identity, trusted)
            }
            if (outcome is Outcome.Decrypted) {
                val current = decrypted
                if (current == null || (current.duplicate && !outcome.duplicate)) decrypted = outcome
            } else if (outcome is Outcome.Failed) {
                failure = outcome.error
            }
        }

        val done = decrypted
        if (done != null) return done
        val failed = failure
        if (failed != null) return Outcome.Failed(failed)
        val prog = progress
        if (prog != null) return prog
        val partErr = partError
        if (partErr != null) return if (mode == Mode.MANUAL) Outcome.Failed(partErr) else Outcome.Ignored
        val card = normalized.firstOrNull { it.startsWith(CryptoEngine.PUBLIC_PREFIX) }
        if (card != null) return Outcome.PublicKeyCard(card)
        return Outcome.Ignored
    }

    /** An encrypted attachment file (.clink) that was shared, opened or picked. */
    fun processFileBytes(context: Context, bytes: ByteArray, source: String, mode: Mode): Outcome {
        val app = context.applicationContext ?: context
        val packet = try {
            CryptoEngine.fileToPacket(bytes)
        } catch (t: Throwable) {
            return if (mode == Mode.MANUAL) Outcome.Failed(t) else Outcome.Ignored
        }
        val digest = AppStore.digestOf(packet)
        return decryptAndStore(app, digest, source, mode) { identity, trusted ->
            CryptoEngine.decryptPacket(packet, identity, trusted)
        }
    }

    private fun decryptAndStore(
        app: Context,
        digest: String,
        source: String,
        mode: Mode,
        run: (KeyPair, Map<String, CryptoEngine.TrustedContact>) -> CryptoEngine.DecryptResult
    ): Outcome {
        val store = AppStore(app)
        if (mode == Mode.AUTO && store.isProcessed(digest)) return Outcome.Ignored
        val identity = store.loadIdentity()
            ?: return if (mode == Mode.MANUAL) {
                Outcome.Failed(IllegalStateException("本机密钥不可用，请先在 CipherLink 中创建密钥"))
            } else {
                Outcome.Ignored
            }
        val result = try {
            run(identity, store.trustedContacts())
        } catch (t: Throwable) {
            return if (mode == Mode.MANUAL) Outcome.Failed(t) else Outcome.Ignored
        }
        return save(app, store, result, digest, source, mode)
    }

    private fun save(
        app: Context,
        store: AppStore,
        result: CryptoEngine.DecryptResult,
        digest: String,
        source: String,
        mode: Mode
    ): Outcome {
        val firstTime = store.claimProcessed(digest)
        if (mode == Mode.AUTO && !firstTime) return Outcome.Ignored

        val existing = store.findHistory(digest)
        if (existing != null) return Outcome.Decrypted(existing, true)

        val attachment = result.attachment
        val stored = if (attachment != null) {
            try {
                store.saveAttachmentBytes(attachment.data)
            } catch (t: Throwable) {
                return if (mode == Mode.MANUAL) Outcome.Failed(t) else Outcome.Ignored
            }
        } else {
            null
        }
        val text = result.plaintext
        val shownText = if (text.length > MAX_STORED_CHARS) text.take(MAX_STORED_CHARS) + "\n…（内容过长，已截断保存）" else text
        val item = AppStore.HistoryItem(
            id = UUID.randomUUID().toString(),
            digest = digest,
            kind = if (attachment != null) AppStore.KIND_FILE else AppStore.KIND_TEXT,
            time = System.currentTimeMillis(),
            senderFp = result.senderFingerprint,
            senderName = result.senderName,
            senderCard = result.senderCard,
            source = source,
            text = if (attachment != null && shownText.isEmpty()) null else shownText,
            fileName = attachment?.name,
            fileMime = attachment?.mime,
            fileSize = attachment?.data?.size?.toLong() ?: 0L,
            fileStored = stored?.storedName,
            fileKey = stored?.wrappedKey
        )
        store.addHistory(item)
        app.sendBroadcast(Intent(ACTION_UPDATED).setPackage(app.packageName))
        return Outcome.Decrypted(item, false)
    }

    /** Plain-text description of a failure that is safe to show to the user. */
    fun describe(t: Throwable): String {
        val message = generateSequence(t) { it.cause }
            .mapNotNull { it.message?.takeIf(String::isNotBlank) }
            .distinct()
            .take(2)
            .joinToString("\n")
        return message.ifBlank { t.javaClass.simpleName }
    }
}
