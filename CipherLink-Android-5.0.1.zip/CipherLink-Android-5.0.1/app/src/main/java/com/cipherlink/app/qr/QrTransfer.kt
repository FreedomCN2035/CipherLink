package com.cipherlink.app.qr

import com.cipherlink.app.crypto.CryptoEngine
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Transport-only fragmentation. CipherLink encrypts/signs the complete CL2M packet first,
 * then fragments the final text for QR transmission. Missing/reordered/duplicated pieces
 * are handled before decryption.
 */
object QrTransfer {
    const val PREFIX = "CL2Q."
    private const val DEFAULT_CHUNK_CHARS = 1500
    private const val MAX_CHUNK_CHARS = 1750
    private const val MAX_PARTS = 32

    /** Longest CL2M text that can still be turned into QR codes. */
    const val MAX_PAYLOAD_CHARS = MAX_PARTS * DEFAULT_CHUNK_CHARS
    private const val MAX_ACTIVE_GROUPS = 8
    private const val EXPIRY_MS = 20 * 60 * 1000L
    private val random = SecureRandom()

    data class Part(
        val id: String,
        val index: Int,
        val total: Int,
        val digest: String,
        val chunk: String
    )

    sealed interface AddResult
    data class Progress(val id: String, val received: Int, val total: Int, val missing: List<Int>) : AddResult
    data class Complete(val id: String, val total: Int, val payload: String) : AddResult

    private data class State(
        val total: Int,
        val digest: String,
        val parts: MutableMap<Int, String>,
        var updatedAt: Long
    )

    private val states = LinkedHashMap<String, State>()

    fun split(payload: String, chunkChars: Int = DEFAULT_CHUNK_CHARS): List<String> {
        require(payload.startsWith(CryptoEngine.MESSAGE_PREFIX)) { "二维码只能承载 CipherLink 加密消息" }
        require(chunkChars in 700..MAX_CHUNK_CHARS) { "二维码分片大小不合法" }
        if (payload.length <= MAX_CHUNK_CHARS) return listOf(payload)

        val id = CryptoEngine.encode(ByteArray(9).also(random::nextBytes))
        val digest = fullDigest(payload)
        val total = (payload.length + chunkChars - 1) / chunkChars
        require(total <= MAX_PARTS) { "消息太长，最多支持 $MAX_PARTS 张二维码" }

        return (0 until total).map { index ->
            val start = index * chunkChars
            val end = minOf(payload.length, start + chunkChars)
            "$PREFIX$id.${index + 1}.$total.$digest.${payload.substring(start, end)}"
        }
    }

    fun isPart(value: String): Boolean = value.trim().startsWith(PREFIX)

    fun parse(value: String): Part {
        val pieces = value.trim().removePrefix(PREFIX).split('.', limit = 5)
        require(pieces.size == 5) { "二维码分片格式损坏" }
        val id = pieces[0]
        val index = pieces[1].toIntOrNull() ?: throw IllegalArgumentException("二维码序号无效")
        val total = pieces[2].toIntOrNull() ?: throw IllegalArgumentException("二维码总数无效")
        val digest = pieces[3]
        val chunk = pieces[4]
        require(id.length in 12..24) { "传输 ID 无效" }
        require(total in 2..MAX_PARTS) { "二维码总数无效" }
        require(index in 1..total) { "二维码序号无效" }
        require(digest.length == 43) { "二维码校验值无效" }
        require(chunk.isNotEmpty() && chunk.length <= MAX_CHUNK_CHARS) { "二维码分片长度无效" }
        return Part(id, index, total, digest, chunk)
    }

    @Synchronized
    fun addScans(values: Collection<String>): List<AddResult> {
        purgeExpired()
        val parsed = values.map { parse(it) }
        val groups = parsed.groupBy { it.id }
        val results = ArrayList<AddResult>()

        for ((id, group) in groups) {
            val first = group.first()
            val state = states.getOrPut(id) {
                while (states.size >= MAX_ACTIVE_GROUPS) {
                    states.remove(states.entries.firstOrNull()?.key)
                }
                State(first.total, first.digest, LinkedHashMap(), System.currentTimeMillis())
            }
            require(state.total == first.total) { "同一二维码组总片数不一致" }
            require(state.digest == first.digest) { "同一二维码组校验值不一致" }

            for (part in group) {
                val old = state.parts[part.index]
                if (old != null && old != part.chunk) {
                    throw IllegalArgumentException("二维码第 ${part.index} 片出现冲突数据")
                }
                state.parts[part.index] = part.chunk
            }
            state.updatedAt = System.currentTimeMillis()

            if (state.parts.size == state.total) {
                val payload = buildString {
                    for (i in 1..state.total) append(state.parts[i] ?: error("缺少第 $i 片"))
                }
                require(payload.startsWith(CryptoEngine.MESSAGE_PREFIX)) { "二维码拼接后不是 CipherLink 消息" }
                require(fullDigest(payload) == state.digest) { "二维码完整性校验失败：图片可能被修改或损坏" }
                states.remove(id)
                results += Complete(id, state.total, payload)
            } else {
                val missing = (1..state.total).filterNot(state.parts::containsKey)
                results += Progress(id, state.parts.size, state.total, missing)
            }
        }
        return results
    }

    @Synchronized
    fun reset() = states.clear()

    private fun fullDigest(value: String): String = CryptoEngine.encode(
        MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
    )

    @Synchronized
    private fun purgeExpired() {
        val cutoff = System.currentTimeMillis() - EXPIRY_MS
        states.entries.removeIf { it.value.updatedAt < cutoff }
    }
}
