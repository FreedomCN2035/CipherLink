package com.cipherlink.app.ui

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Toast
import com.cipherlink.app.R
import com.cipherlink.app.core.Fmt
import com.cipherlink.app.crypto.CryptoEngine
import com.cipherlink.app.crypto.EntropyCollector
import com.cipherlink.app.storage.AppStore
import java.util.Locale
import java.util.concurrent.Executors

/**
 * First-run key creation. The user touches / slides for about 3 seconds; touch coordinates and
 * timing are mixed in as extra entropy (the OS SecureRandom stays the primary source).
 */
class EntropyDialog(
    private val activity: Activity,
    private val store: AppStore,
    private val onFinished: () -> Unit
) {
    private var dialog: AlertDialog? = null

    val isShowing: Boolean get() = dialog?.isShowing == true

    fun show() {
        if (!Dialogs.isAlive(activity) || isShowing) return
        val ui = Ui(activity)
        val collector = EntropyCollector()
        val handler = Handler(Looper.getMainLooper())
        val executor = Executors.newSingleThreadExecutor()
        var generating = false
        var started = false

        val root = ui.vbox().apply { setPadding(ui.dp(22), ui.dp(16), ui.dp(22), ui.dp(16)) }
        root.addView(ui.text("创建本机密钥", 22f, R.color.cl_text, true))
        root.addView(
            ui.muted(
                "请在下方区域随意点按或滑动约 3 秒，用来为密钥增加额外的随机性。系统安全随机数仍是主要随机源。",
                13f
            ).apply { setLineSpacing(0f, 1.15f) },
            ui.lp(t = 7, b = 12)
        )

        val status = ui.muted("", 12f).apply { gravity = android.view.Gravity.CENTER }
        val progress = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 3_000
            progress = 0
        }

        fun updateUi() {
            val elapsed = collector.elapsedMs()
            progress.progress = elapsed.coerceIn(0L, 3_000L).toInt()
            status.text = if (!started) {
                "触摸上方区域开始 · 持续约 3 秒"
            } else {
                "已收集 ${collector.count()} 次交互 · " + String.format(Locale.US, "%.1f", elapsed / 1000.0) + " 秒"
            }
        }

        fun generate() {
            if (generating) return
            generating = true
            handler.removeCallbacksAndMessages(null)
            status.text = "采集完成，正在生成 RSA-3072 密钥并自测（可能需要几秒）…"
            progress.progress = 3_000
            executor.execute {
                try {
                    val pair = CryptoEngine.generateIdentity(collector.snapshotDigest())
                    require(CryptoEngine.selfTest(pair)) { "新密钥自测失败，已拒绝保存" }
                    store.saveIdentity(pair)
                    handler.post {
                        dialog?.dismiss()
                        if (Dialogs.isAlive(activity)) {
                            Toast.makeText(
                                activity,
                                "密钥已生成 · 指纹 " + Fmt.fingerprintShort(CryptoEngine.fingerprint(pair.public)),
                                Toast.LENGTH_LONG
                            ).show()
                            onFinished()
                        }
                    }
                } catch (t: Throwable) {
                    handler.post {
                        generating = false
                        started = false
                        collector.reset()
                        status.text = "生成失败，请重新触摸采集"
                        progress.progress = 0
                        Dialogs.error(activity, "密钥生成失败", t)
                    }
                }
            }
        }

        val ticker = object : Runnable {
            override fun run() {
                if (generating || dialog?.isShowing != true || !started) return
                updateUi()
                if (collector.elapsedMs() >= 3_000L) generate() else handler.postDelayed(this, 80L)
            }
        }

        val pad = object : View(activity) {
            private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            private val points = ArrayDeque<Pair<Float, Float>>()

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                canvas.drawColor(ui.color(R.color.cl_input))
                val cx = width / 2f
                val cy = height / 2f
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = ui.dp(2).toFloat()
                paint.color = ui.color(R.color.cl_primary)
                canvas.drawCircle(cx, cy, ui.dp(62).toFloat(), paint)
                paint.style = Paint.Style.FILL
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = ui.dp(15).toFloat()
                paint.color = ui.color(R.color.cl_muted)
                canvas.drawText("随意点按 / 滑动", cx, cy + ui.dp(5), paint)
                if (points.size >= 2) {
                    paint.style = Paint.Style.STROKE
                    paint.color = (ui.color(R.color.cl_primary) and 0x00FFFFFF) or 0x66000000
                    val list = points.toList()
                    for (i in 1 until list.size) {
                        canvas.drawLine(list[i - 1].first, list[i - 1].second, list[i].first, list[i].second, paint)
                    }
                }
            }

            override fun onTouchEvent(event: MotionEvent): Boolean {
                if (generating) return true
                collector.add(event)
                if (points.size >= 70) points.removeFirst()
                points.addLast(Pair(event.x, event.y))
                invalidate()
                if (!started) {
                    started = true
                    handler.removeCallbacksAndMessages(null)
                    handler.post(ticker)
                }
                updateUi()
                return true
            }
        }
        root.addView(pad, ui.lp(h = ui.dp(210), b = 10))
        root.addView(status, ui.lp(h = ui.dp(30)))
        root.addView(progress, ui.lp(h = ui.dp(6), b = 8))
        root.addView(
            ui.muted("完成后会自动生成 RSA-3072 密钥对，并先做一次加解密自测。私钥只保存在本机。", 12f)
                .apply { gravity = android.view.Gravity.CENTER; setLineSpacing(0f, 1.1f) }
        )
        updateUi()

        val scroll = ScrollView(activity).apply { addView(root, FrameLayout.LayoutParams(-1, -2)) }
        val built = AlertDialog.Builder(activity)
            .setView(scroll)
            .setNegativeButton("以后再说", null)
            .create()
        built.setCancelable(false)
        built.setCanceledOnTouchOutside(false)
        built.setOnDismissListener {
            handler.removeCallbacksAndMessages(null)
            executor.shutdown()
            dialog = null
        }
        dialog = built
        built.show()
        built.window?.setLayout(
            (activity.resources.displayMetrics.widthPixels - ui.dp(32)).coerceAtLeast(ui.dp(280)),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }
}
