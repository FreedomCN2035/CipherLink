package com.cipherlink.app.qr

import com.cipherlink.app.crypto.CryptoEngine
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.MultiFormatWriter
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.common.BitMatrix
import com.google.zxing.multi.GenericMultipleBarcodeReader
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** QR encoder/decoder tuned for screenshots and multi-QR sheets. */
object QrCodec {
    private const val DEFAULT_SIZE = 720
    private const val SHEET_QR_SIZE = 620
    private const val SHEET_LABEL_HEIGHT = 50
    private const val SHEET_GAP = 26
    private const val SHEET_OUTER = 24
    private const val SHEET_CELL_HEIGHT = SHEET_QR_SIZE + SHEET_LABEL_HEIGHT
    private const val MARGIN = 4

    fun encode(text: String, size: Int = DEFAULT_SIZE): Bitmap {
        require(text.isNotEmpty()) { "二维码内容为空" }
        require(text.length <= 1750) { "二维码单片过长，请使用自动分片" }
        val hints = mapOf<EncodeHintType, Any>(
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to MARGIN
        )
        val matrix: BitMatrix = MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val pixels = IntArray(size * size)
        for (y in 0 until size) {
            val row = y * size
            for (x in 0 until size) pixels[row + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
        }
        return Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
    }

    /**
     * Generates every QR in one image. The number of columns adapts to keep the sheet
     * reasonably square, while each QR keeps a large quiet zone for screenshot decoding.
     */
    fun encodeSheet(parts: List<String>): Bitmap {
        require(parts.isNotEmpty()) { "没有二维码内容" }
        val columns = when {
            parts.size <= 16 -> 2
            parts.size <= 27 -> 3
            else -> 4
        }
        val gap = SHEET_GAP
        val outer = SHEET_OUTER
        val labelHeight = SHEET_LABEL_HEIGHT
        val cellW = SHEET_QR_SIZE
        val cellH = SHEET_CELL_HEIGHT
        val rows = ceil(parts.size / columns.toDouble()).toInt()
        val width = outer * 2 + columns * cellW + (columns - 1) * gap
        val height = outer * 2 + rows * cellH + (rows - 1) * gap
        val sheet = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(sheet)
        canvas.drawColor(Color.WHITE)

        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 40, 52)
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(105, 113, 131)
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(225, 228, 234)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }

        parts.forEachIndexed { index, part ->
            val qr = encode(part, SHEET_QR_SIZE)
            try {
                val col = index % columns
                val row = index / columns
                val left = outer + col * (cellW + gap)
                val top = outer + row * (cellH + gap)
                canvas.drawRoundRect(
                    left.toFloat() - 5f,
                    top.toFloat() - 5f,
                    (left + cellW).toFloat() + 5f,
                    (top + cellH).toFloat() + 5f,
                    10f,
                    10f,
                    borderPaint
                )
                canvas.drawBitmap(qr, left.toFloat(), top.toFloat(), null)
                canvas.drawText("${index + 1} / ${parts.size}", left + cellW / 2f, top + cellW + 26f, labelPaint)
                if (parts.size > 1) {
                    canvas.drawText("CipherLink QR", left + cellW / 2f, top + cellW + 45f, subPaint)
                }
            } finally {
                qr.recycle()
            }
        }
        return sheet
    }

    /**
     * Decodes all QR codes it can find. For a CipherLink sheet, GenericMultipleBarcodeReader
     * is attempted first, then a small set of grid decompositions is used as a deterministic
     * fallback. This makes whole-sheet screenshots much more reliable than decoding one QR.
     */
    fun decodeAll(bitmap: Bitmap, deep: Boolean = true): List<String> {
        val results = LinkedHashSet<String>()
        val images = ArrayList<Bitmap>(2)
        images += bitmap

        // Screenshots from chat apps are often downscaled. A bounded upscale restores module
        // size for ZXing without allowing untrusted images to trigger huge allocations.
        // Background monitoring (deep = false) skips this and the grid search for plain
        // images, so ordinary screenshots cost almost no battery.
        if (deep && maxOf(bitmap.width, bitmap.height) < 3600) {
            val factor = min(2.0, 3600.0 / maxOf(bitmap.width, bitmap.height).coerceAtLeast(1).toDouble())
            if (factor > 1.15) {
                val w = (bitmap.width * factor).roundToInt().coerceAtLeast(bitmap.width)
                val h = (bitmap.height * factor).roundToInt().coerceAtLeast(bitmap.height)
                if (w.toLong() * h.toLong() <= 16_000_000L) {
                    runCatching { Bitmap.createScaledBitmap(bitmap, w, h, true) }.getOrNull()?.let(images::add)
                }
            }
        }

        for (image in images) {
            results.addAll(decodeWhole(image))
            val expected = results.mapNotNull(::declaredPartTotal).maxOrNull() ?: 1
            if (expected > 1 && results.count { it.startsWith(QrTransfer.PREFIX) } < expected) {
                for ((cols, rows) in gridCandidates(image, expected)) {
                    decodeGrid(image, cols, rows).forEach(results::add)
                    if (results.count { it.startsWith(QrTransfer.PREFIX) } >= expected) break
                }
            } else if (deep && results.isEmpty()) {
                for ((cols, rows) in gridCandidates(image, null).take(12)) {
                    decodeGrid(image, cols, rows).forEach(results::add)
                    if (results.isNotEmpty()) break
                }
            }
            if (image !== bitmap) image.recycle()
            val expectedAfter = results.mapNotNull(::declaredPartTotal).maxOrNull() ?: 1
            if (expectedAfter == 1 || results.count { it.startsWith(QrTransfer.PREFIX) } >= expectedAfter) {
                if (results.any { it.startsWith(CryptoEngine.MESSAGE_PREFIX) } || results.count { it.startsWith(QrTransfer.PREFIX) } > 0) {
                    break
                }
            }
        }
        return results.toList()
    }

    private fun decodeWhole(bitmap: Bitmap): List<String> {
        val binary = toBinary(bitmap)
        val hints = mapOf<DecodeHintType, Any>(
            DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
            DecodeHintType.TRY_HARDER to true,
            DecodeHintType.CHARACTER_SET to "UTF-8"
        )
        val out = LinkedHashSet<String>()
        runCatching {
            val reader = MultiFormatReader().apply { setHints(hints) }
            GenericMultipleBarcodeReader(reader).decodeMultiple(binary, hints).forEach { out.add(it.text) }
        }
        if (out.isEmpty()) {
            runCatching {
                val reader = MultiFormatReader().apply { setHints(hints) }
                out.add(reader.decode(binary, hints).text)
            }
        }
        return out.toList()
    }

    private fun decodeGrid(bitmap: Bitmap, columns: Int, rows: Int): List<String> {
        val out = LinkedHashSet<String>()
        if (columns !in 1..4 || rows !in 1..20) return emptyList()
        for (row in 0 until rows) {
            for (col in 0 until columns) {
                val cellLeft = bitmap.width * col / columns
                val cellRight = bitmap.width * (col + 1) / columns
                val cellTop = bitmap.height * row / rows
                val cellBottom = bitmap.height * (row + 1) / rows
                val cw = cellRight - cellLeft
                val ch = cellBottom - cellTop
                if (cw < 160 || ch < 160) continue

                // CipherLink sheets place a square QR at the TOP of each cell and the
                // "n / total" label below it. The previous centered 90% crop could cut into
                // the finder patterns. Keep almost the entire QR area and only trim the label.
                val marginX = max(4, cw / 40)
                val marginTop = max(4, ch / 50)
                val labelReserve = max(48, ch / 9)
                val cropSize = min(cw - marginX * 2, ch - labelReserve)
                if (cropSize < 140) continue

                val left = cellLeft + (cw - cropSize) / 2
                val top = cellTop + marginTop
                var decodedInCell = false
                val crop = runCatching { Bitmap.createBitmap(bitmap, left, top, cropSize, cropSize) }.getOrNull() ?: continue
                try {
                    decodeWhole(crop).forEach { out.add(it); decodedInCell = true }
                } finally {
                    crop.recycle()
                }

                // Fallback for externally assembled grids where the QR may be vertically centered.
                if (!decodedInCell) {
                    val centeredTop = cellTop + max(0, (ch - cropSize) / 2)
                    val centered = runCatching { Bitmap.createBitmap(bitmap, left, centeredTop, cropSize, cropSize) }.getOrNull()
                    if (centered != null) {
                        try { decodeWhole(centered).forEach { out.add(it); decodedInCell = true } } finally { centered.recycle() }
                    }
                }
            }
        }
        return out.toList()
    }

    private fun gridCandidates(bitmap: Bitmap, expectedTotal: Int?): List<Pair<Int, Int>> {
        val ratio = bitmap.height.toDouble() / bitmap.width.toDouble().coerceAtLeast(1.0)
        val candidates = LinkedHashSet<Pair<Int, Int>>()

        if (expectedTotal != null) {
            for (cols in 1..4) {
                val rows = (expectedTotal + cols - 1) / cols
                if (rows in 1..20) candidates += cols to rows
            }
        } else {
            for (cols in 1..4) {
                for (rows in 1..20) candidates += cols to rows
            }
        }

        // Generated sheets have cellH = 620 + 50 and fixed gaps/outer margins.
        // Rank layouts by how close their theoretical aspect ratio is to the input image.
        fun layoutRatio(pair: Pair<Int, Int>): Double {
            val (cols, rows) = pair
            val width = 48 + cols * SHEET_QR_SIZE + (cols - 1) * SHEET_GAP
            val height = 48 + rows * SHEET_CELL_HEIGHT + (rows - 1) * SHEET_GAP
            return height.toDouble() / width.toDouble()
        }
        return candidates.sortedBy { kotlin.math.abs(kotlin.math.ln((layoutRatio(it) + 1e-9) / (ratio + 1e-9))) }
    }

    private fun declaredPartTotal(text: String): Int? {
        if (!text.startsWith(QrTransfer.PREFIX)) return null
        val pieces = text.removePrefix(QrTransfer.PREFIX).split('.', limit = 5)
        return pieces.getOrNull(2)?.toIntOrNull()?.takeIf { it in 2..64 }
    }

    private fun toBinary(bitmap: Bitmap): BinaryBitmap {
        val argb = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(argb, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        return BinaryBitmap(HybridBinarizer(RGBLuminanceSource(bitmap.width, bitmap.height, argb)))
    }
}
