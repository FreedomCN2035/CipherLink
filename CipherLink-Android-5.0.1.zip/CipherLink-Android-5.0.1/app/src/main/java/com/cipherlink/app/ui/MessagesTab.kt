package com.cipherlink.app.ui

import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.cipherlink.app.MainActivity
import com.cipherlink.app.R
import com.cipherlink.app.core.Fmt
import com.cipherlink.app.storage.AppStore

/** "消息" tab: recipient, composer (text + attachment), decrypt shortcuts and the inbox. */
class MessagesTab(private val host: MainActivity) {
    private val ui: Ui get() = host.ui
    private val store: AppStore get() = host.store

    private var inboxBox: LinearLayout? = null
    private var inboxCount: TextView? = null

    fun build(): View {
        val scroll = ScrollView(host).apply { isFillViewport = true }
        val box = ui.vbox().apply { setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(24)) }

        val state = store.identityState()
        val contacts = store.listContacts()
        val active = store.activeContact()

        if (state == AppStore.IdentityState.CORRUPT) {
            box.addView(corruptCard())
        } else if (state == AppStore.IdentityState.NONE || contacts.isEmpty()) {
            box.addView(setupCard(state == AppStore.IdentityState.READY, contacts.isNotEmpty()))
        }

        if (state == AppStore.IdentityState.READY) {
            box.addView(recipientCard(active))
            box.addView(composerCard(active))
            box.addView(receiveCard())
        }

        val headerRow = ui.hbox().apply { setPadding(ui.dp(4), ui.dp(10), ui.dp(4), ui.dp(8)) }
        headerRow.addView(ui.text("收件箱", 18f, R.color.cl_text, true))
        val count = ui.muted("", 12f)
        inboxCount = count
        headerRow.addView(count, ui.lp(l = 8, w = 0, weight = 1f))
        headerRow.addView(ui.button("清空", Ui.BTN_GHOST) { host.clearInbox() })
        box.addView(headerRow)

        val list = ui.vbox()
        inboxBox = list
        box.addView(list)
        refreshInbox()

        scroll.addView(box)
        return scroll
    }

    // ----------------------------------------------------------------- cards

    private fun corruptCard(): View {
        val card = ui.card()
        card.background = ui.rounded(ui.color(R.color.cl_warn_soft), 20)
        card.addView(ui.text("本机密钥数据异常", 16f, R.color.cl_warn, true))
        card.addView(
            ui.text(
                "检测到已有密钥但无法读取（常见原因：系统迁移或清除了安全存储）。为避免历史消息突然失效，CipherLink 不会自动覆盖它。",
                13f, R.color.cl_text
            ).apply { setLineSpacing(0f, 1.15f) },
            ui.lp(t = 6)
        )
        card.addView(ui.button("到设置里处理", Ui.BTN_PRIMARY) { host.openTab(2) }, ui.lp(t = 12))
        return card
    }

    private fun setupCard(keyReady: Boolean, hasContact: Boolean): View {
        val card = ui.card()
        card.addView(ui.text("3 步开始加密聊天", 18f, R.color.cl_text, true))
        card.addView(ui.muted("先互换公钥，之后双方就可以互发只有对方能解开的密文。"), ui.lp(t = 3, b = 8))

        card.addView(stepRow(1, "创建你的密钥", "在本机生成一对 RSA-3072 密钥，私钥永远不会离开手机", keyReady) {
            ui.button("创建密钥", Ui.BTN_PRIMARY) { host.startKeyCreation() }
        })
        card.addView(stepRow(2, "把你的公钥发给对方", "公钥可以公开，通过任何聊天软件发送都安全", false) {
            if (keyReady) ui.button("分享公钥", Ui.BTN_PRIMARY) { host.shareMyPublicKey() } else null
        })
        card.addView(stepRow(3, "导入对方的公钥", "对方把他的公钥发给你，粘贴或扫描后保存为联系人", hasContact) {
            ui.button("添加联系人", Ui.BTN_PRIMARY) { host.showAddContactDialog() }
        })
        return card
    }

    private fun stepRow(number: Int, title: String, subtitle: String, done: Boolean, action: () -> View?): View {
        val row = ui.vbox().apply { setPadding(0, ui.dp(8), 0, ui.dp(4)) }
        val head = ui.hbox()
        val badge = ui.text(if (done) "✓" else number.toString(), 14f, if (done) R.color.cl_on_primary else R.color.cl_primary, true).apply {
            gravity = Gravity.CENTER
            background = ui.rounded(ui.color(if (done) R.color.cl_green else R.color.cl_primary_soft), 15)
        }
        head.addView(badge, ui.lp(w = ui.dp(30), h = ui.dp(30), r = 12))
        val texts = ui.vbox()
        texts.addView(ui.text(title, 15f, R.color.cl_text, true))
        texts.addView(ui.muted(subtitle), ui.lp(t = 2))
        head.addView(texts, ui.lp(w = 0, weight = 1f))
        row.addView(head)
        if (!done) {
            action()?.let { button -> row.addView(button, ui.lp(t = 8, l = 42)) }
        }
        return row
    }

    private fun recipientCard(active: AppStore.Contact?): View {
        val card = ui.card()
        val row = ui.hbox()
        val texts = ui.vbox()
        texts.addView(ui.muted("发给"))
        texts.addView(ui.text(active?.name ?: "尚未选择收件人", 20f, R.color.cl_text, true), ui.lp(t = 2))
        texts.addView(
            ui.muted(if (active != null) "指纹 " + Fmt.fingerprintShort(active.id) else "先添加对方的公钥", 12f),
            ui.lp(t = 2)
        )
        row.addView(texts, ui.lp(w = 0, weight = 1f))
        row.addView(
            ui.button(if (store.listContacts().isEmpty()) "添加联系人" else "切换") {
                if (store.listContacts().isEmpty()) host.showAddContactDialog() else host.showContactChooser()
            }
        )
        card.addView(row)
        return card
    }

    private fun composerCard(active: AppStore.Contact?): View {
        val card = ui.card()
        val input = ui.input("输入要加密的内容…", 4, 8)
        input.setText(host.draftText)
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                host.draftText = s?.toString().orEmpty()
            }
        })
        card.addView(input, ui.lp(h = ui.dp(124)))

        val attachment = host.draftAttachment
        if (attachment != null) {
            val chip = ui.hbox().apply {
                setPadding(ui.dp(12), ui.dp(8), ui.dp(6), ui.dp(8))
                background = ui.rounded(ui.color(R.color.cl_primary_soft), 14)
            }
            val label = ui.text("📎 " + attachment.name + " · " + Fmt.size(attachment.bytes.size.toLong()), 13f, R.color.cl_primary, true)
            label.maxLines = 1
            label.ellipsize = TextUtils.TruncateAt.MIDDLE
            chip.addView(label, ui.lp(w = 0, weight = 1f))
            chip.addView(ui.button("移除", Ui.BTN_GHOST) {
                host.draftAttachment = null
                host.renderTab()
            })
            card.addView(chip, ui.lp(t = 10))
        }

        val row = ui.hbox()
        row.addView(ui.button(if (attachment == null) "📎 附件" else "更换附件") { host.pickAttachment() }, ui.lp(w = 0, weight = 1f, t = 10, r = 5))
        row.addView(ui.button("二维码拼图") {
            if (!ready(active)) return@button
            val attached = host.draftAttachment
            if (attached != null) {
                host.encryptAttachmentFlow(attached, host.draftText.trim(), true)
            } else {
                val text = input.text.toString().trim()
                if (text.isEmpty()) {
                    host.toast("请先输入要加密的内容")
                } else {
                    host.encryptTextAsync(text) { payload ->
                        host.clearDraft()
                        input.setText("")
                        host.showQrDialog(payload)
                    }
                }
            }
        }, ui.lp(w = 0, weight = 1f, t = 10, l = 5))
        card.addView(row)

        val primaryLabel = if (attachment == null) "加密并复制文本" else "加密附件并发送"
        card.addView(ui.button(primaryLabel, Ui.BTN_PRIMARY) {
            if (!ready(active)) return@button
            val attached = host.draftAttachment
            if (attached != null) {
                host.encryptAttachmentFlow(attached, host.draftText.trim(), false)
            } else {
                val text = input.text.toString().trim()
                if (text.isEmpty()) {
                    host.toast("请先输入要加密的内容")
                } else {
                    host.encryptTextAsync(text) { payload ->
                        host.copyText(payload)
                        host.clearDraft()
                        input.setText("")
                        host.toast("已加密并复制（${payload.length} 字符），去聊天软件粘贴发送")
                    }
                }
            }
        }, ui.lp(t = 8, h = ui.dp(48)))

        card.addView(
            ui.muted("附件最大 10 MB，会加密成 .clink 文件，在聊天软件里当作“文件”发送；对方用 CipherLink 打开即可。", 11f)
                .apply { setLineSpacing(0f, 1.1f) },
            ui.lp(t = 8)
        )
        return card
    }

    private fun ready(active: AppStore.Contact?): Boolean {
        if (active == null) {
            host.toast("请先选择收件人")
            return false
        }
        return true
    }

    private fun receiveCard(): View {
        val card = ui.card()
        card.addView(ui.text("收到密文了？", 16f, R.color.cl_text, true))
        card.addView(ui.muted("复制聊天里的密文，点下面的按钮即可解密；图片和文件也支持"), ui.lp(t = 2, b = 10))

        val row = ui.hbox()
        row.addView(ui.button("粘贴并解密", Ui.BTN_PRIMARY) { host.pasteAndDecrypt() }, ui.lp(w = 0, weight = 1f, r = 5, h = ui.dp(46)))
        row.addView(ui.button("最近截图") { host.decryptLatestScreenshot() }, ui.lp(w = 0, weight = 1f, l = 5, h = ui.dp(46)))
        card.addView(row)
        card.addView(ui.button("选择二维码图片 / .clink 加密文件") { host.pickEncryptedOrImages() }, ui.lp(t = 8, h = ui.dp(46)))

        val manual = ui.input("或在这里手动粘贴密文", 2, 5)
        card.addView(manual, ui.lp(t = 10))
        card.addView(ui.button("解密输入框内容") {
            val text = manual.text.toString()
            if (text.isBlank()) host.toast("请先粘贴密文") else host.decryptText(text, "手动输入")
        }, ui.lp(t = 8))
        return card
    }

    // ------------------------------------------------------------------ inbox

    fun refreshInbox() {
        val list = inboxBox ?: return
        list.removeAllViews()
        val items = store.historyList()
        inboxCount?.text = if (items.isEmpty()) "" else "${items.size} 条"
        if (items.isEmpty()) {
            val empty = ui.card()
            empty.addView(Dialogs.centered(ui, "还没有收到消息\n解密成功的内容会保存在这里（本机加密存储）"))
            list.addView(empty)
            return
        }
        items.forEach { item -> list.addView(inboxCard(item)) }
    }

    private fun inboxCard(item: AppStore.HistoryItem): View {
        val card = ui.card()
        val trusted = store.findContact(item.senderFp) != null

        val head = ui.hbox()
        head.addView(ui.text(Fmt.senderLabel(item.senderName, item.senderFp), 15f, R.color.cl_text, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, ui.lp(w = 0, weight = 1f, r = 8))
        head.addView(ui.muted(Fmt.time(item.time), 11f))
        card.addView(head)

        val chips = ui.hbox()
        chips.addView(
            if (trusted) ui.chip("已验证联系人", R.color.cl_green, R.color.cl_green_soft)
            else ui.chip("未保存的发送方", R.color.cl_warn, R.color.cl_warn_soft)
        )
        if (item.isFile) chips.addView(ui.chip("文件", R.color.cl_primary, R.color.cl_primary_soft), ui.lp(l = 6))
        card.addView(chips, ui.lp(t = 6))

        if (item.isFile) {
            card.addView(ui.text("📎 " + (item.fileName ?: "附件"), 15f, R.color.cl_text, true), ui.lp(t = 10))
            card.addView(ui.muted(Fmt.size(item.fileSize)), ui.lp(t = 2))
            if (!item.text.isNullOrBlank()) card.addView(ui.text(item.text, 14f, R.color.cl_text), ui.lp(t = 6))
        } else {
            val body = ui.text(item.text.orEmpty(), 15f, R.color.cl_text).apply {
                maxLines = 6
                ellipsize = TextUtils.TruncateAt.END
                setLineSpacing(0f, 1.12f)
            }
            card.addView(body, ui.lp(t = 10))
        }

        val actions = ui.hbox()
        if (item.isFile) {
            actions.addView(small("保存") { host.saveReceivedFile(item) })
            actions.addView(small("打开") { host.openReceivedFile(item) })
        } else {
            actions.addView(small("复制") {
                host.copyText(item.text.orEmpty())
                host.toast("已复制")
            })
            actions.addView(small("详情") { host.showDecryptedDialog(item) })
        }
        val senderCard = item.senderCard
        if (!trusted && senderCard != null) {
            actions.addView(small("保存发送方") {
                host.importContactCard(senderCard) { host.renderTab() }
            })
        }
        actions.addView(small("删除") { host.deleteHistoryItem(item) })
        card.addView(actions, ui.lp(t = 6))
        card.setOnClickListener { host.showDecryptedDialog(item) }
        return card
    }

    private fun small(label: String, action: () -> Unit): View =
        ui.button(label, Ui.BTN_GHOST, action).apply {
            textSize = 13f
            minHeight = ui.dp(36)
            minimumHeight = ui.dp(36)
            setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6))
        }
}
